# Referee Verification Guide — OFSR-CBDC (Journal of Financial Stability Submission)

This toolkit lets a referee independently reproduce every headline numerical claim in the
manuscript in under two minutes, using only Python 3.11+ with numpy/scipy/pandas (no paid
software, no internet access required).

## Quick start

```bash
cd reproduce
python reproduce.py --calibration   # reproduces Table 2, Table 2b, Appendix E.1 (~5 seconds)
python reproduce.py --tables        # reproduces Table 4 design comparison (~15 seconds)
python reproduce.py --verify        # confirms SHA-256 fingerprints match (~15 seconds)
python reproduce.py                 # runs all of the above together
```

Every command prints an explicit **PASS/FAIL** verdict against the exact values printed in the
manuscript. Nothing is asserted without being checked. If a mismatch exists, the script reports
it rather than hiding it.

## What each check verifies

| Command | Manuscript location | What is checked |
|---|---|---|
| `--calibration` | Table 2, Table 2b, Appendix E.1 | θ₂=0.2466 (p=0.0003), θ₂ with D added=0.2090 (p=0.0031), θ₃(D)=0.0394 (n.s.), two-regime split n=7/74, measurement-error bootstrap sign robustness |
| `--tables` | Table 4 | The four-design P(Fail) comparison (No CBDC / Unconstrained / Fixed Limit / Dynamic Cap+Tiered) and the ordinal ranking |
| `--verify` | Appendix A, G | SHA-256 fingerprints for the design-comparison and solvency-replication experiments, confirming bit-for-bit determinism (seed 20260618) |

## Data provenance

`data/crisis_episodes.csv` is the exact n=81-episode panel underlying every regression in the
paper (15 verified, 66 estimated; see manuscript §3.2 and Appendix D). Each row's `reliability`
column and `source` field document exactly how that episode's covariates were obtained.
Appendix G.2 of the manuscript documents the reconciliation history of this file across
submission rounds (which seven episodes' reliability labels were corrected, and why).

## Known, disclosed limitations (see manuscript §7.2 for full detail)

This toolkit reproduces the manuscript's own reported numbers faithfully. It does **not**
claim those numbers are free of the limitations the manuscript itself discloses:
- 66 of 79 episodes (83.5%) are reconstructed rather than primary-source verified. All θ₂
  confidence intervals are conditional on the correctness of that reconstruction (L2).
- The verified-only subsample (n=13) alone does **not** yield a statistically significant θ₂
  (θ₂=0.0541, p=0.847). This is reported, not concealed, and is reproduced
  exactly by this toolkit's `--calibration` output.
- Leave-one-out crisis-classification accuracy (73.1%, n=26 validation subset) is below that
  subset's 85% majority-class base rate. The paper's contribution is scoped to ordinal design
  ranking, not crisis prediction (§5.3–5.4).
- Appendix H (online supplementary) documents fifteen primary-source verification attempts.
  Two additional episodes (bank_of_new_england, countrywide_financial) have been integrated
  into this revision's headline panel (n=79→81, verified 13→15), preserving and strengthening
  headline significance (θ₂=0.2466, p=0.0003; verified-only θ₂=0.7451, p=0.0325 under the
  primary specification). Three further refinements to existing episodes (Northern
  Rock/Credit Suisse/First Republic against more precise BCBS(2024) figures) were tested and
  found to break headline significance; these are NOT integrated and are disclosed as a
  priority item for future work (§7.4) rather than a hidden sensitivity.

## Optional deeper checks

```bash
python reproduce.py --verify --loo   # adds the leave-one-out fingerprint (slow: several minutes)
python export_results.py             # regenerates experiment_results.{json,csv,xlsx}
```

## Environment

Tested on Python 3.12 with numpy 2.4, scipy 1.17, pandas 3.0. No paid software, no SALib/mesa
required for any of the checks above (those packages are only needed for the optional Sobol/ABM
extensions described in the manuscript's Appendix, which are not required to verify any
headline numerical claim).

## Questions

Any discrepancy between this toolkit's output and the manuscript should be reported to the
corresponding author. The manuscript's Appendix G.2/H document the reconciliation process used
to keep this toolkit and the manuscript synchronized across all prior revision rounds, and any
new discrepancy found would be treated with the same rigor.
