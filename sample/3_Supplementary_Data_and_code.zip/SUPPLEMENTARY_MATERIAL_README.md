# Supplementary Material — Reproducibility Package

This package accompanies the Journal of Financial Stability submission
**"Central Bank Digital Currency as a Macroprudential Instrument: Systemic
Risk Design Trade-offs and Historical Evidence"**
(Chanhyuk Park, Jae-Suk Yang).

## Quick start for referees

```bash
cd reproduce
python reproduce.py --calibration   # reproduces manuscript Table 2 (~5 seconds)
python reproduce.py --tables        # reproduces manuscript Table 3 design comparison (~15 seconds)
python reproduce.py --verify        # confirms SHA-256 fingerprints match (~15 seconds)
```

Full instructions and a description of every check are in `REFEREE_VERIFICATION_GUIDE.md`.

## Mapping this package to the manuscript

This reproducibility engine was built and version-controlled independently of the final
manuscript, so some internal labels (variable names, code comments, cached
result files) use table/section numbers from the authors' working notes rather than the
manuscript's own numbering. The correspondence is:

| Package reference | Manuscript (Journal of Financial Stability) location |
|---|---|
| `reproduce.py --calibration`, "Table 2" | Manuscript **Table 2** (Empirical calibration) and its notes |
| `reproduce.py --calibration`, "Table 2b" (+digital adoption D) | Manuscript **Table 2 note**, robustness paragraph in **§3.5** |
| `reproduce.py --calibration`, verified/estimated split | Manuscript **Table 2 note** and **§5.3**, Limitation 1 |
| `reproduce.py --calibration`, two-regime split | Manuscript **§3.5**, robustness item 3 |
| `reproduce.py --tables`, "Table 4" design comparison | Manuscript **Table 3** (Comparative performance). Note: the package's headline
table includes a `no_cbdc` baseline column that the manuscript also reports (as the
"No CBDC (reference)" row in Table 3); the manuscript additionally reports a
`tiered_only` design (holding-cap fixed, tiered remuneration only) not present in this
script's default four-column table but directly computable from the same simulation
engine (`engines/core.py`) with `dynamic_cap=False, tiered=True` — this configuration
reproduces the manuscript's Tiered Remuneration row exactly. |
| 27-combination parameter-perturbation grid | Manuscript **§3.5**, robustness item 1 |
| 600-trial random-dropout check | Manuscript **§3.5**, robustness item 4 |
| Measurement-error bootstrap (Appendix E.1 in package docstrings) | Manuscript **§3.5**, robustness item 5 |

## What is and is not included

Included: the full n = 81 historical crisis-episode panel (`data/crisis_episodes.csv`,
15 verified / 66 estimated),
the Monte Carlo simulation engine, the OLS calibration module, and the scripted
reproduction/verification harness (`reproduce/`).

Not included / out of scope for this Letter: the web application (`platform/server`,
`platform/client`) is the authors' internal research-platform interface used during
model development. It is included for completeness and transparency but is not required
to reproduce any number reported in the manuscript; all manuscript figures are
reproducible from `reproduce/` and `platform/python` alone.

## Known, disclosed limitations

See manuscript §5.3 and the Table 2 note for the full, quantified discussion of why the
verified/estimated panel-reliability gap cannot be resolved through further data
collection alone. This package reproduces the underlying statistics (including the
formal heterogeneity test and the associated power calculation) exactly as reported in
the manuscript.

## Data license

`data/` is provided under CC BY 4.0 (see `data/README.md` and `data/DATASHEET.md` for
full provenance and reliability flags).


## Update note (this revision)

Two additional, independently re-runnable scripts have been added to `reproduce/` for this
revision, addressing reviewer requests: `grid_widened.py` (re-runs the Table F3 27-combination
scenario-perturbation grid at a widened ±40% envelope, in addition to replicating the original
±20% result) and `shrinkage_pooling.py` (fits a random-effects, DerSimonian-Laird pooling of the
verified-only and estimated-only Specification I estimates, as a partial-pooling alternative to
the frequentist verified-only-only benchmark). Both scripts write their full numeric output to
`reproduce/*_results.json` and are referenced in the main manuscript at §5.5 and §3.4
respectively. Earlier drafts of this README and the referee guide referred to a different journal
name and a stale n=79/13-verified panel size, both left over from an earlier submission round;
these have been corrected to match the current n=81/15-verified Journal of Financial Stability
submission, which is what `reproduce.py` and the shipped `data/crisis_episodes.csv` have actually
reflected throughout.
