# Datasheet — Historical Bank-Run / Deposit-Flight Episode Panel

This datasheet follows the *Datasheets for Datasets* framework (Gebru et al., 2021). It
documents the open dataset shipped in `data/`. **License: CC BY 4.0** (see `../LICENSE-DATA`).

## Files

| File | Rows | Description |
|---|---|---|
| `crisis_episodes.csv` | 79 episodes (17 verified + 62 estimated) | Full manuscript panel (Table 1 + Appendix D); used to calibrate and validate the crisis-dynamics model |
| `bis_concentration.csv` | — | Cross-country banking-concentration panel (calibration input) |
| `fred_digital_payments.csv` | — | Digital-payment adoption series (calibration input) |

## Motivation

- **Purpose.** To calibrate and *out-of-sample validate* a simulation of deposit-flight and
  failure dynamics, and to let independent researchers reproduce and critique that validation.
- **Gap addressed.** Most CBDC modelling lacks an explicit empirical anchor for outflow/failure
  dynamics. This panel provides one, with explicit reliability flags so the anchor's strength
  is transparent.

## Composition

- **Instances.** Each row is one historical episode (a bank or banking-system stress event),
  1984–2023.
- **Fields.** `episode, year, deposits_bn, peak_outflow, total_decline, failed,
  concentration, digital, severity, had_lolr, window_days, source, reliability`.
- **Label balance.** 56 failed / 23 survived — a **failure-dominant** panel (≈70.9% base rate).
  This imbalance is *material*: a naive "always predict failure" classifier scores ≈71–85%,
  so any reported classification accuracy MUST be read against that base rate (the paper does
  this explicitly).
- **Reliability flags** (the single most important column for honest use):
  - `verified` (17 episodes): primary-source calibrated (FDIC regulatory filings, BoE/ECB/FINMA/BIS
    disclosures, Icelandic SIC Report, peer-reviewed reconstructions; expanded per CHANGELOG v9.3.0).
  - `estimated` (62 episodes): FDIC/central-bank reconstructions; figures are *order-of-magnitude*
    estimates, not audited values. Reliability graded A/B/C in Appendix D.
  - `stylized` (2 episodes — in extended file only): counterfactual/illustrative cases — **must be excluded**
    from out-of-sample accuracy claims. LOO panel uses 26 episodes (28 base − 2 stylised).

## Collection process

- **Sources.** Public FDIC failure records, BIS working papers and statistics, central-bank
  financial-stability reports, and peer-reviewed case studies (e.g., WaMu 2008, IndyMac 2008,
  Northern Rock 2007, SVB 2023). The `source` column gives a short tag per row.
- **Sampling.** Convenience/purposive sampling of well-documented episodes; **not** a random
  or exhaustive sample of all bank failures. Selection bias toward large, well-reported events
  is expected and should be assumed.
- **Timeframe.** Episodes span 1984–2023; data compiled 2025–2026.

## Preprocessing / cleaning

- `peak_outflow`, `total_decline` normalised to deposit fractions.
- `severity`, `digital`, `concentration` are model-facing normalised covariates in [0, 1];
  for `estimated` rows these are reconstructed, not observed.
- No imputation of missing failure labels; `failed` is a hard 0/1 from the public record.

## Uses

- **Intended.** Calibration and leave-one-out validation of crisis-dynamics models; teaching;
  replication. The validated comparative-advantage of the model is **design ranking**, not
  point prediction of `peak_outflow` (LOO R² for peak is near zero — see paper §5.2).
- **Out of scope / cautions.** Do **not** use this panel to assert precise failure-probability
  forecasts, to train a deployed early-warning classifier, or to make claims about any
  individual institution. The `estimated` rows in particular are unsuitable for inferential
  point estimates without primary-source re-verification.

## Known limitations

1. Expanded `verified` core (n = 15, up from 13 in the prior revision) — still limited; verified-only OLS yields θ₂=0.7451 (p=0.0325, significant under the primary specification; not significant under the Appendix F alternative). Full panel n=81 required for statistical precision.
2. Failure-dominant imbalance (79%) inflates naive accuracy; always compare to base rate.
3. `estimated` covariates carry reconstruction error not quantified here.
4. Survivorship/reporting bias toward large, documented episodes.

## Maintenance

- **Versioning.** The dataset is versioned with the repository and archived per Zenodo release
  (DOI). Changes are tracked in the Git history of `data/`.
- **Contributions.** New episodes welcome via PR with a `source`, a `reliability` flag, and a
  primary-source URL — see `../CONTRIBUTING.md`.
- **Contact.** Open an issue using the "Scientific / reproducibility issue" template.

## Citation

> OFSR-CBDC Contributors (2026). Historical Bank-Run / Deposit-Flight Episode Panel (n=81).
> In *Open Financial Stability Research Platform for CBDC Design* (v10.0, manuscript-sync). CC BY 4.0.
> DOI: 10.5281/zenodo.XXXXXXX

## Extended panel (1984–2025) — `crisis_episodes_extended.csv`

A larger panel of **62 episodes** spanning 1984–2025 (45 failed / 17 survived; base rate ≈73%,
improved from the base panel's 79%). Composition: 8 verified · 52 estimated · 2 stylised.
Coverage includes the S&L crisis (1984–1992), the 2008–2010 FDIC failure wave, the European
sovereign/banking crises (2011–2013), the Icelandic bank collapses (2008), and the 2023
regional-bank / Credit Suisse episode. **All `episode`/`year`/`failed` values are real public
record (FDIC, central banks, FSB); covariates for `estimated` rows are reconstructions and must
be re-verified before inferential use.** A `merged` view (base ∪ extended, de-duplicated, 78
episodes) is produced by `engines/historical_loader.py`.

This panel enables k-fold, bootstrap, Monte-Carlo, and temporal external validation
(`engines/validation.py`) in addition to leave-one-out, and underpins the empirical
calibration in `engines/calibrate.py` (RMSE/MAE + bootstrap parameter CIs).
