# Open Dataset

CC BY 4.0 (see `../LICENSE-DATA`). Full provenance, reliability flags, and usage cautions are
in **[`DATASHEET.md`](DATASHEET.md)** — read it before any inferential use.

| File | Description |
|---|---|
| `crisis_episodes_extended.csv` | **62 episodes (1984–2025)**, 45 failed / 17 survived (base rate ≈73%). 8 verified · 52 estimated · 2 stylised. Enables k-fold/bootstrap/MC/external validation. |
| `crisis_episodes.csv` | 28 historical bank-run / deposit-flight episodes (1984–2023). 8 verified · 18 estimated · 2 stylised. 22 failed / 6 survived. |
| `bis_concentration.csv` | Cross-country banking-concentration panel (calibration input). |
| `fred_digital_payments.csv` | Digital-payment adoption series (calibration input). |

**Key honesty note.** The panel is failure-dominant (≈79% base rate). Any classification
accuracy must be compared against that base rate; the model's validated strength is CBDC
**design ranking**, not magnitude prediction (see paper §5.2 and the appendix).
