"""
_compat_pydantic — minimal, dependency-free fallback for the small subset of
pydantic v2 used by this package (BaseModel, Field, model_validator).

It is imported *only* when the real `pydantic` is unavailable, so that the core
simulation engine, calibration, and reproduction harness run in a clean
Python 3.11+ environment with just numpy/scipy/pandas. When pydantic is
installed, the package uses the real thing and this module is never loaded.

Supported features (all that params.py / results.py rely on):
  - class-level annotated fields with plain defaults or Field(default=...)
  - Field(default=..., ge=, le=, gt=, lt=, description=, default_factory=)
  - per-instance deep copy of mutable defaults (lists, BaseModel instances)
  - keyword-only construction with range validation (ge/le/gt/lt -> ValueError)
  - @model_validator(mode="after") hooks run after construction, may mutate self
  - @property accessors (native; nothing special needed)
"""
from __future__ import annotations
import copy as _copy
from typing import Any, Callable


class _FieldInfo:
    __slots__ = ("default", "default_factory", "ge", "le", "gt", "lt", "description")

    def __init__(self, default=..., *, default_factory=None, ge=None, le=None,
                 gt=None, lt=None, description=None, **_ignored):
        self.default = default
        self.default_factory = default_factory
        self.ge, self.le, self.gt, self.lt = ge, le, gt, lt
        self.description = description

    def has_default(self) -> bool:
        return self.default is not ... or self.default_factory is not None

    def make_default(self):
        if self.default_factory is not None:
            return self.default_factory()
        return _copy.deepcopy(self.default)


def Field(default=..., **kwargs):  # noqa: N802  (mirror pydantic name)
    return _FieldInfo(default, **kwargs)


def model_validator(*, mode: str = "after"):
    """Mark a method as an after-construction validator (only mode='after' used)."""
    def deco(fn: Callable):
        fn.__is_model_validator__ = True
        fn.__validator_mode__ = mode
        return fn
    return deco


def _collect_fields(cls) -> dict:
    """Walk MRO base-first so subclasses override; return {name: _FieldInfo|default}."""
    fields: dict[str, Any] = {}
    for klass in reversed(cls.__mro__):
        ann = klass.__dict__.get("__annotations__", {})
        for name in ann:
            if name.startswith("_"):
                continue
            default = klass.__dict__.get(name, ...)
            fields[name] = default
    return fields


class _BaseModelMeta(type):
    def __new__(mcs, name, bases, ns):
        cls = super().__new__(mcs, name, bases, ns)
        cls.__model_fields__ = _collect_fields(cls)
        validators = []
        for klass in cls.__mro__:
            for attr, val in klass.__dict__.items():
                if getattr(val, "__is_model_validator__", False):
                    validators.append(val)
        # de-dup preserving order
        seen = set(); uniq = []
        for v in validators:
            if v.__name__ not in seen:
                seen.add(v.__name__); uniq.append(v)
        cls.__model_validators__ = uniq
        return cls


def _validate_range(name, value, fi: _FieldInfo):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return
    if fi.ge is not None and value < fi.ge:
        raise ValueError(f"{name}={value} violates ge={fi.ge}")
    if fi.gt is not None and value <= fi.gt:
        raise ValueError(f"{name}={value} violates gt={fi.gt}")
    if fi.le is not None and value > fi.le:
        raise ValueError(f"{name}={value} violates le={fi.le}")
    if fi.lt is not None and value >= fi.lt:
        raise ValueError(f"{name}={value} violates lt={fi.lt}")


class BaseModel(metaclass=_BaseModelMeta):
    def __init__(self, **kwargs):
        unknown = set(kwargs) - set(self.__model_fields__)
        if unknown:
            raise TypeError(f"unexpected fields {unknown} for {type(self).__name__}")
        for name, default in self.__model_fields__.items():
            if name in kwargs:
                value = kwargs[name]
                if isinstance(default, _FieldInfo):
                    _validate_range(name, value, default)
            elif isinstance(default, _FieldInfo):
                if not default.has_default():
                    raise TypeError(f"missing required field '{name}' for {type(self).__name__}")
                value = default.make_default()
            elif default is ...:
                raise TypeError(f"missing required field '{name}' for {type(self).__name__}")
            else:
                value = _copy.deepcopy(default)
            object.__setattr__(self, name, value)
        for validator in self.__model_validators__:
            result = validator(self)
            if result is not None and result is not self:
                # 'after' validators conventionally return self
                pass

    # convenience parity with pydantic
    def model_dump(self) -> dict:
        return {n: getattr(self, n) for n in self.__model_fields__}

    dict = model_dump  # pydantic v1 alias used in a few spots

    def __repr__(self) -> str:
        inner = ", ".join(f"{n}={getattr(self, n)!r}" for n in self.__model_fields__)
        return f"{type(self).__name__}({inner})"
