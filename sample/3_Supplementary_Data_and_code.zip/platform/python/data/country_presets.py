"""
국가별 보정 프리셋 (calibration anchors).

각 국가의 에이전트 구성·디지털결제율·현금사용률·은행집중도·안정성 임계값을
선행연구/공식 통계 기준 중앙값으로 설정한다. 모든 값에 출처를 명시하며,
panel 엔진과 calibration 엔진이 공유한다.

출처 약어
─────────
[BIS-RB]  BIS CPMI Red Book Statistics (CT1/CT6 tables, 2018–2023)
[FRED]    Federal Reserve Economic Data — 디지털결제·현금사용 프록시 시리즈
[ECB-SPACE] ECB Study on Payment Attitudes of Consumers in the Euro area
[BOK]     한국은행 지급결제보고서 / 화폐수요 통계
[PBoC]    People's Bank of China Payment System Report
[Riksbank] Sveriges Riksbank Payments Report

※ 수치는 공표 통계의 근사 스냅샷이며, 논문 제출 전 원자료로 재확인할 것.
  (data/cache/*.csv 의 패널 시계열이 1차 근거, 아래 값은 단일연도 요약 앵커)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class AgentPreset:
    key: str
    name: str
    share: float
    digital: float
    risk: float


@dataclass(frozen=True)
class CountryPreset:
    key: str
    name: str
    # ── 실증 앵커 (calibration targets) ──
    digital: float        # 디지털결제 비중 (성인 인구 기준)
    cash: float           # 현금 결제/보유 비중
    concentration: float  # 상위 5개 은행 자산집중도 (CR5)
    density: float        # 은행간 네트워크 추정 밀도
    threshold: float      # 뱅크런 전환 안정성 임계값
    rate2: float          # 권고 tiered rate level-2 (%)
    rate3: float          # 권고 tiered rate level-3 (%)
    cap: float            # 권고 보유한도 (현지통화 → 원화 환산 근사)
    source: str           # 출처 노트
    agents: List[AgentPreset] = field(default_factory=list)


# ── 에이전트 구성: 국가별 고령화·디지털 침투·자산편중 반영 ────────────────────
def _agents(hh, firm, eld, dig, wlt, sme,
            hh_d, firm_d, eld_d, dig_d, wlt_d, sme_d) -> List[AgentPreset]:
    return [
        AgentPreset("household", "가계",          hh,   hh_d,  0.55),
        AgentPreset("firm",      "기업",          firm, firm_d, 0.65),
        AgentPreset("elderly",   "고령층",        eld,  eld_d, 0.25),
        AgentPreset("digital",   "디지털 친화층", dig,  dig_d, 0.80),
        AgentPreset("wealthy",   "고액자산가",    wlt,  wlt_d, 0.95),
        AgentPreset("sme",       "중소은행 고객", sme,  sme_d, 0.85),
    ]


COUNTRY_PRESETS: Dict[str, CountryPreset] = {
    "korea": CountryPreset(
        key="korea", name="대한민국",
        digital=0.92, cash=0.08, concentration=0.75, density=0.82,
        threshold=0.62, rate2=-1.5, rate3=-4.0, cap=20_000_000,
        source="[BOK] 2023 지급결제보고서 §4 · [BIS-RB] CT6 Korea",
        agents=_agents(0.35, 0.20, 0.15, 0.15, 0.08, 0.07,
                       0.65, 0.55, 0.30, 0.95, 0.75, 0.60),
    ),
    "eu": CountryPreset(
        key="eu", name="유로존(EU)",
        digital=0.73, cash=0.21, concentration=0.62, density=0.68,
        threshold=0.70, rate2=-1.0, rate3=-3.0, cap=4_000_000,   # ≈ €3,000 한도
        source="[ECB-SPACE] 2022 · [BIS-RB] CT6 Euro area",
        agents=_agents(0.34, 0.21, 0.18, 0.12, 0.08, 0.07,
                       0.58, 0.52, 0.26, 0.92, 0.70, 0.55),
    ),
    "china": CountryPreset(
        key="china", name="중국",
        digital=0.86, cash=0.13, concentration=0.58, density=0.74,
        threshold=0.66, rate2=-0.5, rate3=-2.0, cap=10_000_000,  # e-CNY 지갑 등급제
        source="[PBoC] 2023 Payment System Report · [BIS-RB] CT6 China",
        agents=_agents(0.33, 0.22, 0.16, 0.17, 0.07, 0.05,
                       0.78, 0.70, 0.42, 0.96, 0.80, 0.62),
    ),
    "us": CountryPreset(
        key="us", name="미국",
        digital=0.78, cash=0.16, concentration=0.48, density=0.60,
        threshold=0.74, rate2=-0.5, rate3=-2.5, cap=13_000_000,  # ≈ $10,000
        source="[FRED] DPANKR/payment proxies · [BIS-RB] CT6 US",
        agents=_agents(0.36, 0.19, 0.14, 0.14, 0.10, 0.07,
                       0.62, 0.58, 0.34, 0.93, 0.78, 0.58),
    ),
    "sweden": CountryPreset(
        key="sweden", name="스웨덴",
        digital=0.95, cash=0.04, concentration=0.81, density=0.86,
        threshold=0.60, rate2=-1.5, rate3=-4.0, cap=3_000_000,   # e-krona
        source="[Riksbank] 2022 Payments Report p.14 · [BIS-RB] CT6 Sweden",
        agents=_agents(0.34, 0.20, 0.13, 0.18, 0.08, 0.07,
                       0.70, 0.60, 0.38, 0.97, 0.82, 0.64),
    ),
}

# panel 비교의 기본 3개국 (사용자 요청: 한국/EU/중국)
DEFAULT_PANEL: List[str] = ["korea", "eu", "china"]
ALL_COUNTRIES: List[str] = list(COUNTRY_PRESETS.keys())
