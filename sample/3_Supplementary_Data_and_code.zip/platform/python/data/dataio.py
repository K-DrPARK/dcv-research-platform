"""
실데이터 수집 모듈 — FRED (pandas_datareader) + BIS CPMI Red Book.

설계 원칙
─────────
1. 온라인이면 실시간 수집(pandas_datareader.DataReader, source="fred").
2. 네트워크/패키지 부재 시 data/cache/*.csv 스냅샷으로 graceful fallback.
3. 모든 반환에 provenance(출처·시각·온라인여부)를 부착해 재현성 확보.

연구 재현성을 위해 캐시는 1차 근거이며, 온라인 수집분은 캐시를 갱신한다.
오프라인 환경(CI·심사위원 재현)에서도 동일 결과가 나오도록 캐시를 동봉한다.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

_CACHE_DIR = Path(__file__).parent / "cache"

# pandas_datareader 는 선택적 의존성 (오프라인에서도 동작)
try:
    import pandas_datareader.data as web   # noqa: F401
    _HAS_PDR = True
except Exception:
    _HAS_PDR = False


# 국가 → FRED 디지털결제/현금 프록시 시리즈 ID (온라인 수집용).
# 단일 공식 "디지털결제율" 시리즈가 없으므로 프록시(전자결제건수·현금비중 등)를
# 정규화해 사용한다. 오프라인이면 캐시 패널을 그대로 쓴다.
_FRED_DIGITAL_SERIES: Dict[str, List[str]] = {
    "us":     ["DPANKR"],          # 예시 프록시 (실제 ID는 환경에 맞게 교체)
    "korea":  [],                  # 공식 FRED 시리즈 부재 → 캐시 사용
    "eu":     [],
    "china":  [],
    "sweden": [],
}


@dataclass
class Provenance:
    source:    str
    online:    bool
    fetched_at: str
    note:      str


@dataclass
class PanelData:
    """국가×연도 패널 + provenance."""
    frame:      pd.DataFrame          # columns: country, year, value, ...
    provenance: Provenance

    def to_dict(self) -> dict:
        return {
            "rows": self.frame.to_dict(orient="records"),
            "provenance": asdict(self.provenance),
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ── FRED ──────────────────────────────────────────────────────────────────────
class FredClient:
    """
    FRED 디지털결제·현금 비중 수집기.

    get_digital_panel() → 국가×연도 디지털결제 비중 패널.
    온라인이면 시리즈를 받아 캐시를 갱신하고, 아니면 캐시를 읽는다.
    """

    def __init__(self, cache_dir: Path = _CACHE_DIR):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_file = self.cache_dir / "fred_digital_payments.csv"

    def _read_cache(self) -> pd.DataFrame:
        df = pd.read_csv(self._cache_file, comment="#")
        return df

    def get_digital_panel(self, countries: Optional[List[str]] = None) -> PanelData:
        df = self._read_cache()
        online = False
        note = "offline cache (재현용 스냅샷)"

        if _HAS_PDR:
            # 온라인 시도: 시리즈가 정의된 국가만 갱신
            updated = []
            for c, series_ids in _FRED_DIGITAL_SERIES.items():
                for sid in series_ids:
                    try:
                        s = web.DataReader(sid, "fred")   # type: ignore[name-defined]
                        yearly = s.resample("YE").mean().iloc[:, 0]
                        norm = (yearly - yearly.min()) / (yearly.max() - yearly.min() + 1e-9)
                        for ts, v in norm.items():
                            updated.append({"country": c, "year": ts.year,
                                             "digital_share": round(float(v), 4),
                                             "cash_share": round(1 - float(v), 4),
                                             "fred_series": sid, "note": "online"})
                    except Exception:
                        continue
            if updated:
                online = True
                note = "online FRED + cache merge"
                up = pd.DataFrame(updated)
                df = (pd.concat([df, up], ignore_index=True)
                        .drop_duplicates(["country", "year"], keep="last"))
                df.to_csv(self._cache_file, index=False)

        if countries:
            df = df[df["country"].isin(countries)].reset_index(drop=True)

        return PanelData(
            frame=df,
            provenance=Provenance("FRED", online, _now(), note),
        )


# ── BIS CPMI Red Book ─────────────────────────────────────────────────────────
class BisClient:
    """
    BIS CPMI Red Book 은행 자산집중도(CR5/HHI) 수집기.

    BIS 통계는 공개 API가 제한적이므로 캐시 스냅샷을 1차 근거로 사용한다.
    온라인 BIS SDMX 엔드포인트가 환경에 설정되면 _try_online()을 확장한다.
    """

    def __init__(self, cache_dir: Path = _CACHE_DIR):
        self.cache_dir = cache_dir
        self._cache_file = self.cache_dir / "bis_concentration.csv"

    def get_concentration_panel(self, countries: Optional[List[str]] = None) -> PanelData:
        df = pd.read_csv(self._cache_file, comment="#")
        if countries:
            df = df[df["country"].isin(countries)].reset_index(drop=True)
        return PanelData(
            frame=df,
            provenance=Provenance(
                "BIS CPMI Red Book (CT6)", False, _now(),
                "offline cache (재현용 스냅샷; 제출 전 Red Book 원자료 재확인)",
            ),
        )


# ── 통합 패널 빌더 ────────────────────────────────────────────────────────────
def build_empirical_panel(countries: Optional[List[str]] = None) -> pd.DataFrame:
    """
    FRED 디지털결제 + BIS 집중도를 country×year 로 병합한 실증 패널.
    calibration 엔진의 1차 입력.
    """
    fred = FredClient().get_digital_panel(countries)
    bis  = BisClient().get_concentration_panel(countries)
    merged = pd.merge(
        fred.frame[["country", "year", "digital_share", "cash_share"]],
        bis.frame[["country", "year", "cr5", "hhi"]],
        on=["country", "year"], how="inner",
    )
    merged.attrs["provenance"] = {
        "fred": asdict(fred.provenance),
        "bis":  asdict(bis.provenance),
    }
    return merged
