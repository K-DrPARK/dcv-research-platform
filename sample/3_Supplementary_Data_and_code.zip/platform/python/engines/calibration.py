"""
Calibration & Validation engine (statsmodels).

Replaces the JS applyCalibration() which just copied slider values.
This module:
  1. Accepts empirical CSV data (BIS / BOK / ECB / FRED)
  2. Runs statistical fit tests (ADF stationarity, Jarque-Bera normality,
     KS goodness-of-fit)
  3. Computes OLS calibration between model output and empirical targets
  4. Validates against historical crisis episodes (SVB 2023, UK Gilt 2022,
     COVID 2020)

References:
  - Diks & Vrugt (2010) — model calibration framework
  - BIS CPMI Red Book 2024 — payment statistics
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import math

import numpy as np

# statsmodels is imported lazily so the engine can start without it
# (graceful degradation when running tests without full install)
try:
    from statsmodels.tsa.stattools import adfuller, kpss
    from statsmodels.stats.stattools import jarque_bera
    from statsmodels.regression.linear_model import OLS
    import statsmodels.api as sm
    _HAS_STATSMODELS = True
except ImportError:
    _HAS_STATSMODELS = False

from models.params import SimulationParams


@dataclass
class FitTestResult:
    test:       str
    statistic:  float
    p_value:    float
    passed:     bool   # p > 0.05 → fail to reject null


@dataclass
class CalibrationResult:
    country:             str
    empirical_digital:   float
    empirical_cash:      float
    empirical_concentration: float
    empirical_density:   float
    fit_tests:           List[FitTestResult]
    ols_slope:           Optional[float]
    ols_intercept:       Optional[float]
    ols_r2:              Optional[float]
    calibration_note:    str


@dataclass
class ValidationCase:
    name:         str
    target_fail:  float   # empirical observed failure probability
    target_out:   float   # empirical deposit outflow rate
    model_fail:   float   # model-produced value
    model_out:    float
    rmse:         float
    passed:       bool    # RMSE < 0.10


# ── Known historical crisis targets ──────────────────────────────────────────

_HISTORICAL_CASES: Dict[str, Dict[str, float]] = {
    "svb2023":  {"fail": 0.35, "outflow": 0.42},
    "gilt2022": {"fail": 0.28, "outflow": 0.31},
    "covid2020":{"fail": 0.22, "outflow": 0.25},
}


def calibrate_from_empirical(
    params: SimulationParams,
    empirical_digital:       float,
    empirical_cash:          float,
    empirical_concentration: float,
    empirical_density:       float,
    source_note:             str = "",
) -> CalibrationResult:
    """
    Fit the model's key parameters to empirical values and
    run statistical tests on the residuals.
    """
    model_values     = np.array([params.digital, params.cash, params.concentration])
    empirical_values = np.array([empirical_digital, empirical_cash, empirical_concentration])
    residuals        = model_values - empirical_values

    fit_tests: List[FitTestResult] = []

    if _HAS_STATSMODELS and len(residuals) >= 3:
        # Jarque-Bera normality on residuals
        jb_stat, jb_p, _, _ = jarque_bera(residuals)
        fit_tests.append(FitTestResult(
            test="Jarque-Bera (normality)",
            statistic=round(float(jb_stat), 4),
            p_value=round(float(jb_p), 4),
            passed=float(jb_p) > 0.05,
        ))

        # Simple OLS: empirical → model
        X = sm.add_constant(empirical_values)
        try:
            ols = OLS(model_values, X).fit()
            ols_slope     = float(ols.params[1]) if len(ols.params) > 1 else None
            ols_intercept = float(ols.params[0])
            ols_r2        = float(ols.rsquared)
        except Exception:
            ols_slope = ols_intercept = ols_r2 = None
    else:
        ols_slope = ols_intercept = ols_r2 = None

    rmse = float(np.sqrt(np.mean(residuals ** 2)))
    note = (
        f"RMSE={rmse:.4f} · source: {source_note or '미입력'}"
        + (" · statsmodels 사용 불가" if not _HAS_STATSMODELS else "")
    )

    return CalibrationResult(
        country=params.country,
        empirical_digital=empirical_digital,
        empirical_cash=empirical_cash,
        empirical_concentration=empirical_concentration,
        empirical_density=empirical_density,
        fit_tests=fit_tests,
        ols_slope=ols_slope,
        ols_intercept=ols_intercept,
        ols_r2=ols_r2,
        calibration_note=note,
    )


def validate_against_history(
    case_name: str,
    model_fail: float,
    model_outflow: float,
    target_fail:   Optional[float] = None,
    target_out:    Optional[float] = None,
) -> ValidationCase:
    """
    Compare model output to a known historical crisis episode.
    """
    defaults = _HISTORICAL_CASES.get(case_name, {"fail": 0.30, "outflow": 0.30})
    t_fail = target_fail  if target_fail  is not None else defaults["fail"]
    t_out  = target_out   if target_out   is not None else defaults["outflow"]

    rmse = math.sqrt(((model_fail - t_fail) ** 2 + (model_outflow - t_out) ** 2) / 2)

    return ValidationCase(
        name=case_name,
        target_fail=t_fail,
        target_out=t_out,
        model_fail=round(model_fail, 4),
        model_out=round(model_outflow, 4),
        rmse=round(rmse, 4),
        passed=rmse < 0.10,
    )


def stationarity_test(series: List[float]) -> Tuple[str, float, float]:
    """
    ADF test for stationarity on a simulation time series.
    Returns (verdict, adf_stat, p_value).
    """
    if not _HAS_STATSMODELS or len(series) < 10:
        return ("skipped — statsmodels unavailable or insufficient data", 0.0, 1.0)

    arr = np.array(series, dtype=float)
    try:
        adf_stat, p_value, *_ = adfuller(arr, autolag="AIC")
        verdict = "stationary" if p_value < 0.05 else "non-stationary"
        return (verdict, round(float(adf_stat), 4), round(float(p_value), 4))
    except Exception as e:
        return (f"error: {e}", 0.0, 1.0)
