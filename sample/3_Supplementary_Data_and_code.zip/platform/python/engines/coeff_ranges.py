"""
계수 불확실성 레지스트리 (coefficient priors).

core.py 의 _COEFF 는 "인용 범위의 중앙값"을 점추정으로 쓴다. 본 모듈은 그
범위 정보를 복원하여 (low, point, high) 삼각분포 사전으로 표현하고, 진짜
구조적 Monte Carlo(engines.mc_structural)의 불확실성 원천으로 사용한다.

- cited=True  : 원문 주석에 명시된 범위 (예: [0.28, 0.42]).
- cited=False : 원문에 단일 추정치만 있어 ±로 보수적 범위를 부여한 항목.
                (논문에는 '저자 가정'으로 별도 표기할 것)

삼각분포를 쓰는 이유: 전문가 유도(expert-elicited) 구간 + 최빈값이 주어진
표준적 불확실성 표현(PERT/triangular). 균등분포보다 중앙 추정에 질량을 둔다.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np


@dataclass(frozen=True)
class CoeffPrior:
    point: float
    low:   float
    high:  float
    cited: bool          # 원문에 범위가 명시되어 있는가
    note:  str = ""


# point 는 core._COEFF 와 일치해야 한다 (= 범위 중앙/최빈값).
COEFF_PRIORS: Dict[str, CoeffPrior] = {
    # ── 예금이탈 ──
    "BASELINE_DIGITAL_EPS":        CoeffPrior(0.05, 0.03, 0.08, False, "Eq.1 baseline ε (저자보정)"),
    "BASELINE_RISK_ZETA":          CoeffPrior(0.05, 0.03, 0.08, False, "Eq.1 baseline ζ (저자보정)"),
    "OUTFLOW_DIGITAL_SENSITIVITY": CoeffPrior(0.35, 0.28, 0.42, True,  "[KN21] Kumhof & Noone (2021), holding-limit design (re-attributed from ACF22 per independent citation-verification protocol, manuscript §3.8)"),
    "OUTFLOW_RISK_SENSITIVITY":    CoeffPrior(0.16, 0.12, 0.20, True,  "[KN21] Table 2"),
    "OUTFLOW_CAP_BASE":            CoeffPrior(0.05, 0.04, 0.06, True,  "[BOK23] §4.2 기저상수 (B1수정)"),
    "OUTFLOW_CAP_SLOPE":           CoeffPrior(0.06, 0.05, 0.08, True,  "[BOK23] §4.2 slope (B1수정)"),
    "OUTFLOW_CASH_BUFFER":         CoeffPrior(0.35, 0.30, 0.40, True,  "[KN21] Kumhof & Noone (2021), disintermediation analysis (re-attributed from ACF22 per independent citation-verification protocol, manuscript §3.8)"),
    # ── 신규 정책수단 효과 계수 (E, author-calibrated; cited=False) ──────────
    "CBDC_TAX_ELASTICITY":         CoeffPrior(5.0,  3.0,  7.0,  False, "보유세 이탈완화 탄력 (저자보정)"),
    "CBDC_EXPIRATION_DAMP":        CoeffPrior(0.10, 0.05, 0.15, False, "만료형 비축억제 (저자보정)"),
    "CBDC_PROGRAMMABLE_DAMP":      CoeffPrior(0.22, 0.15, 0.30, False, "조건부 한도 패닉완화 (저자보정)"),
    "CBDC_OFFLINE_AMP":            CoeffPrior(0.06, 0.03, 0.10, False, "오프라인 위기이탈 회복력 (저자보정)"),
    "TIER_RATE2_ELASTICITY":       CoeffPrior(0.045, 0.04, 0.05, True, "[KN21] p.572"),
    "TIER_RATE3_ELASTICITY":       CoeffPrior(0.025, 0.020, 0.030, False, "단일 추정치→±20%"),
    # ── 시스템 취약성 ──
    "FRAG_CONCENTRATION":          CoeffPrior(0.25, 0.20, 0.30, True,  "[NW07] Table 1"),
    "FRAG_DENSITY":                CoeffPrior(0.18, 0.15, 0.22, True,  "[GK10] Fig.3"),
    "FRAG_OUTFLOW_AMPLIFIER":      CoeffPrior(0.55, 0.50, 0.62, False, "author-calibrated; BP09 liquidity-spiral concept (Eq.10 is margin spiral, not retail deposit)"),
    "FRAG_SHOCK_DIRECT":           CoeffPrior(0.18, 0.15, 0.22, False, "author-calibrated; ACF22 shock propagation concept (Table 4 not directly verified)"),
    # ── 스트레스 ──
    "STRESS_OUTFLOW_WEIGHT":       CoeffPrior(0.58, 0.52, 0.65, False, "author-calibrated; BP09 funding-liquidity concept (Eq.8 is dealer margin model)"),
    "STRESS_FRAG_WEIGHT":          CoeffPrior(0.32, 0.28, 0.36, True,  "[GK10] Eq.(3)"),
    "STRESS_SHOCK_NET_WEIGHT":     CoeffPrior(0.25, 0.20, 0.30, True,  "[NW07] p.2045"),
    "STRESS_OPER_WEIGHT":          CoeffPrior(0.18, 0.14, 0.22, True,  "[BIS21] Box 2"),
    # ── 안정성 시그모이드 ──
    # k=13: author-calibrated. 전환구간≈0.71 (k=10→0.92, k=15→0.61)
    # 구 주석 "[ECB12] 전환구간 0.15"는 수학 오류로 삭제 (ln(99)/0.15=30.6≠12.6)
    "STABILITY_SIGMOID_K":         CoeffPrior(13.0, 10.0, 15.0, False, "author-calibrated: 전환구간≈0.71; Nier et al.(2007) threshold concept"),
    # ── 실패 전파 ──
    "FAIL_NEW_RATE":               CoeffPrior(0.30, 0.25, 0.35, True,  "[GK10] Eq.(5)"),
    "FAIL_CASCADE_RATE":           CoeffPrior(0.018, 0.015, 0.022, True, "[GK10] p.2408"),
    "FAIL_STABILITY_BUFFER":       CoeffPrior(0.12, 0.10, 0.14, False, "단일 추정치→±20%"),
    # ③ 수정: 은행 실패율 상한 [NW07] Fig.4 실증 범위
    "FAIL_MAX":                    CoeffPrior(0.65, 0.55, 0.75, True,  "[NW07] Fig.4 cascade 상한"),
    # ⑤ 추가: network_density + disinter
    "NETWORK_DENSITY_KR":          CoeffPrior(0.82, 0.78, 0.86, True,  "[BOK23] §2.1"),
    "NETWORK_DENSITY_US":          CoeffPrior(0.65, 0.60, 0.70, True,  "[BIS21] Box 1"),
    "NETWORK_DENSITY_DEFAULT":     CoeffPrior(0.70, 0.65, 0.75, True,  "[BIS21] Box 1 평균"),
    "DISINTER_OUTFLOW_COEFF":      CoeffPrior(0.95, 0.90, 1.00, True,  "[KN21] p.574"),
    # ── LOLR ──
    "LOLR_STRESS_TRIGGER":         CoeffPrior(0.45, 0.40, 0.60, True,  "[BIS21] §3; v6 recalibrated to 0.45 (below BIS21 midpoint 0.55) to match two-channel crisis stress regime"),
    "LOLR_AMOUNT_ELASTICITY":      CoeffPrior(0.55, 0.50, 0.60, True,  "[BIS21] Eq.(4)"),
    "LOLR_FAIL_REDUCTION":         CoeffPrior(0.23, 0.20, 0.27, True,  "[BIS21] Table 5"),
    "LOLR_STABILITY_BOOST":        CoeffPrior(0.35, 0.30, 0.40, True,  "[BIS21] Table 5"),
    # ── Fire sale ──
    "FIRESALE_STABILITY_IMPACT":   CoeffPrior(0.15, 0.12, 0.18, True,  "[BP09] Eq.(12)"),
    "FIRESALE_STRESS_AMPLIFY":     CoeffPrior(0.10, 0.08, 0.13, True,  "[BP09] Eq.(12)"),
    # ── 후생 ──
    "WELFARE_PAYEFF_BASE":         CoeffPrior(0.35, 0.30, 0.40, True,  "[RAM20] Eq.(7)"),
    "WELFARE_PAYEFF_OUTFLOW":      CoeffPrior(0.90, 0.85, 0.95, True,  "[RAM20] Eq.(7)"),
    "WELFARE_PAYEFF_DIGITAL":      CoeffPrior(0.25, 0.20, 0.30, True,  "[ACF22] p.18"),
    "WELFARE_INCLUSION_BASE":      CoeffPrior(0.20, 0.15, 0.25, True,  "[KN21] p.580"),
    "WELFARE_INCLUSION_DIGITAL":   CoeffPrior(0.35, 0.30, 0.40, True,  "[KN21] p.580"),
    "WELFARE_INCLUSION_CASH":      CoeffPrior(0.20, 0.15, 0.25, True,  "[KN21] p.580"),
    "WELFARE_INNOV_BASE":          CoeffPrior(0.25, 0.20, 0.30, False, "author-calibrated; ACF22 innovation welfare concept (Table 6 not directly verified)"),
    "WELFARE_INNOV_CAP":           CoeffPrior(0.22, 0.18, 0.26, False, "author-calibrated; ACF22 Table 6 not directly verified"),
    "WELFARE_INNOV_DIGITAL":       CoeffPrior(0.25, 0.20, 0.30, False, "author-calibrated; ACF22 Table 6 not directly verified"),
    "WELFARE_RISK_FAIL_WEIGHT":    CoeffPrior(0.70, 0.65, 0.75, True,  "[BIS21] §4"),
    "WELFARE_OPER_SHOCK":          CoeffPrior(0.20, 0.15, 0.25, True,  "[KN21] p.575"),
    # ── Dynamic cap / shock wave / ABM (단일 추정치 → 보수적 범위) ──
    "DYNCAP_TRIGGER_L1":           CoeffPrior(0.22, 0.18, 0.26, False, "[KN21] Table 3 (단일)"),
    "DYNCAP_TRIGGER_L2":           CoeffPrior(0.32, 0.28, 0.36, False, "[KN21] Table 3 (단일)"),
    "DYNCAP_FAIL_TRIGGER":         CoeffPrior(0.08, 0.06, 0.10, False, "[KN21] Table 3 (단일)"),
    "SHOCK_WAVE_LAMBDA":           CoeffPrior(5.0, 4.0, 6.0, False,   "[ACF22] Fig.2 (단일)"),
    "ABM_FEEDBACK_WEIGHT":         CoeffPrior(0.25, 0.20, 0.35, True,  "[ACF22] p.22"),
}


def sample_coeffs(rng: np.random.Generator,
                  base: Optional[Dict[str, float]] = None,
                  only_cited: bool = False) -> Dict[str, float]:
    """
    삼각분포에서 계수 1 draw 를 샘플링.
    base(=core._COEFF) 의 모든 키를 포함하되, 사전이 정의된 키만 흔든다.
    only_cited=True 면 원문 범위가 명시된(cited) 계수만 흔들고 나머지는 고정.
    """
    out: Dict[str, float] = dict(base) if base else {}
    for name, pr in COEFF_PRIORS.items():
        if only_cited and not pr.cited:
            out[name] = pr.point
            continue
        out[name] = float(rng.triangular(pr.low, pr.point, pr.high))
    return out


def n_uncertain(only_cited: bool = False) -> int:
    return sum(1 for p in COEFF_PRIORS.values() if (p.cited or not only_cited))
