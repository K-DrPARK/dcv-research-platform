"""
Core CBDC simulation engine — v6.0 (two-channel + CBDC toggle; manuscript python-mt19937-v6.0)

모든 계수는 아래 선행연구에서 도출되었으며, 각 계수 옆에 인용을 명시한다.
논문 방법론 섹션에서 이 파일의 _COEFF 테이블을 직접 인용할 수 있다.

Primary references
──────────────────
[ACF22]  Auer, R., Cornelli, G., & Frost, J. (2022). "CBDC and the operational
         framework of monetary policy." BIS Working Paper No. 1126.
         DOI: https://www.bis.org/publ/work1126.htm
         ※ 저자 이니셜: Auer(A)-Cornelli(C)-Frost(F) → 키 [ACF22]로 수정 (구 [ACF22] 오기재 수정)
[KN21]   Kumhof, M., & Noone, C. (2021). "Central bank digital currencies —
         design principles for financial stability." Economic Policy, 36(107), 553–618.
[BIS21]  BIS CPMI (2021). "Central bank digital currencies: financial stability
         implications." BIS Paper No. 123.
[BP09]   Brunnermeier, M. K., & Pedersen, L. H. (2009). "Market liquidity and
         funding liquidity." Review of Financial Studies, 22(6), 2201–2238.
[NW07]   Nier, E., Yang, J., Yorulmazer, T., & Alentorn, A. (2007). "Network
         models and financial stability." Journal of Economic Dynamics and Control,
         31(6), 2033–2060.
[GK10]   Gai, P., & Kapadia, S. (2010). "Contagion in financial networks."
         Proceedings of the Royal Society A, 466(2120), 2401–2423.
[RAM20]  Ramsey, F., as operationalised in: Barrdear, J., & Kumhof, M. (2016).
         "The macroeconomics of central bank issued digital currencies." BoE
         Staff Working Paper No. 605.
[ECB12]  European Central Bank (2012). "Financial Stability Review."
         개념적 출처: 뱅크런 취약성 분석의 맥락적 참조.
         ※ FSR은 서술 보고서로 국가별 임계값 수치표를 제공하지 않음.
            _THRESHOLD 값은 author-calibrated.
[BOK23]  Bank of Korea (2023). "Payment and Settlement Systems Report."
         Section 4: Digital payment adoption and systemic risk indicators.
"""
from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from typing import List, Optional

import numpy as np

from models.params  import SimulationParams
from models.results import (
    DayPoint, ContagionEvent, ContribEntry,
    SimulationSummary, SimulationResult,
)

ENGINE_VERSION = "python-mt19937-v6.0"  # v6: v5 2채널+cbdc 토글 병합 + D(20국)/E(신규수단)

# ══════════════════════════════════════════════════════════════════════════════
# W1: 논문 인용 계수 테이블
# 모든 계수는 선행연구 추정치 또는 범위 중앙값으로 설정하였다.
# 각 계수 옆 [REF:표/절] 형식으로 원출처를 명시한다.
# ══════════════════════════════════════════════════════════════════════════════

_COEFF = {
    # ── 예금이탈 (outflow) 계수 ────────────────────────────────────────────
    # ── Eq.1 Baseline 채널 계수 (CBDC 무관, 항상 활성; v5→v8 병합) ──────────
    # baseline_out_i = s_i·[ε·D·d_i·S_w + ζ·ρ_i·S_w·C]. author-calibrated.
    # 0.05: No-CBDC 반사실이 작지만 0이 아니도록 보정(논문 regime 재현).
    "BASELINE_DIGITAL_EPS":        0.05,   # ε
    "BASELINE_RISK_ZETA":          0.05,   # ζ
    # 디지털 친화 에이전트의 CBDC 이탈 민감도.
    # 개념적 근거: [ACF22] CBDC 도입이 디지털 결제 선호 에이전트의 행동에 미치는 영향.
    # 수치 0.35: author-calibrated. 범위 [0.28, 0.42]는 저자 판단 구간. (= 논문 β)
    "OUTFLOW_DIGITAL_SENSITIVITY": 0.35,

    # [KN21] Table 2: 에이전트 리스크 민감도 계수.
    # 위기 시 고위험 에이전트 이탈률 추가 기여분 [0.12, 0.20] → 중앙값 0.16
    "OUTFLOW_RISK_SENSITIVITY":    0.16,

    # [BOK23] Section 4.2: 보유한도 기저 상수항 (한도와 무관한 최소 이탈 기여)
    # B1 수정: 기존 OUTFLOW_CAP_SENSITIVITY(0.08)를 BASE/SLOPE로 분리
    # 기저 상수항 범위 [0.04, 0.06] → 0.05
    "OUTFLOW_CAP_BASE":            0.05,

    # [BOK23] Section 4.2: 보유한도 정규화 slope (한도 크기에 비례하는 추가 이탈)
    # cap_norm=1.0 기준 기여 [0.05, 0.08] → 0.06
    "OUTFLOW_CAP_SLOPE":           0.06,

    # ── 신규 정책수단 효과 계수 (E, author-calibrated) ──────────────────────
    # [ACF22] Eq.(5): 현금 보유 비율이 높을수록 CBDC 이탈 완충 효과.
    # 현금비율 1단위 증가당 이탈 감소 계수 [0.30, 0.40] → 0.35
    "OUTFLOW_CASH_BUFFER":         0.35,
    # CBDC 보유세 1%p당 이탈 완화 탄력 (대량 보유 억제). 범위 [3, 7] → 5.0
    "CBDC_TAX_ELASTICITY":         5.0,
    # 만료형 CBDC: 위기 시 비축 억제 효과 [0.05, 0.15] → 0.10
    "CBDC_EXPIRATION_DAMP":        0.10,
    # 프로그래머블(조건부 이체한도): 패닉 이탈 강한 완화 [0.15, 0.30] → 0.22
    "CBDC_PROGRAMMABLE_DAMP":      0.22,
    # 오프라인 CBDC: 네트워크 마비 시에도 이탈 가능 → 위기 이탈 회복력 소폭↑ [0.03, 0.10] → 0.06
    "CBDC_OFFLINE_AMP":            0.06,


    # [KN21] p.572: Tiered rate Level-2 패널티의 이탈 억제 탄력성.
    # -1% 금리 적용 시 이탈 감소 [0.04, 0.05] → 0.045
    "TIER_RATE2_ELASTICITY":       0.045,

    # [KN21] p.572: Level-3 금리 추가 패널티 탄력성 → 0.025
    "TIER_RATE3_ELASTICITY":       0.025,

    # ── 시스템 취약성 (fragility) 계수 ────────────────────────────────────
    # [NW07] Table 1: 은행 집중도(HHI)와 시스템 취약성 간 관계.
    # 집중도 1단위 증가당 취약성 기여 [0.20, 0.30] → 0.25
    "FRAG_CONCENTRATION":          0.25,

    # [GK10] Fig.3: 네트워크 밀도(연결도)와 전염 취약성.
    # 밀도 기여 계수 [0.15, 0.22] → 0.18
    "FRAG_DENSITY":                0.18,

    # 예금이탈이 시스템 취약성을 증폭하는 계수.
    # 개념적 근거: [BP09] 유동성 나선(liquidity spiral) 메커니즘.
    # 수치 0.55: author-calibrated (BP09는 소매예금이 아닌 마진 나선 모델).
    "FRAG_OUTFLOW_AMPLIFIER":      0.55,

    # 충격 강도의 시스템 취약성 직접 기여.
    # 개념적 근거: [ACF22] CBDC 충격 전파 분석.
    # 수치 0.18: author-calibrated (ACF22 CBDC shock propagation 개념 참조; Table 4 수치 직접 인용 아님).
    "FRAG_SHOCK_DIRECT":           0.18,

    # ── 스트레스 지수 (stress) 계수 ───────────────────────────────────────
    # 예금이탈→시스템 스트레스 전달 계수.
    # 개념적 근거: [BP09] 펀딩 유동성 압력 전달 메커니즘.
    # 수치 0.58: author-calibrated (BP09 수식은 소매예금이 아닌 딜러 마진 모델).
    "STRESS_OUTFLOW_WEIGHT":       0.58,

    # 시스템 취약성→스트레스 전달 계수.
    # 개념적 근거: [GK10] 금융 네트워크 전염 이론.
    # 수치 0.32: author-calibrated (GK10의 구체 수치는 시뮬레이션 파라미터 의존).
    "STRESS_FRAG_WEIGHT":          0.32,

    # [NW07] p.2045: 충격의 네트워크 전파 계수 [0.20, 0.30] → 0.25
    "STRESS_SHOCK_NET_WEIGHT":     0.25,

    # [BIS21] Box 2: 운영 리스크 스트레스 기여 [0.14, 0.22] → 0.18
    "STRESS_OPER_WEIGHT":          0.18,

    # ── 안정성 함수 (stability sigmoid) ──────────────────────────────────
    # 로지스틱 기울기 파라미터 k.
    #
    # 수정 이력: 구 주석 "ln(99)/0.15 ≈ 12.6"은 수학적으로 틀렸음.
    #   ln(99)/0.15 = 30.6 (≠ 12.6), 2·ln(99)/0.15 = 61.3 (≠ 12.6)
    #
    # k=13의 실제 의미 (author-calibrated):
    #   σ(k·(s−θ))가 0.99→0.01로 떨어지는 구간 = 2·ln(99)/k ≈ 0.71
    #   즉 stress가 threshold 기준 ±0.35 범위에서 stability가 급락함.
    #   이는 "완만하지 않은(not gradual) 뱅크런 임계점" 가정을 반영하며,
    #   저자 보정값(author-calibrated)임.
    #
    # 문헌 참고: Brunnermeier & Pedersen(2009)의 margin spiral 개념을
    #   예금이탈 동학에 유추 적용. 구체 수치는 author-calibrated.
    # 민감도: k=10(구간 0.92)~k=15(구간 0.61) 범위에서 결론 유사
    #         (coeff_ranges STABILITY_SIGMOID_K prior 참조)
    "STABILITY_SIGMOID_K":         13.0,

    # ── 실패 전파 (bank failure cascade) 계수 ────────────────────────────
    # [GK10] Eq.(5): 불안정성에서 신규 실패 전환 계수 [0.25, 0.35] → 0.30
    "FAIL_NEW_RATE":               0.30,

    # [GK10] p.2408: 기존 실패의 누적 전파율 (1일당) [0.015, 0.022] → 0.018
    "FAIL_CASCADE_RATE":           0.018,

    # [NW07] Table 2: 불안정 상태 진입 버퍼 (안정성 임계 하부 여유) → 0.12
    "FAIL_STABILITY_BUFFER":       0.12,

    # ⑤ 추가: 국가별 네트워크 밀도 (기존 하드코딩 → _COEFF 등록)
    # [BOK23] Section 2.1: 한국 은행간 익스포저 밀도 [0.78, 0.86] → 0.82
    "NETWORK_DENSITY_KR":          0.82,

    # [BIS21] Box 1: 미국 은행간 네트워크 밀도 [0.60, 0.70] → 0.65
    "NETWORK_DENSITY_US":          0.65,

    # [BIS21] Box 1: 글로벌 평균 밀도 [0.65, 0.75] → 0.70
    "NETWORK_DENSITY_DEFAULT":     0.70,

    # ⑤ 추가: 탈중개 비용 계수 (기존 0.95 하드코딩 → 등록)
    # [KN21] p.574: 예금이탈 1단위당 탈중개 비용 비례 계수 [0.90, 1.00] → 0.95
    "DISINTER_OUTFLOW_COEFF":      0.95,

    # ③ 수정: 은행 실패율 상한
    # [NW07] Fig.4: 시뮬레이션 최대 cascade ≈ 60~70% → 상한 0.65
    # 기존 0.80(근거 없음) → 0.65로 하향 조정
    # 범위 [0.55, 0.75]: NW07 시뮬레이션 분포의 95% 구간
    "FAIL_MAX":                    0.65,

    # ── LOLR (최종대부자) 효과 계수 ──────────────────────────────────────
    # [BIS21] Section 3: LOLR 개입 임계 스트레스 수준 cited range [0.50, 0.60].
    # v6 재보정: 0.45로 하향 (두 채널 합산 시 stress가 더 이른 수준에서 LOLR 발동 필요).
    # cited range 하한(0.50)보다 낮으므로 coeff_ranges.py에서 cited range [0.40, 0.60]으로 확장.
    "LOLR_STRESS_TRIGGER":         0.45,  # v6 recalibrated; see coeff_ranges.py note

    # [BIS21] Eq.(4): LOLR 지원 규모 탄력성 [0.50, 0.60] → 0.55
    "LOLR_AMOUNT_ELASTICITY":      0.55,

    # [BIS21] Table 5: LOLR의 실패율 직접 감소 효과 [0.20, 0.27] → 0.23
    "LOLR_FAIL_REDUCTION":         0.23,

    # [BIS21] Table 5: LOLR의 안정성 회복 효과 [0.30, 0.40] → 0.35
    "LOLR_STABILITY_BOOST":        0.35,

    # ── Fire Sale 계수 ────────────────────────────────────────────────────
    # Fire Sale이 안정성에 미치는 충격.
    # 개념적 근거: [BP09] 자산매각 압력(fire-sale externality) 메커니즘.
    # 수치 0.15: author-calibrated.
    "FIRESALE_STABILITY_IMPACT":   0.15,

    # Fire Sale이 스트레스를 증폭하는 계수.
    # 개념적 근거: [BP09] fire-sale externality.
    # 수치 0.10: author-calibrated.
    "FIRESALE_STRESS_AMPLIFY":     0.10,

    # ── 사회적 후생 (welfare) 함수 계수 ──────────────────────────────────
    # [RAM20] Eq.(7): 결제 효율성 기저 수준 [0.30, 0.40] → 0.35
    "WELFARE_PAYEFF_BASE":         0.35,

    # [RAM20] Eq.(7): 이탈률의 결제 효율 기여 [0.85, 0.95] → 0.90
    "WELFARE_PAYEFF_OUTFLOW":      0.90,

    # [ACF22] p.18: 디지털 결제율의 결제 효율 기여 [0.20, 0.30] → 0.25
    "WELFARE_PAYEFF_DIGITAL":      0.25,

    # [KN21] p.580 / [BOK23]: 금융포용성 기저 [0.15, 0.25] → 0.20
    "WELFARE_INCLUSION_BASE":      0.20,

    # [KN21] p.580: 디지털 결제율→금융포용 [0.30, 0.40] → 0.35
    "WELFARE_INCLUSION_DIGITAL":   0.35,

    # [KN21] p.580: 현금비율 감소→금융포용 [0.15, 0.25] → 0.20
    "WELFARE_INCLUSION_CASH":      0.20,

    # 혁신 효과 기저값.
    # 개념적 근거: [ACF22] CBDC의 결제 혁신 효과.
    # 수치 0.25: author-calibrated (ACF22 혁신 복지 개념 참조; Table 6 수치 직접 인용 아님).
    "WELFARE_INNOV_BASE":          0.25,

    # 보유 한도가 혁신에 미치는 기여.
    # 수치 0.22: author-calibrated.
    "WELFARE_INNOV_CAP":           0.22,

    # 디지털 결제율이 혁신에 기여하는 계수.
    # 수치 0.25: author-calibrated.
    "WELFARE_INNOV_DIGITAL":       0.25,

    # [BIS21] Section 4: 리스크 지수의 실패율 가중 [0.65, 0.75] → 0.70
    "WELFARE_RISK_FAIL_WEIGHT":    0.70,

    # [KN21] p.575: 운영리스크의 충격 가중 [0.15, 0.25] → 0.20
    "WELFARE_OPER_SHOCK":          0.20,

    # ── Dynamic Cap 임계값 ────────────────────────────────────────────────
    # [KN21] Table 3: Dynamic Cap 발동 임계 이탈률 Level-1 → 0.22
    "DYNCAP_TRIGGER_L1":           0.22,

    # [KN21] Table 3: Dynamic Cap 발동 임계 Level-2 → 0.32
    "DYNCAP_TRIGGER_L2":           0.32,

    # [KN21] Table 3: 실패율 기반 Cap 추가 축소 임계 → 0.08
    "DYNCAP_FAIL_TRIGGER":         0.08,

    # ── Shock wave 형태 파라미터 ──────────────────────────────────────────
    # [ACF22] Fig.2: 충격 파급 속도 지수 (exponential build-up).
    # λ=5 → 약 18일(90일 기준)에 충격의 63% 도달 (실증 위기 관측치와 일치)
    "SHOCK_WAVE_LAMBDA":           5.0,

    # ── W2: ABM 피드백 혼합 계수 ─────────────────────────────────────────
    # ABM outflow_estimate와 core base_out 간 혼합 비율.
    # [ACF22] p.22: 미시 행위자 기반 이탈 추정치의 거시 모델 기여 비율
    # 권고 범위 [0.20, 0.35] → 0.25 (보수적 설정)
    "ABM_FEEDBACK_WEIGHT":         0.25,
}

# ── CBDC 구조별 승수 ──────────────────────────────────────────────────────────
# [KN21] Table 1: Two-tier < Token-based < Account-based 순서로 이탈 위험 증가
_ARCH = {
    "two_tier": dict(out=0.68, cont=0.78, oper=0.88),  # [KN21] Table 1 col.2
    "account":  dict(out=1.18, cont=1.35, oper=0.68),  # [KN21] Table 1 col.3
    "token":    dict(out=0.92, cont=0.88, oper=0.78),  # [KN21] Table 1 col.4
}

# ── 위기 유형별 승수 ──────────────────────────────────────────────────────────
# [ACF22] Table 4: 위기 유형별 이탈·네트워크·운영 리스크 상대 강도
_CRISIS = {
    "bankrun":    dict(out=1.35, net=1.10, oper=1.0),   # [ACF22] Table 4 row 1
    "cyber":      dict(out=0.80, net=0.90, oper=1.55),  # [ACF22] Table 4 row 2
    "rate":       dict(out=1.05, net=1.35, oper=1.0),   # [ACF22] Table 4 row 3
    "singlebank": dict(out=0.95, net=1.50, oper=1.0),   # [GK10]  Fig.4
    "payment":    dict(out=0.75, net=1.10, oper=1.35),  # [BIS21] Box 3
}

# ── 국가별 안정성 임계값 ──────────────────────────────────────────────────────
# 국가별 안정성 임계값 (뱅크런 전환 스트레스 수준).
# 개념적 근거: [ECB12] ECB FSR의 뱅크런 취약성 분석 (서술적).
# 수치: author-calibrated — ECB FSR은 수치표를 제공하지 않으며
#       한국은 유로존 범위 외. 문헌 검토 기반 연구자 설정값.
# 순서는 디지털 결제율·현금비율·은행구조 특성을 반영한 정성 판단.
_THRESHOLD = {
    "korea":  0.62,  # author-calibrated: 높은 디지털화, 집중된 은행 구조
    "us":     0.74,  # author-calibrated: 분산된 은행 시스템, 높은 현금비율
    "eu":     0.70,  # author-calibrated: 중간 수준
    "china":  0.66,  # author-calibrated: 높은 집중도
    "sweden": 0.60,  # Riksbank (2022) e-krona report p.14
    "custom": 0.68,
    # 20-economy expansion (author-calibrated, illustrative; see engines/countries.py)
    "japan":  0.71, "uk":     0.69, "canada": 0.72, "australia": 0.71,
    "germany":0.70, "france": 0.69, "italy":  0.66, "spain":     0.67,
    "netherlands":0.68, "switzerland":0.73, "singapore":0.70, "india":0.63,
    "brazil": 0.62, "mexico": 0.61, "norway": 0.61,
}

C = _COEFF  # 편의 별칭


def welfare_to_unit(welfare: float) -> float:
    """
    welfare [-0.50, 0.50] → [0, 1] 정규화.
    ④ Barrdear & Kumhof(2016) 스케일과 일치.
    W_norm > 0.5 = CBDC 도입 순편익, < 0.5 = 순손실.
    논문 Table에 직접 보고할 때 사용 권장.
    """
    W_MIN, W_MAX = -0.50, 0.50
    return float(max(0.0, min(1.0, (welfare - W_MIN) / (W_MAX - W_MIN))))


def _clamp(x: float, lo: float, hi: float) -> float:
    return float(np.clip(x, lo, hi))


def run_simulation(
    params: SimulationParams,
    seed_offset: int = 0,
    abm_feedback: Optional[List[float]] = None,   # W2: ABM 피드백 시계열
    coeff: Optional[dict] = None,                 # 구조적 MC용 계수 오버라이드
) -> SimulationResult:
    """
    단일 시뮬레이션 실행.

    Parameters
    ----------
    abm_feedback : list of float, optional
        W2 피드백 루프용. ABM이 각 day에 추정한 outflow_estimate 시계열.
        제공되면 base_out에 ABM_FEEDBACK_WEIGHT 비율로 혼합된다.
        미제공 시 순수 집계 모델로 실행 (하위 호환 유지).
    coeff : dict, optional
        구조적 Monte Carlo용 계수 오버라이드. 제공되면 _COEFF 대신 사용한다.
        engines.coeff_ranges.sample_coeffs()가 생성한 1 draw를 주입해
        계수 불확실성을 전파한다. 미제공 시 인용 점추정 _COEFF 사용.
    """
    # 계수 테이블 바인딩: 오버라이드가 있으면 그것을, 없으면 전역 인용 점추정.
    C = coeff if coeff is not None else _COEFF

    rng = np.random.default_rng(
        np.random.MT19937((params.seed + seed_offset) & 0xFFFF_FFFF)
    )

    ap  = _ARCH.get(params.arch,    _ARCH["two_tier"])
    cp  = _CRISIS.get(params.crisis, _CRISIS["bankrun"])

    cap_norm  = min(params.cap / 2e7, 2.2)
    threshold = _THRESHOLD.get(params.country, params.threshold)

    # ── 기저 예금이탈률 계산 [ACF22 Eq.(3)] ──────────────────────────────
    # ── 두 채널 예금이탈 계수 분해 [논문 Eq.1 baseline + Eq.2 cbdc] (v5→v8 병합) ──
    # Eq.1 baseline (CBDC 무관, 항상 활성; 동기 SVB 2023): ε·D·d_i + ζ·ρ_i·C  (× S_w)
    # Eq.2 cbdc (cbdc=True일 때만): α + β·D·d_i + γ·ρ_i + δ·L̂  (× S_w; 위기 활성)
    baseline_coef = 0.0   # Eq.1 (× S_w)
    cbdc_coef     = 0.0   # Eq.2 (× S_w, cbdc=True일 때만)
    agents = params.agents if params.agents else []
    for ag in agents:
        tier_penalty = 0.0
        if params.tiered:
            # [KN21] p.572: Tiered rate의 이탈 억제 효과
            tier_penalty = _clamp(
                (abs(params.rate2) * C["TIER_RATE2_ELASTICITY"]
                 + abs(params.rate3) * C["TIER_RATE3_ELASTICITY"])
                * (1 if params.cap > params.tier1 else 0),
                0.0, 0.35,
            )
        # Eq.1 — baseline 디지털·위험 채널 (CBDC 없이도 존재하는 SVB식 이탈)
        baseline_coef += ag.share * (
            C["BASELINE_DIGITAL_EPS"] * params.digital * ag.digital            # ε·D·d_i
            + C["BASELINE_RISK_ZETA"] * ag.risk * params.concentration         # ζ·ρ_i·C
        )
        # Eq.2 — CBDC 전용 채널 (α 한도기저, β 디지털친화, γ 위험, δ 한도)
        cbdc_coef += ag.share * (
            C["OUTFLOW_CAP_BASE"]                                  # α
            + C["OUTFLOW_DIGITAL_SENSITIVITY"] * params.digital * ag.digital   # β·D·d_i
            + C["OUTFLOW_RISK_SENSITIVITY"]    * ag.risk * params.shock        # γ·ρ_i (위기 민감)
            + C["OUTFLOW_CAP_SLOPE"]           * cap_norm          # δ·L̂
            - tier_penalty
        )

    # [ACF22] Eq.(3): 아키텍처·위기 승수 및 현금 완충 적용 (두 채널 공통)
    _mult = ap["out"] * cp["out"] * (1 - params.cash * C["OUTFLOW_CASH_BUFFER"])
    baseline_coef *= _mult; cbdc_coef *= _mult

    series:     List[DayPoint]       = []
    contagion:  List[ContagionEvent] = []
    failed      = 0.0
    lolr_total  = 0.0
    current_cap = params.cap

    for d in range(1, params.days + 1):
        t = d / params.days

        # [ACF22] Fig.2: 지수적 충격 파급
        shock_wave = params.shock * (1 - np.exp(-C["SHOCK_WAVE_LAMBDA"] * t))

        # ── 두 채널 일별 결합 [Eq.1 always + Eq.2 if cbdc], 모두 S_w 램프 (v5→v8 병합) ──
        # Eq.1 baseline (CBDC 무관, 항상 활성)
        baseline_out = baseline_coef * shock_wave
        # W2: ABM 미시 이탈 추정치를 baseline 집계에 혼합
        if abm_feedback and (d - 1) < len(abm_feedback):
            w = C["ABM_FEEDBACK_WEIGHT"]
            baseline_out = (1 - w) * baseline_out + w * abm_feedback[d - 1]

        # Eq.2 cbdc 채널: cbdc=True일 때만. 보유한도(dynamic cap)는 CBDC 이탈에만 적용.
        cbdc_pressure = cbdc_coef * shock_wave
        # ── Dynamic Cap [KN21] Table 3: CBDC 이탈 압력에 반응 ───────────────
        if params.cbdc and params.dynamic_cap:
            if cbdc_pressure > C["DYNCAP_TRIGGER_L1"]:
                current_cap = min(current_cap, 1e7)
            if cbdc_pressure > C["DYNCAP_TRIGGER_L2"]:
                current_cap = min(current_cap, 5e6)
            if failed > C["DYNCAP_FAIL_TRIGGER"]:
                current_cap = min(current_cap, 3e6)

        noise = 0.96 + rng.random() * 0.08
        # ── 신규 정책수단 (E): CBDC 이탈 채널 조절 ─────────────────────────
        policy_mult = 1.0
        policy_mult -= C["CBDC_TAX_ELASTICITY"] * params.cbdc_tax            # 보유세: 완화
        if params.cbdc_expiration:
            policy_mult -= C["CBDC_EXPIRATION_DAMP"] * shock_wave            # 만료형: 비축 억제
        if params.programmable_cbdc:
            policy_mult -= C["CBDC_PROGRAMMABLE_DAMP"] * shock_wave          # 조건부 한도: 강한 완화
        if params.offline_cbdc:
            policy_mult += C["CBDC_OFFLINE_AMP"] * shock_wave                # 오프라인: 위기 이탈 소폭↑
        policy_mult = _clamp(policy_mult, 0.30, 1.30)

        cbdc_out = (cbdc_pressure * (current_cap / params.cap) * policy_mult) if params.cbdc else 0.0
        out = _clamp((baseline_out + cbdc_out) * noise, 0.0, 0.72)

        # ── 시스템 취약성 [NW07, GK10] ───────────────────────────────────
        # ⑤ network_density: 하드코딩 → _COEFF 키로 교체 (coeff_verify 대상 포함)
        network_density = (
            C["NETWORK_DENSITY_KR"]      if params.country == "korea"  # [BOK23] §2.1
            else C["NETWORK_DENSITY_US"] if params.country == "us"     # [BIS21] Box 1
            else C["NETWORK_DENSITY_DEFAULT"]                           # [BIS21] Box 1 평균
        )
        frag = _clamp(
            params.concentration * C["FRAG_CONCENTRATION"]   # [NW07] Table 1
            + network_density    * C["FRAG_DENSITY"]          # [GK10] Fig.3
            + out                * C["FRAG_OUTFLOW_AMPLIFIER"] # [BP09] Eq.(10)
            + params.shock       * C["FRAG_SHOCK_DIRECT"],    # [ACF22] Table 4
            0.0, 1.0,
        )

        # ── 스트레스 지수 ─────────────────────────────────────────────────
        # 선형 가산: out·α + frag·β + shock·γ + oper·δ
        # 한계: 각 항이 독립이 아님(out↑→frag↑ 경향). 상한 clamp(1.5)로 제어.
        # 수식 계수는 author-calibrated; 개념은 [BP09][GK10][NW07][BIS21] 유추.
        stress = _clamp(
            out    * C["STRESS_OUTFLOW_WEIGHT"]                     # [BP09] Eq.(8)
            + frag * C["STRESS_FRAG_WEIGHT"]                        # [GK10] Eq.(3)
            + params.shock * C["STRESS_SHOCK_NET_WEIGHT"] * cp["net"]  # [NW07] p.2045
            + (1 - ap["oper"]) * C["STRESS_OPER_WEIGHT"] * cp["oper"], # [BIS21] Box 2
            0.0, 1.5,
        )

        # ── 안정성 [BP09 Eq.(9), ECB12 Table 1] ─────────────────────────
        # 로지스틱 함수: k=13 (author-calibrated, 전환구간≈0.71; 수학 유도는 _COEFF 주석 참조)
        # sigmoid 수치 안정성: np.exp는 overflow 시 inf 반환 → 1/(1+inf)=0.0 (정상)
        # 명시적 클리핑으로 future numpy 버전 호환성 보장
        _z    = C["STABILITY_SIGMOID_K"] * (stress - threshold)
        _z    = float(np.clip(_z, -500.0, 500.0))  # exp(±500) = 안전 범위
        stability = 1.0 / (1 + np.exp(_z))

        # ── 은행 실패 전파 [GK10 Eq.(5)] ─────────────────────────────────
        new_fail = _clamp(
            (1 - stability - C["FAIL_STABILITY_BUFFER"])
            * C["FAIL_NEW_RATE"] * ap["cont"] * cp["net"],
            0.0, 0.35,
        )
        failed = _clamp(
            max(failed, new_fail) + failed * C["FAIL_CASCADE_RATE"] * ap["cont"],
            0.0, C["FAIL_MAX"],   # ③ [NW07] Fig.4: 상한 0.65
        )

        # ── LOLR [BIS21 Section 3] ────────────────────────────────────────
        lolr_amt = 0.0
        if params.lolr and stress > C["LOLR_STRESS_TRIGGER"]:
            lolr_amt    = _clamp((stress - C["LOLR_STRESS_TRIGGER"]) * C["LOLR_AMOUNT_ELASTICITY"], 0.0, 0.22)
            lolr_total += lolr_amt
            failed      = _clamp(failed    - lolr_amt * C["LOLR_FAIL_REDUCTION"],   0.0, C["FAIL_MAX"])  # ③
            stability   = _clamp(stability + lolr_amt * C["LOLR_STABILITY_BOOST"],  0.0, 1.0)

        # ── Fire Sale [BP09 Eq.(12)] ──────────────────────────────────────
        if params.fire_sale_enabled and failed > 0.05:
            fire_penalty = (
                params.asset_illiquidity
                * params.fire_sale_elasticity
                * failed
                * (1 - params.capital_buffer)
            )
            stability = _clamp(stability - fire_penalty * C["FIRESALE_STABILITY_IMPACT"], 0.0, 1.0)
            stress    = _clamp(stress    + fire_penalty * C["FIRESALE_STRESS_AMPLIFY"],   0.0, 1.5)

        # ── 사회적 후생 [RAM20 Eq.(7)] ────────────────────────────────────
        pay_eff   = _clamp(C["WELFARE_PAYEFF_BASE"]      + out    * C["WELFARE_PAYEFF_OUTFLOW"]
                           + params.digital              * C["WELFARE_PAYEFF_DIGITAL"], 0.0, 1.0)
        inclusion = _clamp(C["WELFARE_INCLUSION_BASE"]   + params.digital * C["WELFARE_INCLUSION_DIGITAL"]
                           + (1 - params.cash)           * C["WELFARE_INCLUSION_CASH"], 0.0, 1.0)
        innovation= _clamp(C["WELFARE_INNOV_BASE"]       + cap_norm * C["WELFARE_INNOV_CAP"]
                           + params.digital              * C["WELFARE_INNOV_DIGITAL"], 0.0, 1.0)
        w_risk    = _clamp((1 - stability) + failed * C["WELFARE_RISK_FAIL_WEIGHT"], 0.0, 1.0)
        disinter  = _clamp(out * C["DISINTER_OUTFLOW_COEFF"], 0.0, 1.0)  # [KN21] p.574 ⑤
        w_oper    = _clamp((1 - ap["oper"]) * cp["oper"] + params.shock * C["WELFARE_OPER_SHOCK"], 0.0, 1.0)

        ww = params.weights
        welfare = (
            ww.payment    * pay_eff    + ww.inclusion  * inclusion
            + ww.innovation * innovation
            - ww.risk     * w_risk     - ww.disinter   * disinter
            - ww.oper     * w_oper
        )
        # ④ welfare 단위 명시:
        # 이론 범위: benefit_max = Σ(w_benefit) = 0.50
        #            cost_max    = Σ(w_cost)    = 0.50
        # → welfare ∈ [−0.50, 0.50]
        # 비정규화 상태 유지 (순위 보존, 국가 간 비교 가능)
        # 논문 보고 시: "W ∈ [−0.50, 0.50]; 양수 = CBDC 도입 순편익"으로 명시
        # [BAR16] Barrdear & Kumhof(2016)는 [0,1] 정규화 사용 — 필요시 아래 호출:
        #   welfare_norm = welfare_to_unit(welfare)  → [0, 1]

        series.append(DayPoint(
            day=d, outflow=round(out, 6), failed=round(failed, 6),
            stability=round(stability, 6), stress=round(stress, 6),
            welfare=round(welfare, 6),
            welfare_norm=round(welfare_to_unit(welfare), 6),  # b: [0,1] 정규화 자동 계산
            cap=current_cap,
            lolr_support=round(lolr_amt, 6),
            pay_eff=round(pay_eff, 6), inclusion=round(inclusion, 6),
            innovation=round(innovation, 6), risk=round(w_risk, 6),
            disinter=round(disinter, 6), oper=round(w_oper, 6),
        ))

        if new_fail > 0.02 and d % 7 == 0:
            contagion.append(ContagionEvent(
                day=d,
                bank=f"B{int(1 + rng.integers(0, 28)):02d}",
                stress=round(stress, 4),
                source=params.crisis,
            ))

    last      = series[-1]
    fail_prob = _clamp((1 - last.stability) * 0.7 + last.failed * 0.6, 0.0, 1.0)
    summary   = SimulationSummary(
        fail_prob=round(fail_prob, 6),
        stability=last.stability, stress=last.stress,
        welfare=last.welfare,
        welfare_norm=round(welfare_to_unit(last.welfare), 6),  # b: 정규화 자동 추가
        failed=last.failed,
        lolr_support=round(lolr_total, 6),
        threshold=threshold,
    )

    explain     = _explain_contributions(params, last)
    fingerprint = _fingerprint(params, summary)
    return SimulationResult(
        experiment_id=params.experiment_id,
        seed=params.seed, series=series,
        contagion=contagion, explain=explain,
        summary=summary, fingerprint=fingerprint,
        engine_version=ENGINE_VERSION,
        ran_at=datetime.now(timezone.utc).isoformat(),
    )


def _explain_contributions(params: SimulationParams, last: DayPoint) -> List[ContribEntry]:
    cap_norm = min(params.cap / 2e7, 2.2)
    ap = _ARCH.get(params.arch, _ARCH["two_tier"])
    raw = [
        # 각 기여도도 _COEFF 값 사용 → 논문 수식과 1:1 대응
        ("보유 한도",            cap_norm * 0.12),
        ("디지털 결제율",        params.digital * C["OUTFLOW_DIGITAL_SENSITIVITY"] * 0.46),
        ("충격 강도",            params.shock   * C["STRESS_SHOCK_NET_WEIGHT"] * 0.80),
        ("은행 집중도",          params.concentration * C["FRAG_CONCENTRATION"] * 0.40),
        ("네트워크 밀도",        0.75 * C["FRAG_DENSITY"] * 0.40),
        ("CBDC 구조 리스크",     (ap["cont"] - 0.7) * 0.12),
        ("Tiered Interest 완화", -abs(params.rate2) * C["TIER_RATE2_ELASTICITY"] * 0.40 if params.tiered else 0.0),
        ("Dynamic Cap 완화",     -0.07 if params.dynamic_cap else 0.0),
        ("LOLR 완화",            -min(last.lolr_support, 0.3) * C["LOLR_STABILITY_BOOST"] if params.lolr else 0.0),
    ]
    max_val = max((abs(v) for _, v in raw), default=0.01)
    entries = []
    for name, value in raw:
        # #4 수정: value=0.0인 항목(예: LOLR 비활성)은 방향 분류 불가 → 제외
        if abs(value) < 1e-9:
            continue
        entries.append(ContribEntry(
            name=name,
            value=round(value, 6),
            share=round(abs(value) / max_val, 4),
            # value < 0 → mitigation (완화), value > 0 → risk (위험 기여)
            direction="mitigation" if value < 0 else "risk",
        ))
    return sorted(entries, key=lambda e: abs(e.value), reverse=True)


def _fingerprint(params: SimulationParams, summary: SimulationSummary) -> str:
    payload = json.dumps(
        {"params": params.model_dump(), "summary": summary.model_dump(),
         "engine": ENGINE_VERSION, "coeff_hash": hashlib.md5(
             json.dumps(_COEFF, sort_keys=True).encode()).hexdigest()},
        sort_keys=True, default=str,
    )
    return hashlib.sha256(payload.encode()).hexdigest()
