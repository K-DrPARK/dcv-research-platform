"""
위기 동역학 보정 + 표본외 검증 엔진 — v6.0 (듀얼패스 통합; manuscript python-mt19937-v6.0 일치)

#1 수정: solvency.py를 crisis_fit에 통합한 듀얼패스(dual-path) 아키텍처.

문제 진단 (R²=−1.48, 분류정확도 15% 원인)
──────────────────────────────────────────
1. 스케일 불일치: core.py는 일일 이탈률 0.2~0.5 예측, 실증 관측은 0.02~0.24
   → 체계적 과대추정 → R² 음수
2. 분류 편향: 기저율 85%(22/26 실패), 고충격 시 항상 fail_prob>0.5
   → 생존 4개를 모두 '실패'로 분류 → 분류정확도=기저율
3. 모델 미명세: 유동성 위기(core)와 지급능력 위기(solvency)를 단일 모델로 통합 불가

듀얼패스 해결책
───────────────
- failure_mode 컬럼으로 에피소드를 분류:
    "liquidity"  → core.py 경로 (SVB, Northern Rock 유형)
    "solvency"   → solvency.py 경로 (WaMu, Continental Illinois 유형)
    "hybrid"     → 두 경로 가중 평균
- 각 경로별 독립 θ 적합 → 표본외 성능 재측정
- 한계 정직 보고: 듀얼패스로도 R² > 0 달성이 어려운 에피소드는
  "모델 범위 외" 로 명시

정직한 한계 인정
─────────────────
3개 θ로 26개 에피소드를 설명하는 것은 과소 모수화(under-parameterized).
듀얼패스가 R² 개선에 기여하지만 완전 해결은 불가. 논문에서 다음으로 보고:
  "유동성 위기 경로(n=14)에서 LOO R²=X.XX, 지급능력 경로(n=8)에서 R²=X.XX.
   혼합 유형(n=4) 에피소드는 단일 경로 모델의 한계로 별도 보고."
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Tuple, Optional

import numpy as np
import pandas as pd

try:
    from scipy.optimize import minimize
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

from models.params  import SimulationParams, AgentConfig, WelfareWeights
from .core          import run_simulation, _COEFF
from .solvency      import run_solvency, SolvencyParams

_EPISODES_CSV = Path(__file__).parent.parent / "data" / "cache" / "crisis_episodes.csv"

_RUN_AGENTS = [
    AgentConfig(key="retail",    name="소매예금",   share=0.45, digital=0.45, risk=0.55),
    AgentConfig(key="wholesale", name="도매예금",   share=0.30, digital=0.90, risk=0.85),
    AgentConfig(key="uninsured", name="비보험예금", share=0.25, digital=0.80, risk=0.95),
]
_FAIL_W  = 0.8
_THETA0  = np.array([1.0, 1.0, 1.0])
_BOUNDS  = [(0.3, 3.0), (0.3, 3.0), (0.5, 1.6)]

# ── 에피소드별 failure_mode 매핑 ──────────────────────────────────────────────
# 원자료 기반 수동 분류:
#   liquidity : 예금이탈이 자산손상보다 먼저 (SVB, Northern Rock 유형)
#   solvency  : 자산손상이 먼저, 뱅크런은 결과 (WaMu, Lehman 유형)
#   hybrid    : 두 경로 동시 진행
_FAILURE_MODE: Dict[str, str] = {
    "svb":                    "liquidity",
    "signature":              "liquidity",
    "first_republic":         "liquidity",
    "washington_mutual":      "solvency",
    "northern_rock":          "liquidity",
    "credit_suisse":          "hybrid",
    "continental_illinois":   "solvency",
    "stable_control":         "liquidity",
    "indymac":                "solvency",
    "wachovia":               "hybrid",
    "colonial_bank":          "solvency",
    "downey_savings":         "solvency",
    "guaranty_bank":          "solvency",
    "bancorp_usna":           "solvency",
    "mcorp":                  "solvency",
    "first_city_tx":          "solvency",
    "bcci":                   "hybrid",
    "new_century":            "solvency",
    "homebanc":               "solvency",
    "silverton_bank":         "solvency",
    "westernbank_pr":         "solvency",
    "first_bk_florida":       "solvency",
    "silicon_valley_bk_uk":   "liquidity",
    "stable_large_2019":      "liquidity",
    "stable_mid_2015":        "liquidity",
    "eurozone_periphery":     "hybrid",
    "bear_stearns":           "liquidity",
    "lehman":                 "solvency",
}


def load_episodes(min_reliability: str = "estimated") -> pd.DataFrame:
    df = pd.read_csv(_EPISODES_CSV, comment="#")
    if "reliability" not in df.columns:
        df["reliability"] = "verified"
    if "failure_mode" not in df.columns:
        df["failure_mode"] = df["episode"].map(
            lambda e: _FAILURE_MODE.get(str(e), "liquidity")
        )
    if min_reliability == "verified":
        df = df[df["reliability"] == "verified"]
    elif min_reliability == "estimated":
        df = df[df["reliability"].isin(["verified", "estimated"])]
    return df.reset_index(drop=True)


def _scaled_coeff(outflow_gain: float, fail_gain: float) -> Dict[str, float]:
    c = dict(_COEFF)
    for k in list(c):
        if k.startswith("OUTFLOW_") and k != "OUTFLOW_CASH_BUFFER":
            c[k] *= outflow_gain
        if k in ("FAIL_NEW_RATE", "FAIL_CASCADE_RATE"):
            c[k] *= fail_gain
    return c


def _predict_liquidity(row, theta: np.ndarray) -> Tuple[float, float]:
    """유동성 경로: core.py run_simulation."""
    outflow_gain, fail_gain, shock_map = theta
    p = SimulationParams(
        country="custom", arch="two_tier", tiered=False,
        lolr=int(row["had_lolr"]) == 1,  # pandas int64/float64/str 모두 안전. bool("0")=True 오류 방지
        concentration=float(row["concentration"]),
        digital=float(row["digital"]),
        shock=float(np.clip(row["severity"] * shock_map, 0.0, 1.0)),
        days=int(np.clip(row["window_days"], 5, 120)),
        agents=_RUN_AGENTS,
        weights=WelfareWeights(),
    )
    res = run_simulation(p, coeff=_scaled_coeff(outflow_gain, fail_gain))
    return float(max(pt.outflow for pt in res.series)), float(res.summary.fail_prob)


def _predict_solvency(row, theta: np.ndarray) -> Tuple[float, float]:
    """지급능력 경로: solvency.py run_solvency."""
    outflow_gain, fail_gain, shock_map = theta
    sp = SolvencyParams(
        risky_asset_share=float(np.clip(row["concentration"] * 0.85, 0.3, 0.9)),
        asset_loss_rate_annual=0.04 * float(row["severity"]),
        loss_acceleration=1.5 + float(row["severity"]) * 0.8,
    )
    p = SimulationParams(
        country="custom", arch="two_tier", tiered=False,
        lolr=int(row["had_lolr"]) == 1,  # pandas int64/float64/str 모두 안전. bool("0")=True 오류 방지
        concentration=float(row["concentration"]),
        digital=float(row["digital"]),
        shock=float(np.clip(row["severity"] * shock_map, 0.0, 1.0)),
        days=int(np.clip(row["window_days"], 5, 120)),
        agents=_RUN_AGENTS,
        weights=WelfareWeights(),
    )
    res = run_solvency(p, sp=sp, cbdc_enabled=False)
    peak = float(max(b.daily_outflow for b in res.series)) if res.series else 0.0
    # 파산 여부 → fail_prob 변환
    fail_p = 1.0 if res.seized_day is not None else 0.15
    return float(peak * outflow_gain), fail_p


def predict_episode(row, theta: np.ndarray) -> Tuple[float, float]:
    """
    에피소드 failure_mode에 따라 경로 선택 후 예측.
    hybrid는 두 경로 가중 평균 (0.5/0.5).
    """
    mode = str(row.get("failure_mode", _FAILURE_MODE.get(str(row["episode"]), "liquidity")))
    if mode == "liquidity":
        return _predict_liquidity(row, theta)
    elif mode == "solvency":
        return _predict_solvency(row, theta)
    else:  # hybrid
        pk_l, fl_l = _predict_liquidity(row, theta)
        pk_s, fl_s = _predict_solvency(row, theta)
        return (pk_l + pk_s) / 2.0, (fl_l + fl_s) / 2.0


def _loss(theta: np.ndarray, df: pd.DataFrame) -> float:
    se_peak, se_fail = [], []
    for _, row in df.iterrows():
        pk, fl = predict_episode(row, theta)
        se_peak.append((pk - float(row["peak_outflow"])) ** 2)
        se_fail.append((fl - float(row["failed"])) ** 2)
    return float(np.mean(se_peak) + _FAIL_W * np.mean(se_fail))


@dataclass
class FitResult:
    theta:           Dict[str, float]
    train_rmse_peak: float
    train_loss:      float
    n_train:         int
    converged:       bool
    note:            str


def fit_crisis(df: Optional[pd.DataFrame] = None) -> FitResult:
    df = load_episodes() if df is None else df
    if _HAS_SCIPY:
        res = minimize(_loss, _THETA0, args=(df,), method="Nelder-Mead",
                       options={"xatol": 1e-3, "fatol": 1e-4, "maxiter": 600})
        theta, converged = res.x, bool(res.success)
    else:
        theta, best = _THETA0.copy(), 1e18
        for a in np.linspace(0.4, 2.6, 10):
            for b in np.linspace(0.4, 2.6, 10):
                for c_ in np.linspace(0.6, 1.5, 6):
                    L = _loss(np.array([a, b, c_]), df)
                    if L < best:
                        best, theta = L, np.array([a, b, c_])
        converged = True

    preds = [predict_episode(r, theta)[0] for _, r in df.iterrows()]
    obs   = df["peak_outflow"].to_numpy(float)
    rmse  = float(np.sqrt(np.mean((np.array(preds) - obs) ** 2)))

    n_liq = (df.get("failure_mode", pd.Series(["liquidity"]*len(df))) == "liquidity").sum()
    n_sol = (df.get("failure_mode", pd.Series(["liquidity"]*len(df))) == "solvency").sum()
    n_hyb = (df.get("failure_mode", pd.Series(["liquidity"]*len(df))) == "hybrid").sum()

    return FitResult(
        theta={"outflow_gain": round(float(theta[0]), 4),
               "fail_gain":    round(float(theta[1]), 4),
               "shock_map":    round(float(theta[2]), 4)},
        train_rmse_peak=round(rmse, 4),
        train_loss=round(_loss(theta, df), 6),
        n_train=len(df), converged=converged,
        note=(f"듀얼패스 scipy Nelder-Mead: "
              f"liquidity={n_liq}, solvency={n_sol}, hybrid={n_hyb}"),
    )


@dataclass
class OosResult:
    per_episode:   List[Dict]
    oos_rmse_peak: float
    oos_r2_peak:   float
    fail_accuracy: float
    fail_accuracy_by_mode: Dict[str, float]
    n_folds:       int
    fitted_thetas: List[Dict]
    note:          str
    honest_assessment: str   # 논문에 직접 기술 가능한 정직한 평가


def validate_loo() -> OosResult:
    """
    Leave-one-out 교차검증 — 듀얼패스 통합 버전.

    경로별 성능도 별도 보고 (논문 Table용).
    """
    df = load_episodes().reset_index(drop=True)
    per: List[Dict] = []
    thetas: List[Dict] = []
    preds_peak, obs_peak = [], []
    fail_correct = 0
    mode_results: Dict[str, List[bool]] = {"liquidity": [], "solvency": [], "hybrid": []}

    for i in range(len(df)):
        train = df.drop(index=i).reset_index(drop=True)
        test  = df.loc[i]
        fr    = fit_crisis(train)
        th    = np.array([fr.theta["outflow_gain"],
                          fr.theta["fail_gain"],
                          fr.theta["shock_map"]])
        pk, fl = predict_episode(test, th)
        pred_failed = int(fl >= 0.5)
        ok = int(pred_failed == int(test["failed"]))
        fail_correct += ok

        mode = str(test.get("failure_mode",
                             _FAILURE_MODE.get(str(test["episode"]), "liquidity")))
        mode_results[mode].append(bool(ok))

        per.append({
            "episode":       test["episode"],
            "year":          int(test["year"]),
            "failure_mode":  mode,
            "obs_peak":      round(float(test["peak_outflow"]), 4),
            "pred_peak":     round(pk, 4),
            "obs_failed":    int(test["failed"]),
            "pred_fail_prob":round(fl, 4),
            "pred_failed":   pred_failed,
            "correct":       bool(ok),
        })
        thetas.append(fr.theta)
        preds_peak.append(pk)
        obs_peak.append(float(test["peak_outflow"]))

    preds_arr = np.array(preds_peak)
    obs_arr   = np.array(obs_peak)
    rmse      = float(np.sqrt(np.mean((preds_arr - obs_arr) ** 2)))
    ss_res    = float(np.sum((obs_arr - preds_arr) ** 2))
    ss_tot    = float(np.sum((obs_arr - obs_arr.mean()) ** 2))
    r2        = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    acc       = fail_correct / len(df)

    mode_acc = {
        m: (sum(v) / len(v) if v else float("nan"))
        for m, v in mode_results.items()
    }

    # 정직한 평가 문구 (논문에 그대로 사용 가능)
    if r2 > 0.3:
        honest = (f"듀얼패스 통합 후 LOO R²={r2:.3f}로 개선. "
                  f"유동성 경로 정확도={mode_acc['liquidity']:.0%}, "
                  f"지급능력 경로={mode_acc['solvency']:.0%}.")
    elif r2 > 0.0:
        honest = (f"듀얼패스 통합 후 LOO R²={r2:.3f} (양수로 전환). "
                  f"그러나 통계적으로 약한 예측력. 모델은 방향성(fail vs survive) "
                  f"예측에 더 적합하며, peak_outflow 수치 예측 정밀도는 제한적.")
    else:
        honest = (
            f"LOO R²={r2:.3f} (음수 유지). "
            f"이는 모델의 peak_outflow 수치 예측력이 기저율보다 낮음을 의미. "
            f"원인: (1) 에피소드별 이질성이 3개 θ로 포착 불가, "
            f"(2) estimated 에피소드의 peak_outflow 추정 오차. "
            f"파산 방향성 분류는 {acc:.0%} (기저율 {int(test['failed'])/len(df) if len(df)>0 else 0.85:.0%}). "
            f"논문에서 수치 예측보다 '위기 경로 분류'와 '정책 비교'를 기여로 포지셔닝 권고."
        )

    return OosResult(
        per_episode=per,
        oos_rmse_peak=round(rmse, 4),
        oos_r2_peak=round(r2, 4),
        fail_accuracy=round(acc, 4),
        fail_accuracy_by_mode={m: round(v, 4) if v == v else None
                                for m, v in mode_acc.items()},
        n_folds=len(df),
        fitted_thetas=thetas,
        note=(f"듀얼패스 LOO-CV · {len(df)}겹 · R²={r2:.3f} · "
              f"분류={acc*100:.0f}% · "
              f"liq={mode_acc['liquidity']:.0%}/"
              f"sol={mode_acc.get('solvency',0):.0%}/"
              f"hyb={mode_acc.get('hybrid',0):.0%}"),
        honest_assessment=honest,
    )


def train_test_split_validate(test_episodes: List[str]) -> Dict:
    df   = load_episodes()
    mask = df["episode"].isin(test_episodes)
    train, test = df[~mask], df[mask]
    fr   = fit_crisis(train)
    th   = np.array([fr.theta["outflow_gain"],
                     fr.theta["fail_gain"],
                     fr.theta["shock_map"]])
    rows = []
    for _, r in test.iterrows():
        pk, fl = predict_episode(r, th)
        rows.append({"episode": r["episode"],
                     "failure_mode": r.get("failure_mode", "liquidity"),
                     "obs_peak": round(float(r["peak_outflow"]), 4),
                     "pred_peak": round(pk, 4),
                     "obs_failed": int(r["failed"]),
                     "pred_fail_prob": round(fl, 4)})
    obs  = test["peak_outflow"].to_numpy(float)
    pred = np.array([x["pred_peak"] for x in rows])
    rmse = float(np.sqrt(np.mean((pred - obs) ** 2))) if len(obs) else 0.0
    return {"theta": fr.theta, "train_rmse_peak": fr.train_rmse_peak,
            "test": rows, "test_rmse_peak": round(rmse, 4),
            "n_train": len(train), "n_test": len(test)}


# ── _FAIL_W 민감도 (기존 유지) ────────────────────────────────────────────────
from dataclasses import dataclass as _dc
from typing import List as _List

@_dc
class FailWRow:
    fail_w: float; theta_outflow: float; theta_fail: float
    theta_shock: float; train_rmse_peak: float
    train_loss: float; converged: bool

def fail_w_sensitivity(grid=None, df=None) -> _List[FailWRow]:
    global _FAIL_W
    if grid is None: grid = [0.4, 0.6, 0.8, 1.0, 1.2]
    if df is None:   df = load_episodes()
    rows, orig = [], _FAIL_W
    for w in grid:
        _FAIL_W = w
        fr = fit_crisis(df)
        rows.append(FailWRow(fail_w=w,
            theta_outflow=fr.theta["outflow_gain"],
            theta_fail=fr.theta["fail_gain"],
            theta_shock=fr.theta["shock_map"],
            train_rmse_peak=fr.train_rmse_peak,
            train_loss=fr.train_loss, converged=fr.converged))
    _FAIL_W = orig
    return rows

def summarise_fail_w_sensitivity(rows: _List[FailWRow]) -> dict:
    if not rows: return {"error": "결과 없음"}
    outs = [r.theta_outflow for r in rows]
    fils = [r.theta_fail    for r in rows]
    shks = [r.theta_shock   for r in rows]
    mx   = max(max(outs)-min(outs), max(fils)-min(fils), max(shks)-min(shks))
    return {
        "max_theta_range": round(mx, 4),
        "robust": mx < 0.15,
        "verdict": (f"θ 최대 변화폭={mx:.4f}. "
                    + ("강건." if mx < 0.15 else "⚠️ 민감.")),
        "rows": [{"fail_w": r.fail_w,
                  "theta_outflow": round(r.theta_outflow, 4),
                  "theta_fail":    round(r.theta_fail, 4),
                  "theta_shock":   round(r.theta_shock, 4),
                  "train_rmse_peak": r.train_rmse_peak,
                  "converged": r.converged} for r in rows],
    }
