"""
historical_loader.py — Historical Crisis Dataset Loader (③).

Loads, filters, and merges historical bank-run / deposit-flight episode panels so that
calibration and validation can run on the base panel, the extended 1984-2025 panel, or a
de-duplicated merge of both.

  load(dataset="extended", min_reliability="estimated")  → pandas DataFrame
  available()                                             → list of dataset keys
  describe(dataset)                                       → summary dict (n, balance, span)

Datasets
  base      crisis_episodes.csv           (manuscript panel: n=81, 15 verified + 66 estimated)
  extended  crisis_episodes_extended.csv  (1984-2025, ~60+ real episodes; superset for validation)
  merged    base ∪ extended, de-duplicated on (episode, year); use for full validation suite

Reliability filtering mirrors crisis_fit.load_episodes:
  verified  → only primary-source-verified rows
  estimated → verified + FDIC/CB reconstructions (default)
  all       → include stylised counterfactuals too (for stress demos only)
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict
import pandas as pd

_DATA = Path(__file__).parent.parent / "data" / "cache"
_FILES = {
    "base":     _DATA / "crisis_episodes.csv",
    "extended": _DATA / "crisis_episodes_extended.csv",
}


def available() -> List[str]:
    keys = [k for k, p in _FILES.items() if p.exists()]
    if all(_FILES[k].exists() for k in ("base", "extended")):
        keys.append("merged")
    return keys


def _read(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, comment="#")
    if "reliability" not in df.columns:
        df["reliability"] = "verified"
    return df


def load(dataset: str = "merged", min_reliability: str = "estimated") -> pd.DataFrame:
    if dataset == "merged":
        a = _read(_FILES["base"]); b = _read(_FILES["extended"])
        df = pd.concat([a, b], ignore_index=True)
        df = df.drop_duplicates(subset=["episode", "year"], keep="last").reset_index(drop=True)
    else:
        if dataset not in _FILES or not _FILES[dataset].exists():
            raise KeyError(f"unknown/absent dataset '{dataset}'. Available: {available()}")
        df = _read(_FILES[dataset])

    if min_reliability == "verified":
        df = df[df["reliability"] == "verified"]
    elif min_reliability == "estimated":
        df = df[df["reliability"].isin(["verified", "estimated"])]
    # "all" → keep everything (including stylised)

    # attach failure_mode if the engine expects it
    if "failure_mode" not in df.columns:
        try:
            from .crisis_fit import _FAILURE_MODE
            df["failure_mode"] = df["episode"].map(lambda e: _FAILURE_MODE.get(str(e), "liquidity"))
        except Exception:
            df["failure_mode"] = "liquidity"
    return df.reset_index(drop=True)


def describe(dataset: str = "extended") -> Dict[str, object]:
    df = load(dataset, min_reliability="all")
    failed = int(df["failed"].astype(int).sum())
    n = len(df)
    rel = df["reliability"].value_counts().to_dict()
    return {
        "dataset": dataset, "n_episodes": n,
        "failed": failed, "survived": n - failed,
        "base_rate": round(max(failed, n - failed) / n, 3) if n else None,
        "year_min": int(df["year"].min()), "year_max": int(df["year"].max()),
        "reliability": {k: int(v) for k, v in rel.items()},
    }
