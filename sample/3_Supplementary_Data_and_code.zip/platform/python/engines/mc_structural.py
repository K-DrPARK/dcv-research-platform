"""
구조적 Monte Carlo 엔진 (coefficient-uncertainty propagation).

기존 monte_carlo.py 는 ±4% 하드코딩 잡음만 전파해 분포가 사실상 퇴화한다.
본 모듈은 인용된 계수 범위(engines.coeff_ranges)에서 계수를 샘플링하여
구조적 불확실성을 전파한다 → p5/p95 가 진짜 모수 불확실성을 반영.

각 draw 는 (params.seed + draw_index) 로 시드되어 완전 재현 가능하다.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple

import numpy as np

from models.params import SimulationParams
from .core         import run_simulation, _COEFF
from .coeff_ranges import sample_coeffs, n_uncertain


@dataclass
class OutputDist:
    name:   str
    mean:   float
    std:    float
    p5:     float
    p50:    float
    p95:    float
    ci90_width: float
    histogram: List[Dict]      # [{bin, count}]


@dataclass
class StructuralMcResult:
    n:               int
    only_cited:      bool
    n_uncertain:     int
    distributions:   Dict[str, OutputDist]
    seed:            int
    note:            str


_OUTPUTS = ("fail_prob", "stability", "welfare", "stress")


def _hist(arr: np.ndarray, lo: float, hi: float, bins: int = 20) -> List[Dict]:
    counts, edges = np.histogram(arr, bins=bins, range=(lo, hi))
    return [{"bin": round(float(edges[i]), 4), "count": int(counts[i])}
            for i in range(len(counts))]


def _dist(name: str, arr: np.ndarray) -> OutputDist:
    lo, hi = (0.0, 1.5) if name == "stress" else (0.0, 1.0)
    p5, p50, p95 = (float(np.percentile(arr, q)) for q in (5, 50, 95))
    return OutputDist(
        name=name,
        mean=round(float(arr.mean()), 6),
        std=round(float(arr.std(ddof=1)), 6),
        p5=round(p5, 6), p50=round(p50, 6), p95=round(p95, 6),
        ci90_width=round(p95 - p5, 6),
        histogram=_hist(arr, lo, hi),
    )


def run_structural_mc(
    params: SimulationParams,
    n: int | None = None,
    only_cited: bool = False,
) -> StructuralMcResult:
    """
    계수 사전에서 n draw 를 샘플링하여 구조적 불확실성을 전파.

    only_cited=True : 원문에 범위가 명시된 계수만 흔든다(보수적·방어적).
    """
    n = max(50, min(n or params.mc_n, 10_000))
    collected: Dict[str, List[float]] = {k: [] for k in _OUTPUTS}

    for i in range(n):
        draw_rng = np.random.default_rng(params.seed + i + 101)
        coeff_i  = sample_coeffs(draw_rng, base=_COEFF, only_cited=only_cited)
        res = run_simulation(params, seed_offset=i, coeff=coeff_i)
        s = res.summary
        collected["fail_prob"].append(s.fail_prob)
        collected["stability"].append(s.stability)
        collected["welfare"].append(s.welfare)
        collected["stress"].append(s.stress)

    dists = {k: _dist(k, np.array(v, dtype=float)) for k, v in collected.items()}

    return StructuralMcResult(
        n=n, only_cited=only_cited,
        n_uncertain=n_uncertain(only_cited),
        distributions=dists, seed=params.seed,
        note=(f"구조적 MC · {n} draws · 흔든 계수 {n_uncertain(only_cited)}개 "
              f"({'인용범위만' if only_cited else '전체 사전'}) · "
              f"삼각분포 전파"),
    )
