"""
Monte Carlo 엔진 — v4.1

통계 엔진 개선:
  1. Geweke Z-score 수렴 검정: 첫 10%와 마지막 50% 평균 비교
  2. 신뢰구간 폭 경고: CI가 0.10(10%p) 이상이면 n 증가 권고
  3. Windows spawn-safe: ProcessPoolExecutor 사용
  4. run_id: SHA-256(params+n+engine)

수렴 검정 방법론:
  Geweke (1992) Z-score: Z = (μ_A - μ_B) / sqrt(σ²_A/n_A + σ²_B/n_B)
  |Z| < 1.96이면 수렴 (95% 유의수준)
  n_A = 상위 10%, n_B = 하위 50% (Gelman et al. 2013 권장)
"""
from __future__ import annotations

import os, sys, warnings, concurrent.futures
from typing import List

import numpy as np

from models.params  import SimulationParams
from models.results import McResult, HistBin

_IS_WINDOWS = sys.platform.startswith("win")


def _worker(args: tuple) -> float:
    params, offset = args
    from engines.core import run_simulation
    return run_simulation(params, seed_offset=offset).summary.fail_prob


def _safe_n_workers() -> int:
    env = os.environ.get("MC_WORKERS")
    if env:
        return max(1, int(env))
    return 1 if _IS_WINDOWS else min(os.cpu_count() or 1, 8)


def _geweke_z(arr: np.ndarray) -> float:
    """
    Geweke (1992) Z-score 수렴 검정.
    처음 10%와 마지막 50%의 평균 차이를 표준오차로 나눔.
    |Z| < 1.96 → 수렴.
    """
    n    = len(arr)
    n_a  = max(1, n // 10)          # 처음 10%
    n_b  = max(1, n // 2)           # 마지막 50%
    a    = arr[:n_a]
    b    = arr[n - n_b:]
    se   = np.sqrt(np.var(a, ddof=1) / len(a) + np.var(b, ddof=1) / len(b))
    if se < 1e-12:
        return 0.0
    return float((np.mean(a) - np.mean(b)) / se)


def run_monte_carlo(params: SimulationParams) -> McResult:
    """
    N회 독립 Monte Carlo 시뮬레이션.

    수렴 검정 (Geweke Z-score):
      |Z| < 1.96 → 수렴 ✓
      |Z| ≥ 1.96 → 경고: n 증가 권고

    신뢰구간 경고:
      CI폭(p95-p5) ≥ 0.10 → n 증가 권고
    """
    n         = max(10, min(params.mc_n, 10_000))
    n_workers = _safe_n_workers()
    args      = [(params, i) for i in range(n)]

    if n_workers == 1:
        fail_probs: List[float] = [_worker(a) for a in args]
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=n_workers) as ex:
            fail_probs = list(ex.map(_worker, args))

    arr = np.array(fail_probs, dtype=np.float64)

    # ── Geweke 수렴 검정 ─────────────────────────────────────────────────────
    geweke_z = _geweke_z(arr)
    converged = abs(geweke_z) < 1.96
    if not converged:
        warnings.warn(
            f"MC Geweke Z-score={geweke_z:.3f} ≥ 1.96 — 수렴 미달. "
            f"현재 n={n}. mc_n을 {min(n*2, 10000)}으로 늘리면 개선될 수 있음. "
            f"[Geweke 1992: Computing Science and Statistics 24, 169-194]",
            UserWarning, stacklevel=2,
        )

    # ── 신뢰구간 폭 경고 ─────────────────────────────────────────────────────
    p5  = float(np.percentile(arr,  5))
    p95 = float(np.percentile(arr, 95))
    ci_width = p95 - p5
    if ci_width >= 0.10:
        warnings.warn(
            f"MC 90% CI폭={ci_width:.3f} ≥ 0.10 (10%p). "
            f"n={n}에서 추정치 불확실성이 큼. mc_n≥{min(n*4, 10000)} 권장.",
            UserWarning, stacklevel=2,
        )

    # ── 히스토그램 ────────────────────────────────────────────────────────────
    counts, edges = np.histogram(arr, bins=20, range=(0.0, 1.0))
    histogram = [
        HistBin(bin=round(float(edges[i]), 4), count=int(counts[i]))
        for i in range(len(counts))
    ]

    # ── run_id ───────────────────────────────────────────────────────────────
    import hashlib as _hlib, json as _json
    from datetime import datetime, timezone
    from engines.core import ENGINE_VERSION
    _rid_payload = _json.dumps(
        {"params": params.model_dump(), "n": n, "engine": ENGINE_VERSION},
        sort_keys=True, default=str,
    )
    _run_id = _hlib.sha256(_rid_payload.encode()).hexdigest()

    return McResult(
        mean_fail_prob=round(float(arr.mean()), 6),
        std_fail_prob=round(float(arr.std(ddof=1)), 6),
        p5=round(p5, 6),
        p95=round(p95, 6),
        n=n,
        histogram=histogram,
        run_id=_run_id,
        engine_version=ENGINE_VERSION,
        ran_at=datetime.now(timezone.utc).isoformat(),
        # 수렴 정보를 method_note로 전달
        method_note=(
            f"Geweke Z={geweke_z:.3f} ({'수렴' if converged else '⚠미달'}) | "
            f"CI폭={ci_width:.3f} ({'OK' if ci_width < 0.10 else '⚠넓음'})"
        ),
    )
