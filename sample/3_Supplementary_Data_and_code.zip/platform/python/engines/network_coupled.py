"""
네트워크 결합 emergence 엔진 — 임계전이(critical transition) + 이력현상(hysteresis).

기존 core 는 입력의 매끄러운 단조 함수라 복잡계의 본질(창발)이 없었고,
은행간 네트워크(network.py)는 core 와 분리된 사일로였다. 본 모듈은 둘을 결합한다.

이론적 토대
───────────
은행간 손실전파 행렬 M_ij = (j→i 익스포저)·LGD / equity_i 의
스펙트럼 반경 λ_max 가 cascade 증폭 이득을 결정한다(May 1972; Haldane–May 2011;
Gai–Kapadia 2010). λ_max 가 클수록 작은 충격이 시스템 전체로 증폭된다.

이 λ_max 를 자기일관(self-consistent) 곤경분율 방정식의 피드백 이득으로 결합:

    x* = σ( a·( w_s·S + g(λ_max)·x* − θ ) )                         (★)

여기서 x* = 곤경 은행 분율, S = 충격, σ = 로지스틱. 피드백 이득 a·g 가
임계(=4, σ 최대기울기 1/4의 역수)를 넘으면 (★)은 **세 개의 고정점**
(calm·불안정·cascade)을 가져 쌍안정(bistable)이 된다. 충격을 올렸다 내리면
상승 경로와 하강 경로가 달라지는 **이력현상**이 창발하며, 두 안장-마디
(saddle-node) 접힘점이 위기 진입/탈출 임계충격을 정의한다.

집중도↑ → 익스포저 편중↑ → λ_max↑ → 이력 루프 확대 (해석: 집중된 은행
시스템일수록 위기에서 빠져나오기 어렵다).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import math

import numpy as np

from models.params import SimulationParams
from .core import run_simulation

# ── 결합 맵 파라미터 (쌍안정 영역에 들도록 보정) ──────────────────────────────
_A      = 10.0      # 곤경공간 시그모이드 기울기
_THETA  = 0.62      # 곤경 전환 임계 (calm 상태를 0 근처로 유지)
_WS     = 1.0       # 외생 충격 → 곤경 구동 가중
_G_MIN  = 0.42      # 피드백 이득 하한
_G_MAX  = 0.72      # 상한 (a·g_max ≈ 7.2, 충분히 쌍안정)
_LAMSCALE = 250.0   # λ_max → g 포화 스케일


def _sigmoid(z: float) -> float:
    if z < -50: return 0.0
    if z >  50: return 1.0
    return 1.0 / (1.0 + math.exp(-z))


# ── 손실전파 행렬 & 스펙트럼 반경 ─────────────────────────────────────────────
def _loss_matrix(params: SimulationParams, n_banks: int = 28,
                 lgd: float = 0.6) -> np.ndarray:
    """
    은행간 손실전파 행렬 M_ij = (j→i 익스포저)·LGD / equity_i.
    실제 네트워크(network.py, Watts-Strogatz+gravity)에서 읽되, networkx 가
    없으면 동일 gravity 규칙의 numpy 재현(재현 가능)으로 폴백한다.
    """
    try:
        from .network import build_interbank_network
        G = build_interbank_network(params, n_banks=n_banks, seed=params.seed + 5555)
        ids = list(G.nodes)
        idx = {b: i for i, b in enumerate(ids)}
        n = len(ids)
        W = np.zeros((n, n))
        for u, v, data in G.edges(data=True):
            W[idx[u], idx[v]] += float(data.get("weight", 0.0))   # u→v 익스포저
        equity = np.array([float(G.nodes[b].get("equity", 1e-6)) for b in ids])
    except Exception:
        # 폴백: gravity 링 구성 (network.py 와 동일 규칙, 결정론적)
        rng = np.random.default_rng(params.seed + 5555)
        n = n_banks
        k = params.concentration * 1.4
        sizes = np.array([1.0 / (i + 1) ** k for i in range(n)]); sizes /= sizes.sum()
        W = np.zeros((n, n))
        for i in range(n):
            for off in (1, 2):
                j = (i + off) % n
                w = 100 * sizes[i] * sizes[j] / (sizes.sum() ** 2)
                W[i, j] += w; W[j, i] += w * 0.6
        equity = sizes * 0.08

    equity = np.clip(equity, 1e-9, None)
    # M_ij = (j→i 익스포저)·LGD / equity_i  →  W[j,i] 가 j→i
    M = (W.T * lgd) / equity[:, None]
    return M


def network_gain(params: SimulationParams) -> Dict[str, float]:
    """네트워크 구조 → cascade 이득 g 및 진단량."""
    M = _loss_matrix(params)
    lam = float(np.max(np.abs(np.linalg.eigvals(M))))
    deg = float((M != 0).sum(axis=1).mean())
    n = M.shape[0]
    density = float((M != 0).sum() / max(n * (n - 1), 1))
    g = _G_MIN + (_G_MAX - _G_MIN) * (1.0 - math.exp(-lam / _LAMSCALE))
    return {"lambda_max": round(lam, 4), "g": round(g, 4),
            "feedback_gain": round(_A * g, 4), "mean_degree": round(deg, 3),
            "density": round(density, 4), "bistable_capable": _A * g > 4.0}


# ── 자기일관 곤경 고정점 ──────────────────────────────────────────────────────
def equilibrium_distress(g: float, shock: float, x0: float = 0.0,
                         iters: int = 400, relax: float = 0.5) -> float:
    """warm-start x0 에서 (★)을 반복 수렴 → 안정 고정점."""
    x = x0
    for _ in range(iters):
        target = _sigmoid(_A * (_WS * shock + g * x - _THETA))
        x_new = (1 - relax) * x + relax * target
        if abs(x_new - x) < 1e-9:
            x = x_new; break
        x = x_new
    return float(np.clip(x, 0.0, 1.0))


# ── 이력현상 스윕 ─────────────────────────────────────────────────────────────
@dataclass
class HysteresisResult:
    shocks_up:      List[float]
    distress_up:    List[float]
    shocks_down:    List[float]
    distress_down:  List[float]
    loop_area:      float            # 이력 루프 면적 (0 이면 단일 안정상태)
    critical_up:    Optional[float]  # 진입 임계충격 (상승 접힘점)
    critical_down:  Optional[float]  # 탈출 임계충격 (하강 접힘점)
    is_hysteretic:  bool
    gain:           Dict[str, float]


def sweep_hysteresis(params: SimulationParams,
                     lo: float = 0.0, hi: float = 1.0,
                     steps: int = 60) -> HysteresisResult:
    """
    충격을 lo→hi 로 올린 뒤 hi→lo 로 내리며, 각 단계에서 직전 평형을
    warm-start 로 사용(continuation). 쌍안정이면 상승/하강 경로가 갈라진다.
    """
    gain = network_gain(params)
    g = gain["g"]

    up_s = list(np.linspace(lo, hi, steps))
    up_x: List[float] = []
    x = 0.0
    for S in up_s:
        x = equilibrium_distress(g, S, x0=x)
        up_x.append(x)

    down_s = list(np.linspace(hi, lo, steps))
    down_x: List[float] = []
    for S in down_s:
        x = equilibrium_distress(g, S, x0=x)
        down_x.append(x)

    # 루프 면적: 동일 충격에서 (하강 - 상승) 곤경 차이의 적분
    down_x_aligned = list(reversed(down_x))   # lo→hi 정렬
    diff = np.abs(np.array(down_x_aligned) - np.array(up_x))
    xs = np.asarray(up_s)
    loop_area = float(np.sum((diff[:-1] + diff[1:]) / 2.0 * np.diff(xs)))  # 사다리꼴

    # 접힘점 탐지: 곤경이 급격히 점프하는 충격
    def _jump(s, xarr):
        d = np.abs(np.diff(xarr))
        if len(d) and d.max() > 0.20:
            return float(s[int(np.argmax(d))])
        return None
    crit_up   = _jump(up_s, up_x)
    crit_down = _jump(down_s, down_x)

    is_hyst = loop_area > 0.01 and crit_up is not None

    return HysteresisResult(
        shocks_up=[round(s, 4) for s in up_s],
        distress_up=[round(v, 4) for v in up_x],
        shocks_down=[round(s, 4) for s in down_s],
        distress_down=[round(v, 4) for v in down_x],
        loop_area=round(loop_area, 4),
        critical_up=round(crit_up, 4) if crit_up is not None else None,
        critical_down=round(crit_down, 4) if crit_down is not None else None,
        is_hysteretic=is_hyst, gain=gain,
    )


# ── 결합 시계열 (네트워크 곤경 → core 피드백) ─────────────────────────────────
@dataclass
class CoupledDay:
    day:               int
    shock_wave:        float
    distress:          float   # 네트워크 곤경 분율 x_t
    stability_uncoupled: float
    stability_coupled: float
    stress_coupled:    float
    tipped:            bool


@dataclass
class CoupledResult:
    series:         List[CoupledDay]
    gain:           Dict[str, float]
    tipping_day:    Optional[int]
    max_distress:   float
    note:           str
    fingerprint:    str = ""   # SHA-256(params+gain) — 재현성 추적
    engine_version: str = ""


def run_coupled_simulation(params: SimulationParams) -> CoupledResult:
    """
    core 의 일별 stress 시계열에 네트워크 곤경 피드백을 결합.
    곤경 x_t 는 직전 일을 warm-start 로 이어받아 시간적 이력(memory)을 가진다.
    충격파가 진입 임계를 넘는 순간 시스템이 cascade 상태로 창발적 전이.
    """
    base = run_simulation(params)
    gain = network_gain(params)
    g = gain["g"]

    lam_shock = 5.0
    days = params.days
    series: List[CoupledDay] = []
    x = 0.0
    tipping_day: Optional[int] = None
    max_x = 0.0

    for pt in base.series:
        d = pt.day
        t = d / days
        shock_wave = params.shock * (1 - math.exp(-lam_shock * t))
        # 네트워크 곤경 평형 (전날 상태에서 이어받음)
        x_prev = x
        x = equilibrium_distress(g, shock_wave, x0=x_prev)
        max_x = max(max_x, x)
        tipped = x > 0.5
        if tipped and tipping_day is None:
            tipping_day = d
        # core 안정성/스트레스에 곤경 피드백
        stab_coupled  = float(np.clip(pt.stability * (1 - x), 0.0, 1.0))
        stress_coupled = float(np.clip(pt.stress + x * 0.5, 0.0, 1.5))
        series.append(CoupledDay(
            day=d, shock_wave=round(shock_wave, 4), distress=round(x, 4),
            stability_uncoupled=round(pt.stability, 4),
            stability_coupled=round(stab_coupled, 4),
            stress_coupled=round(stress_coupled, 4), tipped=tipped,
        ))

    return CoupledResult(
        series=series, gain=gain, tipping_day=tipping_day,
        max_distress=round(max_x, 4),
        note=(f"λ_max={gain['lambda_max']} · 피드백이득 a·g={gain['feedback_gain']} "
              f"({'쌍안정 가능' if gain['bistable_capable'] else '단일안정'}) · "
              f"{'창발적 전이 발생 (day '+str(tipping_day)+')' if tipping_day else '전이 없음'}"),
    )
