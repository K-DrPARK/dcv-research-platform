"""
ols_calibration.py — Reduced-form OLS/MLE calibration of the crisis-outflow channel.

This module implements the *empirically estimated* part of the manuscript
(Tier A): the reduced-form regression of peak deposit outflow on shock severity
and the concentration x shock interaction, estimated on the n=81 historical
episode panel. It is pure numpy/scipy (no statsmodels), so it runs in the same
clean environment as the simulation engine.

Specifications implemented
  table2(df)        peak_outflow ~ kappa + theta1*S + theta2*(C*S)      (manuscript Table 2)
  appendix_f(df)    peak_outflow ~ kappa + C       + theta2*(C*S)      (manuscript Appendix F / Table F2)
  strata(df)        Appendix-F spec on verified-only / estimated-only subsets
  two_regime(df)    Table-2 spec on digital (S>0.70 & D>0.70) vs traditional regimes
  meas_error_boot   Appendix E.1 measurement-error bootstrap (+-5pp on estimated rows)

Every function returns plain dataclasses/dicts so reproduce.py can fingerprint
and compare them against the manuscript values directly.

NOTE ON REPRODUCTION HONESTY
  These routines report whatever the *shipped panel* implies. Where the shipped
  covariate values differ from the manuscript's regression panel, the sign and
  significance reproduce but the exact magnitude may not. reproduce.py compares
  against the manuscript with an explicit tolerance and reports PASS/FAIL rather
  than asserting a match. See paper/REPRODUCTION_REPORT.md.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional
import numpy as np
from scipy import stats


# ────────────────────────────────────────────────────────────────────────────
# Core OLS with analytic SE / t / p / R2 / AIC / BIC (Gaussian MLE).
# ────────────────────────────────────────────────────────────────────────────
@dataclass
class OlsFit:
    names:  List[str]
    beta:   List[float]
    se:     List[float]
    t:      List[float]
    p:      List[float]
    n:      int
    dof:    int
    r2:     float
    rmse:   float
    aic:    float
    bic:    float

    def coef(self, name: str) -> Dict[str, float]:
        i = self.names.index(name)
        return {"est": self.beta[i], "se": self.se[i], "t": self.t[i], "p": self.p[i]}

    def as_dict(self) -> dict:
        return asdict(self)


def _ols(y: np.ndarray, X: np.ndarray, names: List[str]) -> OlsFit:
    y = np.asarray(y, float)
    X = np.asarray(X, float)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    n, k = X.shape
    dof = n - k
    ss_res = float(resid @ resid)
    ss_tot = float(((y - y.mean()) ** 2).sum())
    sigma2 = ss_res / dof
    XtX_inv = np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(sigma2 * XtX_inv))
    t = beta / se
    p = 2 * (1 - stats.t.cdf(np.abs(t), dof))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    rmse = float(np.sqrt(ss_res / n))
    # Gaussian log-likelihood at MLE (sigma^2 = ss_res/n)
    ll = -0.5 * n * (np.log(2 * np.pi) + np.log(ss_res / n) + 1)
    aic = 2 * k - 2 * ll
    bic = k * np.log(n) - 2 * ll
    return OlsFit(
        names=list(names),
        beta=[round(float(b), 4) for b in beta],
        se=[round(float(s), 4) for s in se],
        t=[round(float(tt), 3) for tt in t],
        p=[round(float(pp), 4) for pp in p],
        n=int(n), dof=int(dof),
        r2=round(float(r2), 4), rmse=round(rmse, 4),
        aic=round(float(aic), 2), bic=round(float(bic), 2),
    )


# ────────────────────────────────────────────────────────────────────────────
# Panel access (pure-pandas; falls back to csv if needed).
# ────────────────────────────────────────────────────────────────────────────
def _vec(df, col):
    return np.asarray(df[col].astype(float).to_numpy())


def load_panel(dataset: str = "base"):
    """Load the calibration panel as a DataFrame (uses historical_loader)."""
    from engines import historical_loader
    # min_reliability='estimated' keeps verified+estimated, drops stylised — the n=81 panel
    return historical_loader.load(dataset, min_reliability="estimated").reset_index(drop=True)


# ────────────────────────────────────────────────────────────────────────────
# Specifications.
# ────────────────────────────────────────────────────────────────────────────
def table2(df) -> OlsFit:
    """Manuscript Table 2: peak_outflow ~ kappa + theta1*S + theta2*(C*S)."""
    y = _vec(df, "peak_outflow"); C = _vec(df, "concentration"); S = _vec(df, "severity")
    X = np.column_stack([np.ones(len(y)), S, C * S])
    return _ols(y, X, ["kappa", "theta1_S", "theta2_CxS"])


def appendix_f(df) -> OlsFit:
    """Manuscript Appendix F / Table F2: peak_outflow ~ kappa + C + theta2*(C*S)."""
    y = _vec(df, "peak_outflow"); C = _vec(df, "concentration"); S = _vec(df, "severity")
    X = np.column_stack([np.ones(len(y)), C, C * S])
    return _ols(y, X, ["kappa", "C", "theta2_CxS"])


def table2b(df) -> OlsFit:
    """Manuscript Table 2b: peak_outflow ~ kappa + theta1*S + theta2*(C*S) + theta3*D.

    Extended specification that adds digital adoption D as a direct regressor to test
    whether omitting D biases the headline concentration x shock estimate. The manuscript claim
    is that theta2 stays positive/significant and theta3 (D) is not significant.
    """
    y = _vec(df, "peak_outflow"); C = _vec(df, "concentration")
    S = _vec(df, "severity"); D = _vec(df, "digital")
    X = np.column_stack([np.ones(len(y)), S, C * S, D])
    return _ols(y, X, ["kappa", "theta1_S", "theta2_CxS", "theta3_D"])


def weighted_appendix_f(df, verified_weight: float = 1.0, estimated_weight: float = 1.0) -> OlsFit:
    """Reliability-weighted WLS on the Appendix F specification:
    peak_outflow ~ kappa + C + theta2*(C*S), with per-row weight = verified_weight
    if reliability=='verified' else estimated_weight. Equal weights (1.0/1.0)
    reduce to the unweighted Appendix F OLS in appendix_f(). This closes the gap
    documented in the manuscript: prior revisions reported reliability-weighted
    figures (Verified=1.0/Estimated=0.50 and 0.30) that this module could not
    yet reproduce because no WLS routine existed in the shipped package.
    """
    y = _vec(df, "peak_outflow"); C = _vec(df, "concentration"); S = _vec(df, "severity")
    X = np.column_stack([np.ones(len(y)), C, C * S])
    if "reliability" in df.columns:
        w = np.where(df["reliability"].to_numpy() == "verified", verified_weight, estimated_weight)
    else:
        w = np.ones(len(y))
    W = np.diag(w)
    XtW = X.T @ W
    beta = np.linalg.solve(XtW @ X, XtW @ y)
    resid = y - X @ beta
    n, k = X.shape
    dof = n - k
    sigma2 = float(resid @ W @ resid) / dof
    cov = sigma2 * np.linalg.inv(XtW @ X)
    se = np.sqrt(np.diag(cov))
    t = beta / se
    p = 2 * (1 - stats.t.cdf(np.abs(t), dof))
    ss_res = float(resid @ W @ resid)
    y_bar = float((w * y).sum() / w.sum())
    ss_tot = float((w * (y - y_bar) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return OlsFit(
        names=["kappa", "C", "theta2_CxS"],
        beta=[round(float(b), 4) for b in beta],
        se=[round(float(s), 4) for s in se],
        t=[round(float(tt), 3) for tt in t],
        p=[round(float(pp), 4) for pp in p],
        n=int(n), dof=int(dof),
        r2=round(float(r2), 4), rmse=round(float(np.sqrt(ss_res / n)), 4),
        aic=float("nan"), bic=float("nan"),
    )


def strata(df) -> Dict[str, OlsFit]:
    """Appendix-F spec on verified-only and estimated-only strata."""
    out: Dict[str, OlsFit] = {"full": appendix_f(df)}
    if "reliability" in df.columns:
        for key in ("verified", "estimated"):
            sub = df[df["reliability"] == key]
            if len(sub) > 3:
                out[key] = appendix_f(sub)
    return out


def two_regime(df) -> Dict[str, OlsFit]:
    """Table-2 spec split into digital (S>0.70 & D>0.70) vs traditional regimes."""
    S = _vec(df, "severity"); D = _vec(df, "digital")
    digital = (S > 0.70) & (D > 0.70)
    out: Dict[str, OlsFit] = {}
    out["digital"] = table2(df[digital]) if digital.sum() > 3 else None
    out["traditional"] = table2(df[~digital]) if (~digital).sum() > 3 else None
    out["n_digital"] = int(digital.sum())
    out["n_traditional"] = int((~digital).sum())
    return out


def meas_error_bootstrap(df, n_boot: int = 200, eps: float = 0.05,
                         seed: int = 20260618) -> Dict[str, float]:
    """Appendix E.1: perturb estimated-episode peak_outflow by U(-eps,+eps),
    re-estimate Table-2 theta2 each draw; verified rows held exact."""
    rng = np.random.RandomState(seed)
    y0 = _vec(df, "peak_outflow"); C = _vec(df, "concentration"); S = _vec(df, "severity")
    est_mask = (df["reliability"].to_numpy() == "estimated") if "reliability" in df.columns \
        else np.ones(len(y0), bool)
    draws = []
    for _ in range(n_boot):
        y = y0.copy()
        noise = rng.uniform(-eps, eps, est_mask.sum())
        y[est_mask] = np.clip(y[est_mask] + noise, 0.0, 0.50)
        X = np.column_stack([np.ones(len(y)), S, C * S])
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        draws.append(float(beta[2]))
    draws = np.array(draws)
    return {
        "n_boot": n_boot, "eps": eps,
        "mean_theta2": round(float(draws.mean()), 4),
        "std_theta2": round(float(draws.std(ddof=1)), 4),
        "pct5": round(float(np.percentile(draws, 5)), 4),
        "pct95": round(float(np.percentile(draws, 95)), 4),
        "pct_positive": round(float((draws > 0).mean()), 4),
        "pct_gt_0p1": round(float((draws > 0.1).mean()), 4),
    }


# ────────────────────────────────────────────────────────────────────────────
# One-shot summary used by reproduce.py --calibration.
# ────────────────────────────────────────────────────────────────────────────
def run_calibration(dataset: str = "base", n_boot: int = 200) -> dict:
    df = load_panel(dataset)
    t2 = table2(df)
    t2b = table2b(df)
    fF = appendix_f(df)
    st = strata(df)
    tr = two_regime(df)
    me = meas_error_bootstrap(df, n_boot=n_boot)
    return {
        "n": int(len(df)),
        "table2": t2.as_dict(),
        "table2_theta2": t2.coef("theta2_CxS"),
        "table2b": t2b.as_dict(),
        "table2b_theta2": t2b.coef("theta2_CxS"),
        "table2b_theta3_D": t2b.coef("theta3_D"),
        "appendix_f_full_theta2": fF.coef("theta2_CxS"),
        "verified_only_theta2": st["verified"].coef("theta2_CxS") if "verified" in st else None,
        "estimated_only_theta2": st["estimated"].coef("theta2_CxS") if "estimated" in st else None,
        "two_regime": {
            "n_digital": tr["n_digital"], "n_traditional": tr["n_traditional"],
            "digital_theta2": tr["digital"].coef("theta2_CxS") if tr["digital"] else None,
            "traditional_theta2": tr["traditional"].coef("theta2_CxS") if tr["traditional"] else None,
        },
        "measurement_error_boot": me,
    }
