"""
다국가 패널 시뮬레이션 엔진.

사용자 요청: 한국/EU/중국 동시 시뮬레이션 → 국가별 최적 CBDC 설계 비교.

핵심 기능
─────────
1. run_panel(): 국가 리스트를 받아 각국 프리셋(에이전트·디지털·집중도·임계값)을
   기준 파라미터에 덧씌워 동일 시드·동일 위기 시나리오로 동시 실행.
2. optimize_design(): 각국별로 설계공간을 격자 탐색하여
   "fail_prob < threshold 제약 하에서 welfare 최대화" 최적 CBDC 설계를 찾는다.
   탐색 차원: arch × tiered × dynamic_cap × lolr × fire_sale.
3. 결과를 국가 간 비교 가능한 표 형태로 반환.

재현성: 모든 실행은 base seed 고정. 국가별 seed_offset 으로 분리.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from itertools import product
from typing import List, Dict, Optional

from models.params import SimulationParams, AgentConfig, WelfareWeights
from data.country_presets import COUNTRY_PRESETS, DEFAULT_PANEL


# panel 모듈은 core 만 의존 (SALib/networkx 불필요)
def _run(params: SimulationParams, seed_offset: int = 0):
    from engines.core import run_simulation
    return run_simulation(params, seed_offset=seed_offset)


def _coerce_agents(agents) -> List[AgentConfig]:
    """dict/AgentConfig 혼재 입력을 AgentConfig 리스트로 통일 (pydantic 버전 무관 견고)."""
    out: List[AgentConfig] = []
    for a in agents:
        if isinstance(a, AgentConfig):
            out.append(a)
        elif isinstance(a, dict):
            out.append(AgentConfig(**a))
        else:  # 객체 속성 접근
            out.append(AgentConfig(key=a.key, name=a.name, share=a.share,
                                   digital=a.digital, risk=a.risk))
    return out

def _coerce_params(p: SimulationParams) -> SimulationParams:
    """중첩 모델(agents, weights)을 객체로 통일 (pydantic 버전/셰임 무관 견고)."""
    p.agents = _coerce_agents(p.agents)
    w = getattr(p, "weights", None)
    if isinstance(w, dict):
        p.weights = WelfareWeights(**w)
    return p


@dataclass
class CountryRun:
    country:    str
    name:       str
    fail_prob:  float
    stability:  float
    stress:     float
    welfare:    float
    failed:     float
    lolr_support: float
    threshold:  float
    final_outflow: float
    safe:       bool                 # fail_prob < threshold-기반 안전 판정
    fingerprint: str
    welfare_norm: float = 0.0   # ④ [0,1] 정규화 welfare (BAR16 스케일); 기본값 필드는 맨 끝


@dataclass
class OptimalDesign:
    country:     str
    name:        str
    arch:        str
    tiered:      bool
    dynamic_cap: bool
    lolr:        bool
    fire_sale_enabled: bool
    welfare:     float
    fail_prob:   float
    feasible:    bool                # 제약(fail_prob<threshold) 충족 여부
    rationale:   str
    n_evaluated: int


@dataclass
class PanelResult:
    countries:       List[str]
    runs:            List[CountryRun]
    optimal:         List[OptimalDesign]
    ranking:         List[Dict]       # welfare 내림차순 국가 랭킹
    base_seed:       int
    note:            str


def _params_for_country(base: SimulationParams, key: str,
                        seed_offset_index: int) -> SimulationParams:
    """기준 파라미터에 국가 프리셋을 덧씌운 SimulationParams 생성."""
    preset = COUNTRY_PRESETS[key]
    d = base.model_dump()
    d.update(
        country=key,
        digital=preset.digital,
        cash=preset.cash,
        concentration=preset.concentration,
        threshold=preset.threshold,
        rate2=preset.rate2,
        rate3=preset.rate3,
        cap=preset.cap,
        agents=[AgentConfig(key=a.key, name=a.name, share=a.share,
                            digital=a.digital, risk=a.risk)
                for a in preset.agents],
    )
    return _coerce_params(SimulationParams(**d))


def run_panel(
    base: SimulationParams,
    countries: Optional[List[str]] = None,
) -> PanelResult:
    """국가별 동시 시뮬레이션."""
    countries = countries or DEFAULT_PANEL
    runs: List[CountryRun] = []

    for i, key in enumerate(countries):
        if key not in COUNTRY_PRESETS:
            continue
        preset = COUNTRY_PRESETS[key]
        p = _params_for_country(base, key, i)
        r = _run(p, seed_offset=i)
        last = r.series[-1]
        # 안전 판정: 최종 안정성이 임계값 이상 + 실패확률 낮음
        safe = (last.stability >= preset.threshold) and (r.summary.fail_prob < 0.5)
        runs.append(CountryRun(
            country=key, name=preset.name,
            fail_prob=r.summary.fail_prob, stability=r.summary.stability,
            stress=r.summary.stress, welfare=r.summary.welfare,
            welfare_norm=round((r.summary.welfare + 0.50) / 1.00, 4),  # ④
            failed=r.summary.failed, lolr_support=r.summary.lolr_support,
            threshold=preset.threshold, final_outflow=last.outflow,
            safe=safe, fingerprint=r.fingerprint[:16],
        ))

    optimal = [optimize_design(base, c, i) for i, c in enumerate(countries)
               if c in COUNTRY_PRESETS]

    ranking = sorted(
        [{"country": r.country, "name": r.name,
          "welfare": round(r.welfare, 4), "fail_prob": round(r.fail_prob, 4),
          "safe": r.safe} for r in runs],
        key=lambda x: x["welfare"], reverse=True,
    )

    return PanelResult(
        countries=countries, runs=runs, optimal=optimal, ranking=ranking,
        base_seed=base.seed,
        note=f"{len(runs)}개국 동시 시뮬레이션 · base_seed={base.seed} · "
             f"국가별 프리셋 보정 적용",
    )


# ── 국가별 최적 설계 탐색 ─────────────────────────────────────────────────────
_ARCH_SPACE       = ["two_tier", "account", "token"]
_BOOL_SPACE       = [True, False]


def optimize_design(
    base: SimulationParams,
    country: str,
    seed_offset: int = 0,
) -> OptimalDesign:
    """
    제약 최적화: max welfare  s.t. fail_prob < threshold.
    설계공간 = arch × tiered × dynamic_cap × lolr × fire_sale (3·2·2·2·2 = 48).
    """
    preset = COUNTRY_PRESETS[country]
    base_country = _params_for_country(base, country, seed_offset)

    best: Optional[OptimalDesign] = None
    best_feasible_welfare = -1e9
    best_any_welfare = -1e9
    best_any: Optional[OptimalDesign] = None
    n = 0
    fail_cap = min(preset.threshold, 0.20)   # 제약: fail_prob 상한

    for arch, tiered, dyncap, lolr, fire in product(
        _ARCH_SPACE, _BOOL_SPACE, _BOOL_SPACE, _BOOL_SPACE, _BOOL_SPACE
    ):
        n += 1
        d = base_country.model_dump()
        d.update(arch=arch, tiered=tiered, dynamic_cap=dyncap,
                 lolr=lolr, fire_sale_enabled=fire)
        p = _coerce_params(SimulationParams(**d))
        r = _run(p, seed_offset=seed_offset)
        w, fp = r.summary.welfare, r.summary.fail_prob
        feasible = fp < fail_cap

        cand = OptimalDesign(
            country=country, name=preset.name, arch=arch, tiered=tiered,
            dynamic_cap=dyncap, lolr=lolr, fire_sale_enabled=fire,
            welfare=round(w, 4), fail_prob=round(fp, 4), feasible=feasible,
            rationale="", n_evaluated=0,
        )
        if feasible and w > best_feasible_welfare:
            best_feasible_welfare = w
            best = cand
        if w > best_any_welfare:
            best_any_welfare = w
            best_any = cand

    chosen = best or best_any
    chosen.n_evaluated = n
    if best:
        chosen.rationale = (
            f"제약(fail_prob<{fail_cap:.2f}) 충족 설계 중 welfare 최대. "
            f"arch={chosen.arch}, tiered={'ON' if chosen.tiered else 'OFF'}, "
            f"dyn_cap={'ON' if chosen.dynamic_cap else 'OFF'}, "
            f"LOLR={'ON' if chosen.lolr else 'OFF'}."
        )
    else:
        chosen.rationale = (
            f"제약(fail_prob<{fail_cap:.2f})을 만족하는 설계 없음 → "
            f"welfare 최대 설계 제시(주의: 위험 임계 초과)."
        )
    return chosen


# ══════════════════════════════════════════════════════════════════════════════
# welfare 가중치 강건성 분석
# 심사위원 질문 대응: "가중치를 어떻게 결정했습니까? 민감도는?"
# ══════════════════════════════════════════════════════════════════════════════

from dataclasses import dataclass as _dc
from typing import Dict as _Dict, List as _List
import itertools as _itertools

@_dc
class WelfareRobustnessRow:
    weight_variant:     str
    weights:            dict
    country_rankings:   _List[str]   # 국가 이름 순위 (1위→N위)
    rank_changed:       bool         # 기본 가중치 대비 순위 변화 여부
    welfare_range:      float        # 국가 간 welfare 범위 (클수록 변별력 높음)


def welfare_weight_robustness(
    countries: _List[str] = None,
    perturbation: float = 0.50,
    scenario: str = "auto",
) -> dict:
    """
    welfare 가중치 ±perturbation% 변화 시 국가 간 순위 변화 분석.

    논문 방어 논리:
        "가중치를 ±50% 변화시켜도 국가 간 순위가 유지된다면
         결론이 특정 가중치 선택에 강건함을 의미."

    Parameters
    ----------
    countries      : 비교 국가 목록 (None이면 기본 5개국)
    perturbation   : 가중치 변화 비율 (0.50 = ±50%)
    scenario       : "auto" 또는 구체 파라미터
    """
    if countries is None:
        countries = ["korea", "us", "eu", "china", "sweden"]

    from models.params import SimulationParams, AgentConfig, WelfareWeights
    from engines.core  import run_simulation

    base_w = {"payment":0.25,"inclusion":0.10,"innovation":0.15,
               "risk":0.30,"disinter":0.15,"oper":0.05}

    # 기본 파라미터 (단순 비교용)
    def _make_params(country, weights):
        from data.country_presets import get_preset
        try:
            p = get_preset(country)
        except Exception:
            p = SimulationParams(country=country, seed=42,
                agents=[AgentConfig(key="h",name="가계",share=0.35,digital=0.65,risk=0.55),
                        AgentConfig(key="f",name="기업",share=0.20,digital=0.55,risk=0.65),
                        AgentConfig(key="e",name="고령층",share=0.15,digital=0.30,risk=0.25),
                        AgentConfig(key="d",name="디지털",share=0.15,digital=0.95,risk=0.80),
                        AgentConfig(key="w",name="고액",share=0.08,digital=0.75,risk=0.95),
                        AgentConfig(key="s",name="중소기업",share=0.07,digital=0.60,risk=0.85)],
                weights=WelfareWeights())
        return p.model_copy(update={"weights": weights})

    def _get_welfare(country, ww_dict):
        """
        welfare_norm 계산. 실패 시 None 반환.
        0.5를 반환하면 모든 국가가 동점이 되어 순위 분석 결과가 오염됨.
        호출자(_get_welfare 결과 집계 부분)에서 None 필터링 후 순위 계산.
        """
        ww = WelfareWeights(**ww_dict)
        p  = _make_params(country, ww)
        try:
            r = run_simulation(p)
            return r.summary.welfare_norm
        except Exception as _exc:
            import warnings as _w
            _w.warn(
                f"welfare 계산 실패 ({country}, {ww_dict}): {_exc}. "
                "해당 변형을 순위 분석에서 제외합니다.",
                UserWarning, stacklevel=3,
            )
            return None

    # 기본 순위 — None(계산 실패) 국가 제외
    base_welfares_raw = {c: _get_welfare(c, base_w) for c in countries}
    base_welfares     = {c: v for c, v in base_welfares_raw.items() if v is not None}
    if len(base_welfares) < 2:
        return {
            "error": "기본 가중치에서 2개 이상 국가의 welfare 계산이 실패했습니다.",
            "base_ranking": list(base_welfares_raw.keys()),
            "stability_rate": None,
            "verdict": "계산 실패 — welfare_weight_robustness 결과를 신뢰할 수 없음.",
        }
    base_ranking = sorted(base_welfares, key=lambda c: base_welfares[c], reverse=True)

    results = []
    rank_stable_count = 0
    variants_tested   = 0

    # 각 가중치 항목을 ±50% 변화
    for key in base_w:
        for mult in [1 - perturbation, 1 + perturbation]:
            new_w = dict(base_w)
            new_w[key] = round(base_w[key] * mult, 4)
            # 합이 1이 되도록 나머지 비례 조정
            total = sum(new_w.values())
            new_w = {k: round(v/total, 6) for k,v in new_w.items()}

            welfares_raw = {c: _get_welfare(c, new_w) for c in countries}
            # None 필터링: 계산 실패 국가는 순위 비교에서 제외
            welfares = {c: v for c, v in welfares_raw.items() if v is not None}
            if len(welfares) < 2:
                # 국가가 2개 미만이면 이 변형을 건너뜀
                variants_tested += 1
                continue
            # base_ranking과 동일한 국가 집합으로만 비교
            common = [c for c in base_ranking if c in welfares]
            ranking  = sorted(common, key=lambda c: welfares[c], reverse=True)
            changed  = (ranking != [c for c in base_ranking if c in welfares])
            w_range  = round(max(welfares.values()) - min(welfares.values()), 4)

            results.append(WelfareRobustnessRow(
                weight_variant=f"{key}×{mult:.2f}",
                weights=new_w,
                country_rankings=ranking,
                rank_changed=changed,
                welfare_range=w_range,
            ))
            variants_tested += 1
            if not changed:
                rank_stable_count += 1

    stability_rate = rank_stable_count / variants_tested if variants_tested else 0
    verdict = (
        f"가중치 {perturbation*100:.0f}% 변화 시 순위 안정률: {stability_rate*100:.0f}% "
        f"({rank_stable_count}/{variants_tested} 변형).\n"
        + ("→ 결론이 가중치 선택에 강건함 (안정률 ≥ 80%)."
           if stability_rate >= 0.8 else
           f"→ 일부 가중치 변화에 순위 민감. "
           f"순위 변화 발생 항목: "
           f"{[r.weight_variant for r in results if r.rank_changed][:3]}...")
    )

    return {
        "base_ranking":      base_ranking,
        "base_welfares":     {c: round(v,4) for c,v in base_welfares.items()},
        "stability_rate":    round(stability_rate, 4),
        "n_variants":        variants_tested,
        "n_stable":          rank_stable_count,
        "verdict":           verdict,
        "rows": [
            {"variant":       r.weight_variant,
             "rank_changed":  r.rank_changed,
             "ranking":       r.country_rankings,
             "welfare_range": r.welfare_range}
            for r in results
        ],
    }
