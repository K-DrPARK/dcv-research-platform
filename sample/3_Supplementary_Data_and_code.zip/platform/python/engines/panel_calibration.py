"""
패널 보정 엔진 (panel calibration).

기존 calibrate_from_empirical()는 (digital, cash, concentration) 3점에만
OLS를 적용해 R²가 사실상 무의미했다(잔차 자유도 1). 본 모듈은 이를 대체하는
국가×연도 패널 회귀를 제공한다.

방법
────
1. data.build_empirical_panel() 로 FRED 디지털결제 + BIS 집중도 패널 수집
   (국가 5 × 연도 6 = 관측치 30개).
2. 각 국가의 에이전트 구성에서 모델의 '구조적 디지털채택 지수'를 산출:
       d_hat(c) = Σ_a  share_a · digital_a            (인구가중 디지털친화도)
   이는 core.py 의 OUTFLOW_DIGITAL_SENSITIVITY 항이 사용하는 1차 구조량과 동일.
3. 패널 전체에 대해 affine OLS  d_obs = a·d_hat + b + ε 를 적합하고
   R², 조정 R², RMSE, 기울기 95% CI 를 계산한다.
4. (선택) statsmodels 가 있으면 잔차의 ADF/Jarque-Bera 진단을 덧붙인다.

R²의 해석: 모델의 에이전트 구성이 국가 간 디지털채택 서열을 얼마나
재현하는지를 측정한다. within-country 시계열 추세는 단일연도 프리셋이
설명하지 못하므로, cross-sectional(국가평균) R²도 함께 보고해 과대적합을 방지.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional

import numpy as np

try:
    import statsmodels.api as sm
    from statsmodels.tsa.stattools import adfuller
    from statsmodels.stats.stattools import jarque_bera
    _HAS_SM = True
except Exception:
    _HAS_SM = False

from data.country_presets import COUNTRY_PRESETS


@dataclass
class OlsFit:
    slope:      float
    intercept:  float
    r2:         float
    adj_r2:     float
    rmse:       float
    n:          int
    slope_ci95: List[float]            # [lo, hi]


@dataclass
class PanelCalibrationResult:
    countries:        List[str]
    n_obs:            int
    panel_fit:        OlsFit            # 전체 패널 (country×year)
    cross_section_fit: OlsFit          # 국가평균 횡단면
    per_country:      List[Dict]       # 국가별 d_obs(mean) vs d_hat
    diagnostics:      List[Dict]       # statsmodels 진단 (있으면)
    provenance:       Dict
    note:             str


def model_digital_index(country_key: str) -> float:
    """국가 프리셋의 인구가중 디지털친화도 = 모델 구조적 디지털채택 지수."""
    p = COUNTRY_PRESETS[country_key]
    total_share = sum(a.share for a in p.agents) or 1.0
    return float(sum(a.share * a.digital for a in p.agents) / total_share)


def _ols(x: np.ndarray, y: np.ndarray) -> OlsFit:
    """단순 affine OLS (numpy). R², adj-R², RMSE, 기울기 95% CI."""
    n = len(x)
    X = np.column_stack([np.ones(n), x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    intercept, slope = float(beta[0]), float(beta[1])
    yhat = X @ beta
    resid = y - yhat
    ss_res = float(resid @ resid)
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    k = 2
    adj_r2 = 1.0 - (1 - r2) * (n - 1) / max(n - k, 1)
    rmse = float(np.sqrt(ss_res / n))

    # 기울기 표준오차 → 95% CI
    if n > k and ss_tot > 0:
        sigma2 = ss_res / (n - k)
        sxx = float(((x - x.mean()) ** 2).sum())
        se_slope = float(np.sqrt(sigma2 / sxx)) if sxx > 0 else 0.0
        t = 1.96  # 대표본 근사 (statsmodels 있으면 정확 t로 대체 가능)
        ci = [slope - t * se_slope, slope + t * se_slope]
    else:
        ci = [slope, slope]

    return OlsFit(round(slope, 6), round(intercept, 6), round(r2, 6),
                  round(adj_r2, 6), round(rmse, 6), n,
                  [round(ci[0], 6), round(ci[1], 6)])


def calibrate_panel(
    countries: Optional[List[str]] = None,
) -> PanelCalibrationResult:
    """
    FRED/BIS 패널에 대해 모델 구조량을 보정하고 의미 있는 R²를 산출한다.
    """
    # 지연 임포트 (data 패키지 순환참조 방지)
    from data.dataio import build_empirical_panel

    panel = build_empirical_panel(countries)
    if countries is None:
        countries = sorted(panel["country"].unique().tolist())

    # 모델 구조 지수 d_hat (국가별 상수)
    d_hat_map = {c: model_digital_index(c) for c in countries}
    panel = panel[panel["country"].isin(countries)].copy()
    panel["d_hat"] = panel["country"].map(d_hat_map)

    x_panel = panel["d_hat"].to_numpy(dtype=float)
    y_panel = panel["digital_share"].to_numpy(dtype=float)
    panel_fit = _ols(x_panel, y_panel)

    # 횡단면(국가평균) 회귀
    cs = panel.groupby("country").agg(
        d_obs=("digital_share", "mean"),
        d_hat=("d_hat", "first"),
        cr5=("cr5", "mean"),
    ).reset_index()
    cs_fit = _ols(cs["d_hat"].to_numpy(float), cs["d_obs"].to_numpy(float))

    per_country = [
        {"country": r.country,
         "d_obs_mean": round(float(r.d_obs), 4),
         "d_hat": round(float(r.d_hat), 4),
         "cr5_mean": round(float(r.cr5), 4),
         "abs_error": round(abs(float(r.d_obs) - float(r.d_hat)), 4)}
        for r in cs.itertuples()
    ]

    # statsmodels 진단 (잔차 정상성·정규성)
    diagnostics: List[Dict] = []
    if _HAS_SM and len(y_panel) >= 10:
        X = sm.add_constant(x_panel)
        res = sm.OLS(y_panel, X).fit()
        resid = res.resid
        try:
            adf_stat, adf_p, *_ = adfuller(resid, autolag="AIC")
            diagnostics.append({"test": "ADF (residual stationarity)",
                                "statistic": round(float(adf_stat), 4),
                                "p_value": round(float(adf_p), 4),
                                "passed": bool(adf_p < 0.05)})
        except Exception:
            pass
        try:
            jb_stat, jb_p, _, _ = jarque_bera(resid)
            diagnostics.append({"test": "Jarque-Bera (residual normality)",
                                "statistic": round(float(jb_stat), 4),
                                "p_value": round(float(jb_p), 4),
                                "passed": bool(jb_p > 0.05)})
        except Exception:
            pass

    prov = panel.attrs.get("provenance", {})
    note = (f"패널 {panel_fit.n}관측 (국가{len(countries)}×연도) · "
            f"R²={panel_fit.r2:.3f}, 횡단면 R²={cs_fit.r2:.3f} · "
            + ("statsmodels 진단 포함" if _HAS_SM else "statsmodels 미설치(numpy OLS)"))

    return PanelCalibrationResult(
        countries=countries, n_obs=panel_fit.n,
        panel_fit=panel_fit, cross_section_fit=cs_fit,
        per_country=per_country, diagnostics=diagnostics,
        provenance=prov, note=note,
    )
