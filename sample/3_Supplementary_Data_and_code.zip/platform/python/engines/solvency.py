"""
지급능력(Solvency) 파산 메커니즘 — WaMu 모델 — v1.0

배경
────
기존 core.py의 bank failure는 "유동성 위기(liquidity crisis)" 모델이다:
예금이탈 → 스트레스 → 안정성 감소 → 실패확률.
이는 Northern Rock(2007), SVB(2023) 유형에 적합하다.

그러나 Washington Mutual(2008)의 실제 파산 경로는 달랐다:
  1단계: 모기지 손실로 **자산가치 감소** (유동성은 처음엔 정상)
  2단계: 자본비율(CAR) 하락 → 규제당국 주목
  3단계: 불안감 전파 → 예금이탈 가속 (유동성 위기로 전환)
  4단계: 자본 소진 → OTS 압류 → FDIC 수탁관리
  5단계: JPMorgan에 $1.9B에 매각 (주주·후순위채 전액 손실)

이 경로의 핵심: **자산 손상이 먼저, 뱅크런은 나중이다.**
core.py의 순서(뱅크런→유동성→실패)와 정반대.

이론적 근거
───────────
[KN21]  Kumhof & Noone (2021): CBDC 도입 시 "quiet bank run" 경로.
        자본비율 하락이 CBDC 채택 유인을 만들어 유동성 위기를 촉발.
[AG14]  Acharya, V. & Mora, N. (2015). "A crisis of banks as liquidity
        providers." Journal of Finance, 70(1), 1–43.
        — 자본 부족 은행이 예금 경쟁에서 탈락하는 메커니즘.
[BHK14] Berger, A. N., et al. (2016). "Bank liquidity creation following
        regulatory interventions and capital support." Journal of Financial
        Intermediation, 26, 115–141.
        — 규제 자본 하한과 유동성 창출 관계.
[FDIC08] FDIC (2008). "The 2008 FDIC Annual Report." Washington Mutual
        receivership 공식 기록.
[OTS08] OTS (2008). "Washington Mutual Examination: Safety and Soundness."
        — CAR 경로 실증 데이터.

WaMu 실증 수치 (crisis_episodes.csv의 washington_mutual 행)
───────────────────────────────────────────────────────────
  deposits_bn=188, peak_outflow=0.02 (1일 최대), total_decline=0.09 (10일)
  concentration=0.55, digital=0.45 (2008년 = 도매 낮음)
  severity=0.55, had_lolr=0, window_days=10, failed=1
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple

import numpy as np

from models.params  import SimulationParams
from models.results import SimulationResult


# ══════════════════════════════════════════════════════════════════════════════
# 지급능력 파산 파라미터 (WaMu 실증 보정)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class SolvencyParams:
    """
    지급능력 파산 모델 파라미터.
    기본값은 WaMu(2008)를 기준으로 보정됨.
    """
    # ── 자산 손상 경로 ─────────────────────────────────────────────────────
    # [OTS08]: WaMu의 모기지 포트폴리오 구성 → 고위험 자산비율
    risky_asset_share:      float = 0.62   # 위험자산(모기지·증권) 비율 [OTS08]
    # [FDIC08]: 위기 1년간 자산 손상률 (모기지 디폴트 손실)
    asset_loss_rate_annual: float = 0.045  # 연간 자산손상률 → 일별 환산 [FDIC08]
    # 손상 속도: 처음엔 느리다가 가속 (모기지 디폴트 파급에 lag 존재)
    loss_acceleration:      float = 1.8    # 후반부 손상 가속 계수
    # 위기 윈도우 집중 계수: 연중 분산이 아니라 위기 수주에 손상이 집중됨.
    # 자산손상이 CAR의 주 동인이 되도록 (solvency-first 경로 재현).
    # 2.5: WaMu 압류 ~8-10일·peak<15%·hybrid 경로를 재현하도록 보정.
    crisis_impairment_mult: float = 2.5

    # ── 자본비율 (CAR) 임계 ────────────────────────────────────────────────
    # Basel II: Well-capitalized = CAR ≥ 10%; Undercapitalized = CAR < 8%
    # [BHK14]: 실질 규제 압력 시작 임계
    car_well_capitalized:   float = 0.10   # 양호 임계
    car_undercapitalized:   float = 0.08   # 부실 임계 (규제 경보)
    car_critically_low:     float = 0.06   # 임박 압류 임계 [OTS08]
    # [KN21]: CBDC 도입 시 CAR 하락→조용한 뱅크런 전환 민감도
    cbdc_car_sensitivity:   float = 0.35   # CAR 1%p 하락당 CBDC 도피율

    # ── 예금이탈↔자본 상호작용 ────────────────────────────────────────────
    # [AG14]: 자본비율 하락이 예금이탈을 유발하는 비율 (조용한 뱅크런)
    quiet_run_trigger_car:  float = 0.09   # CAR이 이 이하로 내려가면 조용한 뱅크런 시작
    quiet_run_intensity:    float = 0.18   # 조용한 뱅크런 일일 이탈률 [AG14]
    # [FDIC08]: WaMu 공개 발표 후 패닉 가속 계수
    panic_amplifier:        float = 2.40   # 공개 정보 누설 후 이탈 가속배율

    # ── FDIC/OTS 압류 조건 ────────────────────────────────────────────────
    # [FDIC08]: 실제 압류 기준: CAR < 2% 또는 예금이탈 누적 > 20%
    fdic_car_threshold:     float = 0.02
    fdic_outflow_threshold: float = 0.20


# ══════════════════════════════════════════════════════════════════════════════
# 은행 재무상태 상태변수
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class BankBalance:
    """일별 재무상태 스냅샷."""
    day:                int
    assets:             float   # 총자산 (초기 = 1.0 정규화)
    equity:             float   # 자기자본
    deposits:           float   # 예금 (초기 = 1.0)
    car:                float   # 자본비율 = equity / assets
    cumulative_loss:    float   # 누적 자산손상
    cumulative_outflow: float   # 누적 예금이탈 (분율)
    daily_outflow:      float   # 당일 예금이탈 (분율)
    phase:              str     # "normal"|"stressed"|"quiet_run"|"panic"|"seized"
    car_breach:         str     # ""|"undercapitalized"|"critically_low"|"seized"
    lolr_received:      float   # 당일 LOLR 지원
    cbdc_flight:        float   # CBDC 도피로 인한 추가 이탈 (CBDC 시나리오 전용)


@dataclass
class SolvencyResult:
    """지급능력 파산 시뮬레이션 전체 결과."""
    params:             SimulationParams
    sp:                 SolvencyParams
    series:             List[BankBalance]
    seized_day:         Optional[int]    # 파산/압류 발생일 (None=생존)
    final_car:          float
    final_outflow_cumul:float
    failure_path:       str             # 파산 경로 분류
    wamu_score:         float           # WaMu 유사도 점수 [0,1]
    cbdc_amplification: float           # CBDC가 없었을 대비 손상 증폭배율
    fingerprint:        str


# ══════════════════════════════════════════════════════════════════════════════
# 핵심 시뮬레이션 엔진
# ══════════════════════════════════════════════════════════════════════════════

def run_solvency(
    params: SimulationParams,
    sp: Optional[SolvencyParams] = None,
    cbdc_enabled: bool = True,
    seed_offset: int = 0,
) -> SolvencyResult:
    """
    WaMu식 지급능력 파산 경로 시뮬레이션.

    핵심 순서:
      자산 손상 → CAR 하락 → 조용한 뱅크런 → 패닉 → 압류

    이 순서가 core.py(유동성 위기)와 구별되는 지급능력 파산의 본질이다.

    Parameters
    ----------
    cbdc_enabled : bool
        True면 CAR 하락 시 CBDC 도피 경로가 추가로 활성화됨.
        False로 비교하면 CBDC가 얼마나 파산을 가속하는지 측정 가능.
    """
    if sp is None:
        sp = SolvencyParams()

    rng  = np.random.default_rng(
        np.random.MT19937((params.seed + seed_offset + 8888) & 0xFFFF_FFFF)
    )

    # ── 초기 상태 (정규화) ─────────────────────────────────────────────────
    # WaMu 실증: 자본비율 ≈ 9.5% (위기 진입 시점, 규제상 양호~부실 경계).
    # B2-#2 수정: 런 트리거(0.09) 위에서 출발 → 자산손상이 CAR을 끌어내려
    # 트리거를 돌파한 뒤에야 조용한 뱅크런이 시작(solvency가 원인, 런은 결과).
    initial_car      = 0.095 + rng.random() * 0.005
    assets           = 1.0
    equity           = initial_car * assets
    deposits         = 0.88   # 부채의 88%가 예금 (WaMu 실증)
    cum_loss         = 0.0
    cum_outflow      = 0.0
    phase            = "normal"
    series: List[BankBalance] = []
    seized_day: Optional[int] = None

    # ── 일별 자산 손상률 (위기 윈도우 집중형) ──────────────────────────────
    # [OTS08]: 위기 시 모기지 손상은 연중 분산이 아니라 위기 수개월에 집중 크리스털화.
    # B2-#2 수정: 연율/252(거래일 분산) → 위기 윈도우 집중. 자산손상이 CAR의
    # 주(主) 동인이 되어 "손상→CAR붕괴→런"(solvency-first) 순서를 재현한다.
    # (수정 전: 연율/252 ≈ 0.0001/일 → CAR 미동, 화재매각만 CAR을 끌어내려
    #  실제로는 liquidity-first로 오분류되던 문제.)
    crisis_impairment = getattr(sp, "crisis_impairment_mult", 4.0)
    daily_loss_base = (sp.asset_loss_rate_annual * sp.risky_asset_share
                       / 30.0 * crisis_impairment)

    for d in range(1, params.days + 1):
        t = d / params.days

        # ── 1단계: 자산 손상 (모기지 디폴트, 증권 평가손) ─────────────────
        # 가속: 후반부에 sp.loss_acceleration배
        loss_mult = 1.0 + (sp.loss_acceleration - 1.0) * t
        shock_boost = params.shock * (1 - math.exp(-5 * t))
        daily_loss = daily_loss_base * loss_mult * (1 + shock_boost)
        daily_loss += float(rng.random() * daily_loss * 0.15)  # 손상 노이즈

        assets    -= daily_loss
        equity    -= daily_loss
        cum_loss  += daily_loss
        assets     = max(assets, 0.001)
        equity     = max(equity, 0.0)

        # ── 2단계: CAR 계산 및 위반 판정 ──────────────────────────────────
        car = equity / assets if assets > 0 else 0.0

        car_breach = ""
        if car < sp.fdic_car_threshold:
            car_breach = "seized"
        elif car < sp.car_critically_low:
            car_breach = "critically_low"
        elif car < sp.car_undercapitalized:
            car_breach = "undercapitalized"

        # ── 3단계: 예금이탈 결정 (WaMu 경로 핵심) ────────────────────────

        # 3-A. 기저 이탈: 위기 충격 직접 효과
        base_out = params.shock * shock_boost * 0.025 * (1 + rng.random() * 0.2)

        # 3-B. 조용한 뱅크런: CAR이 quiet_run_trigger 이하로 내려가면 도매예금 이탈
        # [AG14]: 기관예금자는 CAR을 실시간 모니터링 → 조용히 이탈
        quiet_run = 0.0
        if car < sp.quiet_run_trigger_car:
            quiet_run = sp.quiet_run_intensity * (sp.quiet_run_trigger_car - car) / sp.quiet_run_trigger_car
            quiet_run *= params.concentration   # 집중된 기관예금일수록 이탈 빠름
            if phase in ("normal", "stressed"):
                phase = "quiet_run"

        # 3-C. CBDC 도피: CBDC 도입 환경에서 CAR 하락 시 소매예금도 이탈
        # [KN21]: "quiet bank run via CBDC" — 앱 한 번으로 이탈 가능
        cbdc_flight = 0.0
        if cbdc_enabled and car < sp.quiet_run_trigger_car:
            # 디지털 친화도 × CAR 하락폭 × CBDC 민감도
            car_drop = max(0.0, sp.quiet_run_trigger_car - car)
            cbdc_flight = params.digital * car_drop * sp.cbdc_car_sensitivity
            cbdc_flight *= (1 + params.shock * 0.5)

        # 3-D. 공개 정보 누설 후 패닉 (CAR critically_low 이후)
        panic_mult = 1.0
        if car_breach in ("critically_low", "seized"):
            panic_mult = sp.panic_amplifier
            if phase != "seized":
                phase = "panic"

        daily_out = float(np.clip(
            (base_out + quiet_run + cbdc_flight) * panic_mult,
            0.0, 0.30   # 하루 최대 30% 이탈 (WaMu 실증 상한)
        ))

        deposits  -= daily_out * deposits
        deposits   = max(deposits, 0.001)
        cum_outflow = float(np.clip(cum_outflow + daily_out, 0.0, 1.0))

        # 예금 이탈로 자산도 감소 (유동성 매각 강요) [BP09] Eq.(11)
        # B2 수정: epoch 시작 assets 기준으로 모든 계산 수행 후 한 번에 적용
        # 수정 전: assets 감소 후 줄어든 assets로 equity 재계산 → equity 과대 감소
        assets_before_sale = assets
        forced_sale_ratio  = daily_out * 0.5   # 이탈의 50%는 자산 매각 [BP09]
        forced_sale_amount = forced_sale_ratio * assets_before_sale
        # 매각 손실: 장부가 대비 30% 할인 매각 (fire sale discount) [BP09]
        forced_sale_loss   = forced_sale_amount * 0.30
        assets -= forced_sale_amount
        equity -= forced_sale_loss   # epoch 시작 assets 기준 손실만 차감

        # ── 4단계: LOLR 지원 (params.lolr=True이고 critically_low 이상일 때만) ──
        lolr_amt = 0.0
        if params.lolr and car < sp.car_undercapitalized and car > sp.fdic_car_threshold:
            lolr_amt  = min(0.002, (sp.car_undercapitalized - car) * 0.5)
            equity   += lolr_amt * assets
            deposits += lolr_amt * assets  # LOLR = 유동성 공급

        # ── 5단계: FDIC 압류 판정 ─────────────────────────────────────────
        # [FDIC08]: CAR < 2% OR 누적이탈 > 20% → 압류
        if seized_day is None:
            if car < sp.fdic_car_threshold or cum_outflow > sp.fdic_outflow_threshold:
                phase      = "seized"
                seized_day = d

        series.append(BankBalance(
            day=d, assets=round(assets, 6), equity=round(equity, 6),
            deposits=round(deposits, 6), car=round(car, 4),
            cumulative_loss=round(cum_loss, 6),
            cumulative_outflow=round(cum_outflow, 6),
            daily_outflow=round(daily_out, 6),
            phase=phase, car_breach=car_breach,
            lolr_received=round(lolr_amt, 6),
            cbdc_flight=round(cbdc_flight, 6),
        ))

        if phase == "seized":
            break   # 파산 후 시뮬레이션 종료

    # ── 결과 집계 ──────────────────────────────────────────────────────────
    last = series[-1]
    failure_path = _classify_failure_path(series, sp, seized_day)
    wamu_score   = _compute_wamu_similarity(series, sp, seized_day)

    # CBDC 증폭배율: cbdc_enabled=True vs False 비교는 호출자가 수행
    # 여기선 CBDC 비행 비율로 추정
    total_cbdc_flight = sum(b.cbdc_flight for b in series)
    total_out         = last.cumulative_outflow
    cbdc_amp          = (total_cbdc_flight / total_out) if total_out > 0 else 0.0

    # ② fingerprint 완전성 수정:
    # SolvencyParams(risky_asset_share 등)가 fingerprint에 없으면
    # 파라미터를 바꿔도 동일 fingerprint → 재현 보장 실패.
    import hashlib, json, dataclasses
    sp_dict = dataclasses.asdict(sp) if sp is not None else {}
    fp_payload = json.dumps(
        {
            "experiment_id": params.experiment_id,
            "seed":          params.seed,
            "seized_day":    seized_day,
            "final_car":     last.car,
            "cum_outflow":   last.cumulative_outflow,
            "cbdc_enabled":  cbdc_enabled,
            "sp_hash":       hashlib.md5(
                                 json.dumps(sp_dict, sort_keys=True).encode()
                             ).hexdigest(),
            "params_hash":   hashlib.md5(
                                 json.dumps(params.model_dump(), sort_keys=True,
                                            default=str).encode()
                             ).hexdigest(),
        },
        sort_keys=True,
    )
    fingerprint = hashlib.sha256(fp_payload.encode()).hexdigest()

    return SolvencyResult(
        params=params, sp=sp, series=series,
        seized_day=seized_day,
        final_car=last.car,
        final_outflow_cumul=last.cumulative_outflow,
        failure_path=failure_path,
        wamu_score=round(wamu_score, 4),
        cbdc_amplification=round(cbdc_amp, 4),
        fingerprint=fingerprint,
    )


def _classify_failure_path(
    series: List[BankBalance],
    sp: SolvencyParams,
    seized_day: Optional[int],
) -> str:
    """
    파산 경로 분류:
      solvency_first   : 자산손상→CAR 붕괴→뱅크런 (WaMu 유형)
      liquidity_first  : 뱅크런→유동성 고갈→파산 (SVB 유형)
      hybrid           : 두 경로 동시 진행
      survived         : 생존
    """
    if seized_day is None:
        return "survived"

    # 조용한 뱅크런 시작 vs 자본부실(undercapitalized) 진입 시점 비교.
    # B2-#2 수정: 기존엔 'critically_low'(0.06)를 기준으로 비교했으나, 런 트리거
    # (0.09)가 그보다 높아 CAR이 항상 트리거를 먼저 통과 → 구조적으로 solvency_first가
    # 불가능했다. 지급능력 파산의 본질은 "자본이 규제 부실선을 깨면서(=원인) 런이
    # 뒤따른다(=결과)"이므로, undercapitalized(0.08) 진입을 solvency 마커로 사용한다.
    quiet_run_days = [b.day for b in series if b.phase == "quiet_run"]
    under_days     = [b.day for b in series
                      if b.car_breach in ("undercapitalized", "critically_low", "seized")]

    if not quiet_run_days:
        return "solvency_first"   # 뱅크런 없이 자본 고갈
    if not under_days:
        return "liquidity_first"  # 자본 정상인데 이탈 (순수 유동성)

    first_qr   = min(quiet_run_days)
    first_under = min(under_days)

    # 자본부실이 런보다 먼저(2일+) → solvency_first; 런이 먼저(3일+) → liquidity_first;
    # 근접(동시 진행) → hybrid (WaMu: 부실과 런이 거의 동시).
    if first_under < first_qr - 1:
        return "solvency_first"
    elif first_qr < first_under - 3:
        return "liquidity_first"
    else:
        return "hybrid"


def _compute_wamu_similarity(
    series: List[BankBalance],
    sp: SolvencyParams,
    seized_day: Optional[int],
) -> float:
    """
    WaMu 실증 패턴과의 유사도 [0, 1].
    WaMu: 10일 위기 / 파산 / peak_outflow 0.02 / 조용한 뱅크런 패턴
    """
    if seized_day is None:
        return 0.0

    score = 0.0
    # 파산 여부 (+0.3)
    score += 0.30

    # 위기 기간 유사도: WaMu = 10일 (+0.2)
    day_score = max(0.0, 1.0 - abs(seized_day - 10) / 30.0)
    score += 0.20 * day_score

    # peak outflow 유사도: WaMu ≈ 0.02 (+0.2)
    peak_out = max(b.daily_outflow for b in series) if series else 0.0
    out_score = max(0.0, 1.0 - abs(peak_out - 0.02) / 0.10)
    score += 0.20 * out_score

    # 조용한 뱅크런 단계 존재 (+0.15)
    if any(b.phase == "quiet_run" for b in series):
        score += 0.15

    # 초기 CAR 정상 후 하락 패턴 (+0.15)
    if series and series[0].car > sp.car_well_capitalized:
        score += 0.15

    return float(np.clip(score, 0.0, 1.0))


# ══════════════════════════════════════════════════════════════════════════════
# CBDC 증폭 비교 실험 (with vs without CBDC)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class CbdcAmplificationResult:
    """CBDC 유무에 따른 파산 가속도 비교."""
    with_cbdc:         SolvencyResult
    without_cbdc:      SolvencyResult
    seized_day_delta:  Optional[int]    # CBDC로 인해 파산이 앞당겨진 일수 (음수 = 가속)
    car_drop_delta:    float            # CBDC로 인한 추가 CAR 하락
    outflow_delta:     float            # CBDC로 인한 추가 누적이탈
    cbdc_hastens:      bool             # CBDC가 파산을 앞당기는가


def compare_cbdc_amplification(
    params: SimulationParams,
    sp: Optional[SolvencyParams] = None,
) -> CbdcAmplificationResult:
    """
    CBDC 도입 전/후 지급능력 파산 경로 비교.
    논문의 핵심 반사실(counterfactual) 분석.
    """
    r_with    = run_solvency(params, sp, cbdc_enabled=True)
    r_without = run_solvency(params, sp, cbdc_enabled=False)

    d_with    = r_with.seized_day
    d_without = r_without.seized_day

    if d_with is not None and d_without is not None:
        delta_day = d_with - d_without   # 음수면 CBDC가 파산 가속
    elif d_with is not None and d_without is None:
        delta_day = -params.days         # CBDC로 인해 파산 (없으면 생존)
    else:
        delta_day = None

    # B2-#2 발견 수정: outflow_delta·car_drop_delta를 각 시계열의 '자기 압류일'에서
    # 비교하면, CBDC가 파산을 앞당겨 with-CBDC 시계열이 더 짧아질 때 누적이탈이
    # 오히려 작게 측정돼 delta 부호가 뒤집힌다(서로 다른 시점 비교 = 무효).
    # 올바른 반사실은 '동일 시점'(더 이른 압류일) 비교다.
    common = min(len(r_with.series), len(r_without.series))
    ow_with    = r_with.series[common - 1].cumulative_outflow
    ow_without = r_without.series[common - 1].cumulative_outflow
    car_with    = r_with.series[common - 1].car
    car_without = r_without.series[common - 1].car

    return CbdcAmplificationResult(
        with_cbdc=r_with,
        without_cbdc=r_without,
        seized_day_delta=delta_day,
        car_drop_delta=round(car_without - car_with, 4),
        outflow_delta=round(ow_with - ow_without, 4),
        cbdc_hastens=(delta_day is not None and delta_day < 0),
    )
