"""
시뮬레이션 파라미터 모델 — v4.1

수학 정확성 강화:
  - WelfareWeights: benefit+cost 합산 검증 (각 그룹 합이 올바른 비율)
  - WelfareWeights: 가중치 합 = 1.0 자동 정규화 + 경고
  - AgentConfig: share 합 = 1.0 ± 0.01 검증
  - SimulationParams: shock, digital, concentration 범위 검증
"""
from __future__ import annotations
from typing import Literal, List
try:
    from pydantic import BaseModel, Field, model_validator
except ModuleNotFoundError:  # clean-env reproduction fallback
    from _compat_pydantic import BaseModel, Field, model_validator
import warnings

CbdcArch   = Literal["two_tier", "account", "token"]
CrisisType = Literal["bankrun", "cyber", "rate", "singlebank", "payment"]
CountryKey = Literal[
    "korea", "us", "eu", "china", "sweden", "custom",
    "japan", "uk", "canada", "australia", "germany", "france", "italy", "spain",
    "netherlands", "switzerland", "singapore", "india", "brazil", "mexico", "norway",
]


class AgentConfig(BaseModel):
    key:     str
    name:    str
    share:   float = Field(ge=0, le=0.5,
                           description="에이전트 예금 비중 [0, 0.5]")
    digital: float = Field(ge=0, le=1,
                           description="디지털 친화도 [0, 1]")
    risk:    float = Field(ge=0, le=1,
                           description="위기 리스크 민감도 [0, 1]")


class WelfareWeights(BaseModel):
    """
    사회적 후생 함수 가중치.

    수학적 제약:
      benefit 가중치 (payment, inclusion, innovation) 합 = [0.3, 0.7]
      cost    가중치 (risk, disinter, oper)            합 = [0.3, 0.7]
      전체 합 = 1.0

    합이 1.0이 아닐 경우 자동 정규화 후 경고를 발생시킨다.
    이는 welfare ∈ [-0.5, 0.5] 스케일 보장에 필수적이다.
    """
    payment:    float = Field(default=0.25, ge=0, le=1)
    inclusion:  float = Field(default=0.10, ge=0, le=1)
    innovation: float = Field(default=0.15, ge=0, le=1)
    risk:       float = Field(default=0.30, ge=0, le=1)
    disinter:   float = Field(default=0.15, ge=0, le=1)
    oper:       float = Field(default=0.05, ge=0, le=1)

    @model_validator(mode="after")
    def validate_weights(self) -> "WelfareWeights":
        total = (self.payment + self.inclusion + self.innovation
                 + self.risk + self.disinter + self.oper)

        if abs(total - 1.0) > 1e-6:
            # 자동 정규화: welfare 스케일을 [-0.5, 0.5]로 보장
            warnings.warn(
                f"WelfareWeights 합={total:.6f} ≠ 1.0. "
                f"자동 정규화 적용. 논문에서 정규화된 가중치를 보고할 것.",
                UserWarning, stacklevel=2,
            )
            self.payment    = round(self.payment    / total, 8)
            self.inclusion  = round(self.inclusion  / total, 8)
            self.innovation = round(self.innovation / total, 8)
            self.risk       = round(self.risk       / total, 8)
            self.disinter   = round(self.disinter   / total, 8)
            self.oper       = round(self.oper       / total, 8)

        benefit_sum = self.payment + self.inclusion + self.innovation
        cost_sum    = self.risk + self.disinter + self.oper
        if not (0.2 <= benefit_sum <= 0.8):
            warnings.warn(
                f"benefit 가중치 합={benefit_sum:.3f}이 권장 범위 [0.2, 0.8] 밖. "
                f"welfare 스케일이 비대칭해질 수 있음.",
                UserWarning, stacklevel=2,
            )
        return self

    @property
    def benefit_sum(self) -> float:
        return self.payment + self.inclusion + self.innovation

    @property
    def cost_sum(self) -> float:
        return self.risk + self.disinter + self.oper


class SimulationParams(BaseModel):
    experiment_id: str   = "EXP-CBDC-001"
    seed:          int   = 20260618
    hypothesis:    str   = ""
    country:       CountryKey  = "korea"
    arch:          CbdcArch    = "two_tier"
    cbdc:          bool  = True   # CBDC 발행 여부. False면 Eq.1 baseline 채널만(=No-CBDC 반사실).
    cap:           float = Field(default=20_000_000, gt=0,
                                 description="CBDC 보유 한도 (KRW, >0)")
    days:          int   = Field(default=90, ge=5, le=730,
                                 description="시뮬레이션 기간 [5, 730]일")
    crisis:        CrisisType  = "bankrun"
    shock:         float = Field(default=0.35, ge=0.0, le=1.0,
                                 description="충격 강도 [0, 1]")
    digital:       float = Field(default=0.92, ge=0.0, le=1.0,
                                 description="디지털 결제율 [0, 1]")
    concentration: float = Field(default=0.75, ge=0.0, le=1.0,
                                 description="은행 집중도 [0, 1]")
    cash:          float = Field(default=0.08, ge=0.0, le=1.0,
                                 description="현금 사용률 [0, 1]")
    dynamic_cap:   bool  = True
    lolr:          bool  = True
    tiered:        bool  = True
    tier1:         float = Field(default=5_000_000, gt=0)
    rate2:         float = Field(default=-1.5, ge=-10.0, le=0.0,
                                 description="Tier-2 금리 [-10, 0]%")
    rate3:         float = Field(default=-4.0, ge=-10.0, le=0.0,
                                 description="Tier-3 금리 [-10, 0]%")
    agents:        List[AgentConfig]  = []
    weights:       WelfareWeights     = WelfareWeights()
    threshold:     float = Field(default=0.62, ge=0.0, le=1.0,
                                 description="안정성 임계값 [0, 1]")
    mc_n:          int   = Field(default=500, ge=10, le=10_000,
                                 description="Monte Carlo 샘플 수 [10, 10000]")
    fire_sale_enabled:    bool  = True
    asset_illiquidity:    float = Field(default=0.45, ge=0.0, le=1.0)
    fire_sale_elasticity: float = Field(default=0.60, ge=0.0, le=2.0)
    capital_buffer:       float = Field(default=0.30, ge=0.0, le=1.0)

    # ── 신규 정책수단 (E) ─────────────────────────────────────────────────
    # 모두 CBDC 이탈 채널을 조절. 효과 계수는 author-calibrated (engines/core 참조).
    cbdc_tax:          float = Field(default=0.0, ge=0.0, le=0.05,
                                     description="CBDC 보유세율 [0,5%]: 대량 보유 억제 → 이탈 완화")
    cbdc_expiration:   bool  = False   # 만료형 CBDC: 비축 억제 → 패닉 이탈 완화
    offline_cbdc:      bool  = False   # 오프라인 CBDC: 포용성↑, 위기 시 이탈 회복력 소폭↑
    programmable_cbdc: bool  = False   # 프로그래머블 CBDC: 조건부 이체한도 → 패닉 이탈 강한 완화

    # ── ABM 규모 (② 확장) ─────────────────────────────────────────────────
    abm_grid_size:   int = Field(default=10, ge=5, le=500,
                                 description="ABM 격자 한 변 길이 [5,500] (최대 500×500)")
    abm_n_types:     int = Field(default=6, ge=1, le=30,
                                 description="ABM 에이전트 아키타입 수 [1,30]")

    @model_validator(mode="after")
    def validate_agents_and_rates(self) -> "SimulationParams":
        # 에이전트 share 합 검증 (에이전트가 있을 때만)
        if self.agents:
            share_sum = sum(a.share for a in self.agents)
            if abs(share_sum - 1.0) > 0.015:
                raise ValueError(
                    f"AgentConfig share 합={share_sum:.4f}이 1.0과 너무 다름 "
                    f"(허용 오차 ±0.015). "
                    f"수식 base_out = Σ agent.share * (...) 에서 스케일 오류 발생."
                )
            if abs(share_sum - 1.0) > 1e-6:
                warnings.warn(
                    f"AgentConfig share 합={share_sum:.6f} ≠ 1.0 (허용 오차 내). "
                    f"base_out이 약 {abs(share_sum-1.0)*100:.2f}% 오차를 가짐.",
                    UserWarning, stacklevel=2,
                )

        # rate3 < rate2 확인 (Tier-3이 더 낮아야 함)
        if self.tiered and self.rate3 > self.rate2:
            warnings.warn(
                f"rate3={self.rate3} > rate2={self.rate2}. "
                f"Tiered 구조에서 rate3가 rate2보다 낮아야 함 (더 강한 패널티).",
                UserWarning, stacklevel=2,
            )

        # tier1 < cap 확인
        if self.tiered and self.tier1 >= self.cap:
            warnings.warn(
                f"tier1={self.tier1:,} ≥ cap={self.cap:,}. "
                f"Tiered 구조가 실질적으로 작동하지 않음.",
                UserWarning, stacklevel=2,
            )
        return self
