from __future__ import annotations
from typing import List, Literal
try:
    from pydantic import BaseModel
except ModuleNotFoundError:  # clean-env reproduction fallback
    from _compat_pydantic import BaseModel


class DayPoint(BaseModel):
    day:          int
    outflow:      float
    failed:       float
    stability:    float
    stress:       float
    welfare:      float
    welfare_norm: float = 0.0   # [0,1] 정규화 welfare (Barrdear & Kumhof 2016 스케일)
    cap:          float
    lolr_support: float
    pay_eff:      float
    inclusion:    float
    innovation:   float
    risk:         float
    disinter:     float
    oper:         float


class ContagionEvent(BaseModel):
    day:    int
    bank:   str
    stress: float
    source: str


class ContribEntry(BaseModel):
    name:      str
    value:     float
    share:     float
    direction: Literal["risk", "mitigation"]


class SimulationSummary(BaseModel):
    fail_prob:    float
    stability:    float
    stress:       float
    welfare:      float
    welfare_norm: float = 0.0   # [0,1] 정규화 — 논문 Table 직접 보고용
    failed:       float
    lolr_support: float
    threshold:    float


class SimulationResult(BaseModel):
    experiment_id:  str
    seed:           int
    series:         List[DayPoint]
    contagion:      List[ContagionEvent]
    explain:        List[ContribEntry]
    summary:        SimulationSummary
    fingerprint:    str
    engine_version: str
    ran_at:         str


# ── Monte Carlo ───────────────────────────────────────────────────────────────

class HistBin(BaseModel):
    bin:   float
    count: int


class McResult(BaseModel):
    mean_fail_prob: float
    std_fail_prob:  float
    p5:             float
    p95:            float
    n:              int
    histogram:      List[HistBin]
    run_id:         str = ""   # SHA-256(params+n+engine) — MC 실행 추적용
    engine_version: str = ""   # 재현성: 엔진 버전 기록
    ran_at:         str = ""   # ISO 타임스탬프
    method_note:    str = ""   # Geweke Z-score + CI폭 수렴 정보


# ── Sobol ─────────────────────────────────────────────────────────────────────

class SobolEntry(BaseModel):
    name:    str
    s1:      float
    s1_conf: float
    st:      float
    st_conf: float


class SobolResult(BaseModel):
    indices:   List[SobolEntry]
    n_samples: int
    method:    str
    run_id:    str = ""   # SHA-256(params+problem_hash) — Sobol 실행 추적용
    engine_version: str = ""
    ran_at:    str = ""
