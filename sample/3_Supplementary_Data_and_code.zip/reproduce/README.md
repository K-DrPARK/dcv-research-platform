# Reproducible experiment environment

Three ways to reproduce the headline results, in increasing order of isolation:

| Command | What it does |
|---|---|
| `make quick` | Fast smoke test against your local Python (small N) |
| `make reproduce-local` | Full run against your local Python env |
| `make reproduce` | Build a pinned Docker image and run inside it (most reproducible) |

Each run prints every result with a **SHA-256 fingerprint** and compares it to
`expected_fingerprints.json`. To establish an authoritative baseline on your machine:

```bash
make update      # writes expected_fingerprints.json from a clean run
```

`PYTHONHASHSEED=0` is set everywhere to remove hash-ordering nondeterminism; the engine
itself is seeded via MT19937 (`seed = 20260618`).

> The shipped `expected_fingerprints.json` is an empty placeholder *by design* — we do not
> ship fabricated hashes. Generate yours with `make update`, and CI will verify against the
> committed baseline thereafter. See `../docs/reproducibility.md` for the engine-version
> reconciliation note.


## New in this revision: reviewer-requested extensions

```bash
python grid_widened.py       # Table F3 27-combination grid at +-20% (replication) and +-40% (new)
python shrinkage_pooling.py  # random-effects pooling of verified-only / estimated-only theta2
```

Both scripts write their full numeric output to `grid_results.json` and
`shrinkage_results.json` respectively and are self-contained (they load
`data/crisis_episodes.csv` and `platform/python` directly, same as
`reproduce.py`). See manuscript §5.5 (widened grid) and §3.4 (shrinkage
pooling) for how these results are used.
