import sys, time, json
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'platform' / 'python'))
import numpy as np
from models.params import SimulationParams, WelfareWeights, AgentConfig
from engines.core import run_simulation, ENGINE_VERSION

def agents():
    return [
        AgentConfig(key="retail",    name="Retail",        share=0.35, digital=0.65, risk=0.55),
        AgentConfig(key="wholesale", name="Wholesale",     share=0.20, digital=0.55, risk=0.65),
        AgentConfig(key="elderly",   name="Elderly",       share=0.15, digital=0.30, risk=0.25),
        AgentConfig(key="digital",   name="Digital-native",share=0.15, digital=0.95, risk=0.80),
        AgentConfig(key="wealthy",   name="High-value",    share=0.08, digital=0.75, risk=0.95),
        AgentConfig(key="sme",       name="SME",           share=0.07, digital=0.60, risk=0.85),
    ]

DESIGN_CONFIGS = {
    "no_cbdc":       dict(cbdc=False, dynamic_cap=False, tiered=False, lolr=True),
    "unconstrained": dict(cbdc=True,  dynamic_cap=False, tiered=False, lolr=True, cap=50_000_000),
    "fixed_limit":   dict(cbdc=True,  dynamic_cap=False, tiered=False, lolr=True, cap=20_000_000),
    "dyncap_tiered": dict(cbdc=True,  dynamic_cap=True,  tiered=True,  lolr=True, cap=20_000_000),
}

AG = agents()

def mean_fail(N, concentration, digital, shock, **kw):
    base = dict(seed=20260618, country="korea", shock=shock, digital=digital,
                concentration=concentration, agents=AG, weights=WelfareWeights())
    base.update(kw)
    return float(np.mean([float(run_simulation(SimulationParams(**base), seed_offset=i)
                                .summary.fail_prob) for i in range(N)]))

def clip01(x):
    return max(0.0, min(1.0, x))

BASE_C, BASE_D, BASE_S = 0.75, 0.92, 0.75

def run_grid(pct, N, label):
    c_levels = sorted(set(clip01(BASE_C * m) for m in (1-pct, 1.0, 1+pct)))
    d_levels = sorted(set(clip01(BASE_D * m) for m in (1-pct, 1.0, 1+pct)))
    s_levels = sorted(set(clip01(BASE_S * m) for m in (1-pct, 1.0, 1+pct)))
    print(f"\n=== {label}: pct=+-{int(pct*100)}%  N={N} per cell ===")
    print("concentration levels:", c_levels)
    print("digital levels:", d_levels)
    print("shock levels:", s_levels)

    combos = [(c, d, s) for c in c_levels for d in d_levels for s in s_levels]
    n_strict_best = 0
    n_reversal_uncon = 0
    n_reversal_fixed = 0
    results = []
    t0 = time.time()
    for (c, d, s) in combos:
        res = {k: mean_fail(N, c, d, s, **v) for k, v in DESIGN_CONFIGS.items()}
        strictly_best = res["dyncap_tiered"] < res["fixed_limit"] and res["dyncap_tiered"] < res["unconstrained"]
        if strictly_best:
            n_strict_best += 1
        if not (res["dyncap_tiered"] < res["unconstrained"]):
            n_reversal_uncon += 1
        if not (res["dyncap_tiered"] <= res["fixed_limit"]):
            n_reversal_fixed += 1
        results.append({"c": round(c,3), "d": round(d,3), "s": round(s,3), **res, "strictly_best": strictly_best})
    dt = time.time() - t0
    print(f"combos={len(combos)}  strictly_best={n_strict_best}/{len(combos)}  "
          f"reversals_vs_unconstrained={n_reversal_uncon}/{len(combos)}  "
          f"reversals_vs_fixed={n_reversal_fixed}/{len(combos)}  time={dt:.1f}s")
    return {"pct": pct, "N": N, "engine_version": ENGINE_VERSION, "combos": len(combos),
            "strictly_best": n_strict_best, "reversal_unconstrained": n_reversal_uncon,
            "reversal_fixed": n_reversal_fixed, "results": results, "runtime_s": dt}

if __name__ == "__main__":
    out20 = run_grid(0.20, 80, "REPLICATE ORIGINAL +-20%")
    out40 = run_grid(0.40, 80, "WIDENED +-40%")
    with open('grid_results.json', 'w') as f:
        json.dump({"pct20": out20, "pct40": out40}, f, indent=2)
    print("\nSaved to grid_results.json")
