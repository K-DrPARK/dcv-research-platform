#!/usr/bin/env python3
"""
reproduce.py — One-command reproduction of OFSR-CBDC headline results (v10.1).

Runs the shipped engine and the OLS calibration against the n=81 panel and
compares every number to the manuscript with explicit tolerances,
printing PASS / FAIL / SKIPPED honestly. SHA-256 fingerprints are emitted for
bit-for-bit auditing.

Usage
    python reproduce.py                 # run everything (verify + calibration + tables)
    python reproduce.py --verify        # engine fingerprint experiments only
    python reproduce.py --calibration   # OLS/MLE reduced-form estimation only
    python reproduce.py --tables        # regenerate Table 4 design comparison
    python reproduce.py --quick         # smaller N for a fast smoke test (N=100)
    python reproduce.py --update        # rewrite expected_fingerprints.json baseline

Runs in a clean Python 3.11+ env with numpy/scipy/pandas. Optional heavy deps
(SALib/mesa/statsmodels) are only needed for Sobol/ABM and are skipped cleanly.

See paper/REPRODUCTION_REPORT.md for the full manuscript<->package crosswalk,
including the documented gaps (exact OLS theta2 magnitude; digital-regime count).
"""
from __future__ import annotations
import argparse, hashlib, json, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLATFORM_PY = HERE.parent / "platform" / "python"
sys.path.insert(0, str(PLATFORM_PY))
EXPECTED = HERE / "expected_fingerprints.json"

# Manuscript reference values ---------------------------------------
MSS_TABLE4 = {"no_cbdc": 0.0400, "unconstrained": 0.4118,
              "fixed_limit": 0.3197, "dyncap_tiered": 0.1400}
MSS_THETA2 = 0.2466          # Table 2 reduced-form coefficient (manuscript headline, n=81/15 verified)
TOL_SIM = 0.03               # design-comparison P(Fail) tolerance
TOL_THETA2 = 0.06            # theta2 magnitude tolerance (sign/sig is the hard test)


def _fp(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()


def _agents():
    from models.params import AgentConfig
    return [
        AgentConfig(key="retail",    name="Retail",        share=0.35, digital=0.65, risk=0.55),
        AgentConfig(key="wholesale", name="Wholesale",     share=0.20, digital=0.55, risk=0.65),
        AgentConfig(key="elderly",   name="Elderly",       share=0.15, digital=0.30, risk=0.25),
        AgentConfig(key="digital",   name="Digital-native",share=0.15, digital=0.95, risk=0.80),
        AgentConfig(key="wealthy",   name="High-value",    share=0.08, digital=0.75, risk=0.95),
        AgentConfig(key="sme",       name="SME",           share=0.07, digital=0.60, risk=0.85),
    ]


# ── Table 4 design comparison (CORRECTED CONFIGS — see CHANGELOG v10.1) ───────
# Manuscript Table 4 note: "common LOLR-enabled setting". Unconstrained CBDC =
# LOLR on, no holding-limit instrument (large cap). The earlier harness wrongly
# set Unconstrained to lolr=False/cap=20M, yielding 0.386 instead of 0.412.
def _design_configs():
    return {
        "no_cbdc":       dict(cbdc=False, dynamic_cap=False, tiered=False, lolr=True),
        "unconstrained": dict(cbdc=True,  dynamic_cap=False, tiered=False, lolr=True, cap=50_000_000),
        "fixed_limit":   dict(cbdc=True,  dynamic_cap=False, tiered=False, lolr=True, cap=20_000_000),
        "dyncap_tiered": dict(cbdc=True,  dynamic_cap=True,  tiered=True,  lolr=True, cap=20_000_000),
    }


def exp_design_comparison(N: int):
    import numpy as np
    from models.params import SimulationParams, WelfareWeights
    from engines.core import run_simulation, ENGINE_VERSION
    AG = _agents()

    def mean_fail(**kw):
        base = dict(seed=20260618, country="korea", shock=0.75, digital=0.92,
                    concentration=0.75, agents=AG, weights=WelfareWeights())
        base.update(kw)
        return float(np.mean([float(run_simulation(SimulationParams(**base), seed_offset=i)
                                    .summary.fail_prob) for i in range(N)]))

    res = {k: round(mean_fail(**v), 4) for k, v in _design_configs().items()}
    ranking_ok = res["no_cbdc"] < res["dyncap_tiered"] < res["fixed_limit"] < res["unconstrained"]
    return {"engine_version": ENGINE_VERSION, "N": N, "shock": 0.75, "country": "korea",
            "results": res, "ranking_preserved": bool(ranking_ok)}


def exp_solvency_wamu():
    from models.params import SimulationParams, AgentConfig, WelfareWeights
    from engines.solvency import run_solvency, SolvencyParams
    AG = [AgentConfig(key="r", name="Retail",   share=0.5, digital=0.4, risk=0.5),
          AgentConfig(key="w", name="Wholesale",share=0.5, digital=0.8, risk=0.8)]
    p = SimulationParams(seed=42, shock=0.7, crisis="singlebank", concentration=0.55,
                         digital=0.45, lolr=False, days=30, agents=AG, weights=WelfareWeights())
    r = run_solvency(p, SolvencyParams())
    peak = max((b.daily_outflow for b in r.series), default=0.0)
    return {"failure_path": r.failure_path, "seized_day": r.seized_day,
            "peak_outflow": round(float(peak), 4)}


def exp_crisis_loo():
    from engines.crisis_fit import validate_loo
    oos = validate_loo()
    g = lambda k: getattr(oos, k, None)
    return {"n_folds": g("n_folds"),
            "oos_r2_peak": round(float(g("oos_r2_peak")), 4) if g("oos_r2_peak") is not None else None,
            "fail_accuracy": round(float(g("fail_accuracy")), 4) if g("fail_accuracy") is not None else None}


def exp_calibration():
    from engines import ols_calibration as ols
    return ols.run_calibration("base", n_boot=200)


# ── runners ──────────────────────────────────────────────────────────────────
def _hr(c="="): print(c * 72)


def run_verify(N, expected, update, include_loo=False):
    fps, results, mismatch, ran = {}, {}, False, 0
    jobs = [("design_comparison", lambda: exp_design_comparison(N)),
            ("solvency_wamu", exp_solvency_wamu)]
    if include_loo:
        jobs.append(("crisis_loo", exp_crisis_loo))   # slow: ~minutes (LOO grid refit)
    for name, fn in jobs:
        t0 = time.time()
        try:
            res = fn()
        except Exception as e:
            print(f"\n[{name}] SKIPPED — {type(e).__name__}: {e}")
            results[name] = {"skipped": str(e)}
            continue
        fp = _fp(res); fps[name] = fp; results[name] = res; ran += 1
        print(f"\n[{name}]  ({time.time()-t0:.1f}s)")
        print("  result      :", json.dumps(res, ensure_ascii=False))
        print("  fingerprint :", fp)
        exp = (expected or {}).get(name)
        if exp and not update:                     # only compare against a real, non-blank baseline
            ok = exp == fp
            print("  expected    :", exp, "→", "MATCH ✓" if ok else "MISMATCH ✗")
            mismatch = mismatch or (not ok)
        elif not update:
            print("  expected    : (no baseline yet — run --update to mint)")
    return fps, results, mismatch, ran


def run_tables(N):
    print("\n[design_comparison vs manuscript Table 4]")
    res = exp_design_comparison(N)["results"]
    allpass = True
    print(f"  {'design':16s} {'engine':>8s} {'manuscript':>11s} {'Δ':>8s}  verdict")
    for k in ("no_cbdc", "unconstrained", "fixed_limit", "dyncap_tiered"):
        d = res[k] - MSS_TABLE4[k]; ok = abs(d) <= TOL_SIM; allpass &= ok
        print(f"  {k:16s} {res[k]:8.4f} {MSS_TABLE4[k]:11.4f} {d:+8.4f}  {'PASS' if ok else 'FAIL'}")
    rank = res["no_cbdc"] < res["dyncap_tiered"] < res["fixed_limit"] < res["unconstrained"]
    print(f"  ordinal ranking No<DynCap<Fixed<Unconstrained : {'PASS ✓' if rank else 'FAIL ✗'}")
    print(f"  Table 4 magnitudes within ±{TOL_SIM}: {'PASS ✓' if allpass else 'partial (see report)'}")
    return res, (rank and allpass)


def run_calibration_block():
    print("\n[calibration — reduced-form OLS/MLE on n=81 panel]")
    try:
        cal = exp_calibration()
    except Exception as e:
        print(f"  SKIPPED — {type(e).__name__}: {e}")
        return None, False
    t2 = cal["table2_theta2"]
    sign_ok = t2["est"] > 0 and t2["p"] < 0.05
    mag_ok = abs(t2["est"] - MSS_THETA2) <= TOL_THETA2
    print(f"  n = {cal['n']}")
    print(f"  Table 2  theta2 = {t2['est']:+.4f}  (SE {t2['se']:.4f}, t {t2['t']:.3f}, p {t2['p']:.4f})")
    print(f"           manuscript theta2 = {MSS_THETA2:+.4f} (t 3.765, p 0.0003)")
    print(f"           sign & significance (theta2>0, p<0.05) : {'PASS ✓' if sign_ok else 'FAIL ✗'}")
    print(f"           magnitude within ±{TOL_THETA2}              : {'PASS ✓' if mag_ok else 'FAIL ✗ (documented gap)'}")
    me = cal["measurement_error_boot"]
    print(f"  Appendix E.1 ±5pp bootstrap: {me['pct_positive']*100:.0f}% of {me['n_boot']} draws positive "
          f"(manuscript 100%) : {'PASS ✓' if me['pct_positive'] >= 0.99 else 'FAIL ✗'}")
    # Table 2b: extended OLS adding digital adoption D
    t2b2 = cal.get("table2b_theta2"); t3 = cal.get("table2b_theta3_D")
    if t2b2 and t3:
        t2b_sign = t2b2["est"] > 0 and t2b2["p"] < 0.05
        d_ns = t3["p"] > 0.05            # manuscript claim: D is NOT significant
        print(f"  Table 2b (+D): theta2 = {t2b2['est']:+.4f} (p {t2b2['p']:.4f}; manuscript 0.209, p 0.0031) "
              f": {'PASS ✓' if t2b_sign else 'FAIL ✗'}")
        print(f"               theta3_D = {t3['est']:+.4f} (p {t3['p']:.4f}; manuscript 0.0394, p 0.0973, n.s.) "
              f"-> D not significant : {'PASS ✓' if d_ns else 'FAIL ✗'}")
    tr = cal["two_regime"]
    print(f"  Two-regime split: n_digital={tr['n_digital']} (manuscript 7), "
          f"n_traditional={tr['n_traditional']} (manuscript 74)")
    return cal, sign_ok and me["pct_positive"] >= 0.99


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--calibration", action="store_true")
    ap.add_argument("--tables", action="store_true")
    ap.add_argument("--loo", action="store_true", help="include slow leave-one-out fingerprint")
    ap.add_argument("--quick", action="store_true", help="N=100 smoke test")
    ap.add_argument("--update", action="store_true", help="rewrite expected_fingerprints.json")
    args = ap.parse_args()
    N = 100 if args.quick else 300
    run_all = not (args.verify or args.calibration or args.tables) or args.update

    expected = {}
    if EXPECTED.exists():
        try: expected = json.loads(EXPECTED.read_text())
        except Exception: expected = {}

    _hr(); print("OFSR-CBDC — reproduction run (v10.1)")
    print(f"  platform/python : {PLATFORM_PY}")
    print(f"  Monte Carlo N   : {N}{'  (quick)' if args.quick else ''}")
    _hr()

    fps = {}; fail = False; verify_ran = 0
    if args.verify or run_all:
        fps, _, mismatch, verify_ran = run_verify(N, expected, args.update, include_loo=args.loo)
        fail = fail or mismatch
    if args.calibration or run_all:
        _, cal_ok = run_calibration_block()
        fail = fail or (not cal_ok)
    if args.tables or run_all:
        _, tab_ok = run_tables(N)
        fail = fail or (not tab_ok)

    print("\n" + "=" * 72)
    if args.update:
        # merge into existing baseline, keep manuscript reference block
        base = {k: v for k, v in (expected or {}).items() if k.startswith("_")}
        base.update(fps)
        EXPECTED.write_text(json.dumps({**(expected or {}), **fps}, indent=2))
        print(f"Wrote {verify_ran} fingerprint(s) → {EXPECTED}")
    elif args.verify:
        if verify_ran == 0:
            print("RESULT: no experiments ran (missing deps) — cannot confirm reproduction")
        else:
            print("RESULT:", "fingerprints MATCH ✓" if not fail else "fingerprint MISMATCH ✗")
    else:
        print("RESULT:", "headline results reproduced ✓ (design ranking + theta2 sign/robustness)"
              if not fail else "see PASS/FAIL above and paper/REPRODUCTION_REPORT.md")
    _hr()
    return 1 if fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
