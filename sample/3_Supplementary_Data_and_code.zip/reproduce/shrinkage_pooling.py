import sys, json
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'platform' / 'python'))
import numpy as np
from engines.ols_calibration import load_panel, table2, strata

df = load_panel("base")
print("panel n:", len(df), "reliability counts:\n", df["reliability"].value_counts())

# Specification I (Table 2 spec) fit on full panel
full = table2(df)
c_full = full.coef("theta2_CxS")
print("\nFull panel Spec I theta2:", c_full)

# Specification I fit separately on verified-only and estimated-only strata
v_df = df[df["reliability"] == "verified"].reset_index(drop=True)
e_df = df[df["reliability"] == "estimated"].reset_index(drop=True)
print("\nverified n:", len(v_df), " estimated n:", len(e_df))

fit_v = table2(v_df)
fit_e = table2(e_df)
cv = fit_v.coef("theta2_CxS")
ce = fit_e.coef("theta2_CxS")
print("\nVerified-only Spec I theta2:", cv)
print("Estimated-only Spec I theta2:", ce)

# DerSimonian-Laird random-effects (partial-pooling / shrinkage) combination
# of the two stratum-level theta2 estimates, treating them as two "studies"
# of the same underlying quantity with stratum-specific sampling variance.
theta = np.array([cv["est"], ce["est"]])
var   = np.array([cv["se"]**2, ce["se"]**2])
w_fixed = 1.0 / var
theta_fixed = float(np.sum(w_fixed * theta) / np.sum(w_fixed))
Q = float(np.sum(w_fixed * (theta - theta_fixed)**2))
df_Q = len(theta) - 1
C = float(np.sum(w_fixed) - np.sum(w_fixed**2) / np.sum(w_fixed))
tau2 = max(0.0, (Q - df_Q) / C) if C > 0 else 0.0

w_re = 1.0 / (var + tau2)
theta_re = float(np.sum(w_re * theta) / np.sum(w_re))
se_re = float(np.sqrt(1.0 / np.sum(w_re)))
z = theta_re / se_re
from scipy import stats
p_re = float(2 * (1 - stats.norm.cdf(abs(z))))

print(f"\nHeterogeneity Q={Q:.4f} (df={df_Q}), tau^2={tau2:.6f}")
print(f"Random-effects pooled theta2 = {theta_re:.4f}  SE={se_re:.4f}  z={z:.3f}  p={p_re:.4f}")
print(f"95% CI: [{theta_re - 1.96*se_re:.4f}, {theta_re + 1.96*se_re:.4f}]")

# shrinkage weight actually placed on the verified stratum
shrink_w_verified = float(w_re[0] / np.sum(w_re))
print(f"\nImplied weight on verified stratum in pooled estimate: {shrink_w_verified:.3f}")
print(f"Implied weight on estimated stratum: {1-shrink_w_verified:.3f}")

# Compare: naive full-panel unweighted estimate vs RE-pooled estimate
print(f"\nComparison: full-panel Spec I theta2 = {c_full['est']:.4f} (p={c_full['p']:.4f})")
print(f"            RE-pooled (shrinkage) theta2 = {theta_re:.4f} (p={p_re:.4f})")

out = {
    "n_full": len(df), "n_verified": len(v_df), "n_estimated": len(e_df),
    "full_panel_spec1": c_full,
    "verified_only_spec1": cv,
    "estimated_only_spec1": ce,
    "heterogeneity_Q": Q, "df_Q": df_Q, "tau2": tau2,
    "re_pooled_theta2": theta_re, "re_pooled_se": se_re, "re_pooled_z": z, "re_pooled_p": p_re,
    "re_pooled_ci95": [theta_re - 1.96*se_re, theta_re + 1.96*se_re],
    "weight_on_verified": shrink_w_verified,
}
with open('shrinkage_results.json', 'w') as f:
    json.dump(out, f, indent=2)
print("\nsaved shrinkage_results.json")
